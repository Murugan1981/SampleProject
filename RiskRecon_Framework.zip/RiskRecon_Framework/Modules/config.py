import os
from dotenv import load_dotenv

# Load Environment Variables
load_dotenv()

# ================= PORTS & ADAPTERS (Settings) =================
# Base Directories
BASE_DIR = os.getcwd()
CONF_DIR = os.path.join(BASE_DIR, "Config")
OUT_DIR = os.path.join(BASE_DIR, "Output")

# Output Sub-directories
METADATA_DIR = os.path.join(OUT_DIR, "Metadata")
RESP_DIR = os.path.join(OUT_DIR, "Responses")
REPORT_DIR = os.path.join(OUT_DIR, "Reports")

# Input File Paths
INCLUSION_FILE = os.path.join(CONF_DIR, "TestConditionInclusion.xlsx")
EXCLUSION_FILE = os.path.join(CONF_DIR, "TestConditionExclusion.xlsx")

# Output File Paths
EXTRACTED_ENDPOINTS = os.path.join(METADATA_DIR, "ExtractedEndPoints.xlsx")
MASTER_JSON_REPORT = os.path.join(RESP_DIR, "DataService.json")
FINAL_EXCEL_REPORT = os.path.join(REPORT_DIR, "Final_Comparison_Report.xlsx")

# URLs
DEV_URL = os.getenv("SOURCE_URL") 
PROD_URL = os.getenv("TARGET_URL")


def init_environment():
    """Creates necessary folders if they don't exist."""
    for p in [METADATA_DIR, RESP_DIR, REPORT_DIR]:
        os.makedirs(p, exist_ok=True)
    print(f" Environment initialized in: {OUT_DIR}")