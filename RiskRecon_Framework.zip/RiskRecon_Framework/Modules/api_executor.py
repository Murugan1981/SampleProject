import asyncio
from playwright.async_api import async_playwright

# Limit concurrent connections to avoid crashing the server or getting blocked
MAX_CONCURRENT_REQUESTS = 50 

async def fetch_single_pair(context, test_case, dev_base, prod_base):
    """
    Executes one test case against BOTH Dev and Prod.
    Returns a dictionary with the results.
    """
    # 1. Construct Full URLs
    # url_suffix comes from generator (e.g., "/risk/calc/100")
    suffix = test_case['url_suffix']
    q_params = test_case.get('query_params', {})
    
    dev_full_url = dev_base.rstrip('/') + suffix
    prod_full_url = prod_base.rstrip('/') + suffix

    result = {
        "test_id": test_case['test_id'],
        "endpoint": test_case['endpoint_original'],
        "url_suffix": suffix,
        "params": q_params,
        "dev_status": None,
        "prod_status": None,
        "dev_response": None,
        "prod_response": None,
        "error": None
    }

    try:
        # 2. Fire Requests (Parallel within the pair)
        # We fire Dev and Prod at the exact same time
        future_dev = context.get(dev_full_url, params=q_params)
        future_prod = context.get(prod_full_url, params=q_params)
        
        # Wait for both
        resp_dev, resp_prod = await asyncio.gather(future_dev, future_prod)

        # 3. Capture Status Codes
        result['dev_status'] = resp_dev.status
        result['prod_status'] = resp_prod.status

        # 4. Parse JSON (Safely)
        try:
            result['dev_response'] = await resp_dev.json()
        except:
            result['dev_response'] = await resp_dev.text() # Fallback if not JSON
            
        try:
            result['prod_response'] = await resp_prod.json()
        except:
            result['prod_response'] = await resp_prod.text()

    except Exception as e:
        result['error'] = str(e)
        print(f"   Error in {test_case['test_id']}: {e}")

    return result

async def run_parallel_tests(test_cases, dev_base_url, prod_base_url):
    """
    Main Entry Point.
    Manages the Semaphore (Concurrency Limit) and gathers all results.
    """
    results = []
    
    # Semaphore controls how many tests run at once (e.g., 50)
    sem = asyncio.Semaphore(MAX_CONCURRENT_REQUESTS)

    async with async_playwright() as p:
        # Create a specific API Request Context (No UI, very fast)
        # ignore_https_errors=True is crucial for internal Dev environments with self-signed certs
        api_context = await p.request.new_context(ignore_https_errors=True)
        
        async def sem_task(tc):
            async with sem:
                return await fetch_single_pair(api_context, tc, dev_base_url, prod_base_url)

        # Create tasks
        tasks = [sem_task(tc) for tc in test_cases]
        
        # Run them
        # simple progress tracking
        total = len(tasks)
        print(f"   -> Processing {total} tests (Batch size: {MAX_CONCURRENT_REQUESTS})...")
        
        completed_count = 0
        for future in asyncio.as_completed(tasks):
            res = await future
            results.append(res)
            completed_count += 1
            if completed_count % 10 == 0:
                print(f"      ...{completed_count}/{total} done", end='\r')

        print(f"\n   -> All network requests completed.")
        
    return results