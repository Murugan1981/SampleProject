import pandas as pd
import json
from deepdiff import DeepDiff

# ================= COMPARISON CONFIGURATION =================
# Add keys here that change dynamically and should be IGNORED.
# Syntax: "root['keyname']" or regex patterns
IGNORED_PATHS = [
    "root['timestamp']",
    "root['serverTime']",
    "root['traceId']",
    "root['processId']"
]

# significant_digits=4 means 100.00001 and 100.00002 are treated as EQUAL
MATH_TOLERANCE_DIGITS = 4 
# ============================================================

def get_diff_summary(dev_json, prod_json):
    """
    Compares two JSON objects using DeepDiff.
    Returns: (status_string, diff_details_string)
    """
    if dev_json is None or prod_json is None:
        return "ERROR", "One or both responses are empty/null"

    # DeepDiff configuration for Risk Systems
    diff = DeepDiff(
        dev_json, 
        prod_json, 
        ignore_order=True,                 # Ignore order in lists
        significant_digits=MATH_TOLERANCE_DIGITS, # Smart float comparison
        exclude_paths=IGNORED_PATHS        # Ignore timestamps/IDs
    )

    if not diff:
        return "MATCH", "Identical"
    
    # Format the difference into a readable string
    # DeepDiff returns a complex dict; we simplify it for Excel
    summary = []
    for reason, keys in diff.items():
        summary.append(f"{reason}: {keys}")
    
    return "MISMATCH", "\n".join(summary)

def generate_excel_report(results_data, output_path):
    """
    Main Entry Point.
    Converts execution results into a formatted Excel report.
    """
    if not results_data:
        print(" No results to compare.")
        return

    final_rows = []

    print(f"   -> Comparing {len(results_data)} result pairs...")

    for item in results_data:
        test_id = item['test_id']
        endpoint = item['endpoint']
        params = str(item['params'])
        
        dev_stat = item['dev_status']
        prod_stat = item['prod_status']
        dev_body = item['dev_response']
        prod_body = item['prod_response']
        error_msg = item['error']

        # 1. Check HTTP Status
        if error_msg:
            status = "EXECUTION ERROR"
            details = error_msg
        elif dev_stat != 200 or prod_stat != 200:
            status = "HTTP ERROR"
            details = f"Dev: {dev_stat}, Prod: {prod_stat}"
        else:
            # 2. Deep Compare JSONs
            status, details = get_diff_summary(dev_body, prod_body)

        # 3. Add row
        final_rows.append({
            "Test ID": test_id,
            "Endpoint": endpoint,
            "Parameters": params,
            "Result": status, # MATCH / MISMATCH / ERROR
            "Details": details,
            "Dev Status": dev_stat,
            "Prod Status": prod_stat,
            "Dev Response": json.dumps(dev_body)[:3000], # Truncate for Excel limits
            "Prod Response": json.dumps(prod_body)[:3000]
        })

    # 4. Save to Excel
    df = pd.DataFrame(final_rows)
    
    # Conditional Formatting Logic (Simulated by sorting/ordering)
    # We put Mismatches/Errors at the top so you see them first
    df.sort_values(by=['Result'], inplace=True, ascending=False) 

    try:
        df.to_excel(output_path, index=False)
    except Exception as e:
        print(f"    Error saving Excel report: {e}")

    # Print Summary to Console
    pass_count = len(df[df['Result'] == 'MATCH'])
    fail_count = len(df[df['Result'] == 'MISMATCH'])
    print(f"   -> Report Ready. Summary:  {pass_count} Passed | ❌ {fail_count} Failed")