import pandas as pd
import itertools
import os

def load_excel_config(file_path):
    """Safely loads an Excel file into a DataFrame."""
    if not os.path.exists(file_path):
        print(f" Warning: Config file not found: {file_path}")
        return pd.DataFrame() # Return empty if missing
    return pd.read_excel(file_path)

def parse_values(value_str):
    """
    Converts "A, B, C" string into list ['A', 'B', 'C'].
    Handles integers and floats correctly.
    """
    if pd.isna(value_str) or str(value_str).strip() == "":
        return []
    
    # Convert to string, split by comma, strip whitespace
    return [str(x).strip() for x in str(value_str).split(',') if str(x).strip()]

def create_test_matrix(endpoints_file, inclusion_file, exclusion_file):
    """
    Main Logic:
    1. Read the Scraped Endpoints (to get the base URLs).
    2. Read the Inclusion Rules (to get the Test Data).
    3. Generate Permutations (Cartesian Product).
    4. Filter Exclusions.
    """
    
    # 1. Load Data
    try:
        # We read the 'SOURCE' sheet to know what endpoints exist in Dev
        df_endpoints = pd.read_excel(endpoints_file, sheet_name='SOURCE')
        valid_endpoints = set(df_endpoints['Endpoint'].dropna().unique())
    except Exception as e:
        print(f" Error reading ExtractedEndPoints: {e}")
        return []

    df_inc = load_excel_config(inclusion_file)
    df_exc = load_excel_config(exclusion_file)

    if df_inc.empty:
        print(" Inclusion sheet is empty or missing. No tests generated.")
        return []

    # 2. Filter for "Run = Yes" in Inclusion Sheet
    # Structure expectation: Endpoint | Parameter | Values | Run
    runnable_rows = df_inc[df_inc['Run'].astype(str).str.lower() == 'yes']

    # Group by Endpoint because one endpoint might have multiple rows (one per parameter)
    # OR (simpler): One row per endpoint with multiple param columns? 
    # Let's assume the simpler "Vertical" format: 
    # Row 1: /api/v1 | tradeId | 100, 200
    # Row 2: /api/v1 | date    | 2023-01-01
    
    grouped = runnable_rows.groupby('Endpoint')
    
    test_cases = []

    print(f"   -> Processing {len(grouped)} target endpoints...")

    for endpoint, group in grouped:
        if endpoint not in valid_endpoints:
            print(f"   Skipping {endpoint} (Not found in Scraped Swagger)")
            continue

        # Dictionary to hold lists of values for each param
        # e.g., {'tradeId': ['100','200'], 'date': ['2023-01-01']}
        param_buckets = {}
        
        for index, row in group.iterrows():
            p_name = str(row['Parameter']).strip()
            p_vals = parse_values(row['Values'])
            
            if p_name and p_vals:
                param_buckets[p_name] = p_vals

        # If no params defined, just test the endpoint as is (if valid)
        if not param_buckets:
            test_cases.append({
                "test_id": f"TEST_{len(test_cases)+1:04d}",
                "endpoint": endpoint,
                "params": {},
                "url_suffix": endpoint # No params replaced
            })
            continue

        # 3. Generate Permutations (Cartesian Product)
        # keys: ['tradeId', 'date']
        # values: [['100','200'], ['2023-01-01']]
        keys = param_buckets.keys()
        values = param_buckets.values()
        
        # product: [('100', '2023-01-01'), ('200', '2023-01-01')]
        permutations = list(itertools.product(*values))

        for perm in permutations:
            # Create the param map for this specific test case
            current_params = dict(zip(keys, perm))
            
            # 4. Check Exclusion Logic
            # If this specific combo exists in Exclusion file, skip it
            # (Simple exclusion implementation: if Endpoint + Param + Value matches)
            is_excluded = False
            if not df_exc.empty:
                # This is a basic O(N) check. optimize later if needed.
                for p_key, p_val in current_params.items():
                    # Check if there is a row in Exclusion for this Endpoint + Param
                    match = df_exc[
                        (df_exc['Endpoint'] == endpoint) & 
                        (df_exc['Parameter'] == p_key)
                    ]
                    if not match.empty:
                        # Check if the value is in the excluded values string
                        for _, exc_row in match.iterrows():
                            excluded_vals = parse_values(exc_row['Values'])
                            if p_val in excluded_vals:
                                is_excluded = True
                                break
                    if is_excluded: break
            
            if is_excluded:
                continue

            # 5. Construct URL (Identify Path vs Query)
            # We need to know if '{param}' exists in the endpoint string
            final_url_suffix = endpoint
            query_params = {}

            for p_key, p_val in current_params.items():
                token = f"{{{p_key}}}" # e.g. {tradeId}
                if token in final_url_suffix:
                    # It is a PATH parameter -> Replace in string
                    final_url_suffix = final_url_suffix.replace(token, str(p_val))
                else:
                    # It is a QUERY parameter -> Add to dict
                    query_params[p_key] = str(p_val)

            # Add to Master List
            test_cases.append({
                "test_id": f"TEST_{len(test_cases)+1:04d}",
                "endpoint_original": endpoint,
                "url_suffix": final_url_suffix, # e.g. /risk/calc/100
                "query_params": query_params    # e.g. {'date': '2023-01-01'}
            })

    return test_cases