const PersonalDetails = require('../models/PersonalDetails');
const DemographicDetails = require('../models/DemographicDetails');


exports.savePersonalDetails = async (req, res) => {
  const { username, firstName, lastName, telephone, mobile, dob, maritalStatus } = req.body;
  try {
    const [details, created] = await PersonalDetails.findOrCreate({
      where: { username },
      defaults: { firstName, lastName, telephone, mobile, dob, maritalStatus }
    });

    if (!created) {
      await details.update({ firstName, lastName, telephone, mobile, dob, maritalStatus });
    }

    res.status(200).json({ message: 'Personal details saved successfully' });
  } catch (err) {
    console.error('Save error:', err);
    res.status(500).json({ error: 'Failed to save personal details' });
  }
};

exports.saveDemographicDetails = async (req, res) => {
  const { username, address1, address2, city, state, country, zipCode } = req.body;

  try {
    const [record, created] = await DemographicDetails.findOrCreate({
      where: { username },
      defaults: { address1, address2, city, state, country, zipCode }
    });

    if (!created) {
      await record.update({ address1, address2, city, state, country, zipCode });
    }

    res.status(200).json({ message: 'Demographic details saved successfully' });
  } catch (err) {
    console.error('Error saving demographic details:', err);
    res.status(500).json({ error: 'Failed to save demographic details' });
  }
};


