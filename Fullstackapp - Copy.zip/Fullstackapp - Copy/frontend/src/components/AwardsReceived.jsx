import React, { useState } from 'react';

function AwardsReceived() {
  const [awards, setAwards] = useState([]);
  const [award, setAward] = useState({ title: '', issuedBy: '' });

  const handleChange = (e) => {
    setAward({ ...award, [e.target.name]: e.target.value });
  };

  const handleAdd = () => {
    if (award.title && award.issuedBy) {
      setAwards([...awards, award]);
      setAward({ title: '', issuedBy: '' });
    }
  };

  const handleDelete = (index) => {
    const list = [...awards];
    list.splice(index, 1);
    setAwards(list);
  };

const handleSave = async () => {
  try {
    await axios.post('http://localhost:5000/api/profile/awards', {
      username,
      awards
    });
    alert('Awards saved!');
  } catch {
    alert('Save failed');
  }
};

  return (
    <form className="grid-form" onSubmit={(e) => e.preventDefault()}>
      <div className="form-field">
        <label>Award Title</label>
        <input name="title" value={award.title} onChange={handleChange} />
      </div>
      <div className="form-field">
        <label>Issued By</label>
        <input name="issuedBy" value={award.issuedBy} onChange={handleChange} />
      </div>

      <button type="button" className="full-width" onClick={handleAdd}>Add Award</button>

      {awards.map((item, index) => (
        <div className="full-width" key={index}>
          <p>{item.title} - {item.issuedBy}</p>
          <button type="button" onClick={() => handleDelete(index)}>Delete</button>
        </div>
      ))}
      <button type="submit" className="full-width" onClick={handleSave}>Save</button>
    </form>
  );
}

export default AwardsReceived;
