import React, { useEffect, useState } from 'react';
import axios from 'axios';

function WorkExperience() {
  const username = localStorage.getItem('username');
  const [experiences, setExperiences] = useState([]);
  const [exp, setExp] = useState({ company: '', designation: '', startDate: '', endDate: '' });

  useEffect(() => {
    axios.get(`http://localhost:5000/api/profile/work-experience/${username}`)
      .then(res => res.data && setExperiences(res.data))
      .catch(() => {});
  }, [username]);

  const handleChange = (e) => setExp({ ...exp, [e.target.name]: e.target.value });

  const handleAdd = () => {
    if (exp.company && exp.designation) {
      setExperiences([...experiences, exp]);
      setExp({ company: '', designation: '', startDate: '', endDate: '' });
    }
  };

  const handleDelete = (index) => {
    const list = [...experiences];
    list.splice(index, 1);
    setExperiences(list);
  };

  const handleSave = async () => {
    try {
      await axios.post('http://localhost:5000/api/profile/work-experience', {
        username,
        experiences
      });
      alert('Work Experience saved!');
    } catch (err) {
      alert('Save failed');
    }
  };

  return (
    <form className="grid-form" onSubmit={e => e.preventDefault()}>
      <div className="form-field">
        <label>Company Name</label>
        <input name="company" value={exp.company} onChange={handleChange} />
      </div>
      <div className="form-field">
        <label>Designation</label>
        <input name="designation" value={exp.designation} onChange={handleChange} />
      </div>
      <div className="form-field">
        <label>Start Date</label>
        <input type="date" name="startDate" value={exp.startDate} onChange={handleChange} />
      </div>
      <div className="form-field">
        <label>End Date</label>
        <input type="date" name="endDate" value={exp.endDate} onChange={handleChange} />
      </div>

      <button type="button" className="full-width" onClick={handleAdd}>Add Experience</button>

      {experiences.map((item, idx) => (
        <div className="full-width" key={idx}>
          <p><strong>{item.company}</strong> - {item.designation} ({item.startDate} to {item.endDate})</p>
          <button type="button" onClick={() => handleDelete(idx)}>Delete</button>
        </div>
      ))}

      <button type="submit" className="full-width" onClick={handleSave}>Save</button>
    </form>
  );
}

export default WorkExperience;
