import React, { useState, useEffect } from 'react';
import axios from 'axios';

function EducationDetails() {
  const [form, setForm] = useState({
    qualification: '',
    educationCountry: '',
    university: '',
    cgpa: ''
  });

  useEffect(() => {
    const username = localStorage.getItem('username');
    axios.get(`http://localhost:5000/api/profile/education/${username}`)
      .then(res => res.data && setForm(res.data))
      .catch(() => console.log('No education data found'));
  }, []);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSave = async (e) => {
    e.preventDefault();
    const username = localStorage.getItem('username');
    try {
      await axios.post('http://localhost:5000/api/profile/education', {
        username,
        ...form
      });
      alert('Education details saved!');
    } catch (err) {
      alert('Error saving education details');
    }
  };

  return (
    <form className="grid-form" onSubmit={handleSave}>
      <div className="form-field">
        <label>Highest Qualification</label>
        <input type="text" name="qualification" value={form.qualification} onChange={handleChange} />
      </div>
      <div className="form-field">
        <label>Country of Education</label>
        <input type="text" name="educationCountry" value={form.educationCountry} onChange={handleChange} />
      </div>
      <div className="form-field">
        <label>University</label>
        <input type="text" name="university" value={form.university} onChange={handleChange} />
      </div>
      <div className="form-field">
        <label>CGPA</label>
        <input type="text" name="cgpa" value={form.cgpa} onChange={handleChange} />
      </div>
      <button type="submit" className="full-width">Save</button>
    </form>
  );
}

export default EducationDetails;
