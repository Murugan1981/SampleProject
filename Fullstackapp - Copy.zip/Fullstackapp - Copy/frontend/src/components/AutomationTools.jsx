import React, { useState } from 'react';

function AutomationTools() {
  const [tools, setTools] = useState([]);
  const [tool, setTool] = useState({ name: '', level: '' });

  const handleChange = (e) => setTool({ ...tool, [e.target.name]: e.target.value });

  const handleAdd = () => {
    if (tool.name && tool.level) {
      setTools([...tools, tool]);
      setTool({ name: '', level: '' });
    }
  };

  const handleDelete = (index) => {
    const updated = [...tools];
    updated.splice(index, 1);
    setTools(updated);
  };

const handleSave = async () => {
  try {
    await axios.post('http://localhost:5000/api/profile/automation-tools', {
      username,
      tools
    });
    alert('Tools saved!');
  } catch {
    alert('Save failed');
  }
};

  return (
    <div className="grid-form">
      <div className="form-field">
        <label>Tool Name</label>
        <input name="name" value={tool.name} onChange={handleChange} />
      </div>
      <div className="form-field">
        <label>Expertise Level</label>
        <select name="level" value={tool.level} onChange={handleChange}>
          <option value="">Select</option>
          <option value="Expert">Expert</option>
          <option value="Very good">Very good</option>
          <option value="Intermediate">Intermediate</option>
          <option value="Able to use/code">Able to use/code</option>
        </select>
      </div>

      <button type="button" className="full-width" onClick={handleAdd}>Add Tool</button>

      {tools.map((item, idx) => (
        <div className="full-width" key={idx}>
          <p>{item.name} - {item.level}</p>
          <button type="button" onClick={() => handleDelete(idx)}>Delete</button>
        </div>
      ))}
       <button type="submit" className="full-width" onClick={handleSave}>Save</button>
    </div>
  );
}

export default AutomationTools;
