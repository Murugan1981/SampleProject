import React, { useState } from 'react';
import PersonalDetails from '../components/PersonalDetails';
import DemographicDetails from '../components/DemographicDetails';
import EducationDetails from '../components/EducationDetails';
import WorkExperience from '../components/WorkExperience';
import AutomationTools from '../components/AutomationTools';
import ProgrammingLanguages from '../components/ProgrammingLanguages';
import Certifications from '../components/Certifications';
import AwardsReceived from '../components/AwardsReceived';


const tabLabels = [
  "Personal Details", "Demographic Details", "Education Details", "Work Experience",
  "Automation Tools", "Programming Languages", "Certifications", "Awards Received",
  "Framework Knowledge", "Domain Experience", "AI Model Experience", "Extra Curricular Activities",
  "Hobbies", "Social Media Links", "Upload Profile Picture"
];

function MainForm() {
  const [activeTab, setActiveTab] = useState(0);
  const username = localStorage.getItem('username');

  const handleLogout = () => {
    localStorage.clear();
    window.location.href = '/login';
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 0:
        return <PersonalDetails />;
      case 1:
        return <DemographicDetails />;
      case 2:
        return <EducationDetails />;
      case 3:
        return <WorkExperience />;
      case 4:
        return <AutomationTools />; 
      case 5:
        return <ProgrammingLanguages />; 
      case 6:
        return <Certifications />; 
      case 7:
        return <AwardsReceived />;              
      default:
        return <p>[Form content for {tabLabels[activeTab]} will go here]</p>;
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh' }}>
      {/* Header */}
      <div style={{ background: '#007bff', padding: '10px 20px', color: 'white' }}>
        <span>Logged in as: <strong>{username}</strong></span>
        <button
          onClick={handleLogout}
          style={{
            float: 'right',
            background: 'white',
            color: '#007bff',
            border: 'none',
            padding: '6px 12px',
            borderRadius: '4px',
            cursor: 'pointer',
            fontWeight: 'bold'
          }}
        >
          Logout
        </button>
      </div>

      {/* Body layout: Sidebar + Form content */}
      <div style={{ display: 'flex', flexGrow: 1 }}>
        {/* Sidebar */}
        <div style={{
          minWidth: '220px',
          borderRight: '1px solid #ccc',
          backgroundColor: '#f1f1f1',
          height: '100%',
          overflowY: 'auto'
        }}>
          {tabLabels.map((label, index) => (
            <div
              key={index}
              onClick={() => setActiveTab(index)}
              style={{
                padding: '12px 16px',
                backgroundColor: activeTab === index ? '#d0ebff' : 'transparent',
                fontWeight: activeTab === index ? 'bold' : 'normal',
                borderLeft: activeTab === index ? '4px solid #007bff' : '4px solid transparent',
                cursor: 'pointer',
                transition: 'background-color 0.2s'
              }}
            >
              {label}
            </div>
          ))}
        </div>

        {/* Main Form Area */}
        <div style={{ padding: '30px', flexGrow: 1 }}>
          <h2>{tabLabels[activeTab]}</h2>
          {renderTabContent()}
        </div>
      </div>
    </div>
  );
}

export default MainForm;




// import React, { useState } from 'react';
// import PersonalDetails from '../components/PersonalDetails';
// import DemographicDetails from '../components/DemographicDetails';


// const tabLabels = [
//   "Personal Details", "Demographic Details", "Education Details", "Work Experience",
//   "Automation Tools", "Programming Languages", "Certifications", "Awards Received",
//   "Framework Knowledge", "Domain Experience", "AI Model Experience", "Extra Curricular Activities",
//   "Hobbies", "Social Media Links", "Upload Profile Picture"
// ];

// function MainForm() {
//   const [activeTab, setActiveTab] = useState(0);
//   const username = localStorage.getItem('username');

//   const handleLogout = () => {
//     localStorage.clear();
//     window.location.href = '/login';
//   };

//   const renderTabContent = () => {
//     switch (activeTab) {
//       case 0:
//         return <PersonalDetails />;
//       case 1:
//         return <DemographicDetails />;

//       default:
//         return <p>[Form content for {tabLabels[activeTab]} will go here]</p>;
//     }
//   };

//   return (
//     <div>
//       <div style={{ background: '#f2f2f2', padding: '10px' }}>
//         <span>Logged in as: <strong>{username}</strong></span>
//         <button style={{ float: 'right' }} onClick={handleLogout}>Logout</button>
//       </div>
//       <div style={{ display: 'flex' }}>
//         <div style={{ minWidth: '200px', borderRight: '1px solid gray' }}>
//           {tabLabels.map((label, index) => (
//             <div
//               key={index}
//               onClick={() => setActiveTab(index)}
//               style={{
//                 padding: '10px',
//                 backgroundColor: activeTab === index ? '#ddd' : '#fff',
//                 cursor: 'pointer'
//               }}
//             >
//               {label}
//             </div>
//           ))}
//         </div>
//         <div style={{ padding: '20px', width: '100%' }}>
//           <h2>{tabLabels[activeTab]}</h2>
//           {renderTabContent()}
//         </div>
//       </div>
//     </div>
//   );
// }

// export default MainForm;
