using System;
using System.Collections.Generic;
using System.IO;
using DotNetEnv;
using Newtonsoft.Json.Linq;
using CodeExtraction.App.Utilities;

namespace CodeExtraction.App.Models;

internal sealed class AppConfig
{
    private AppConfig(
        string prdUrl,
        string uatUrl,
        string username,
        string? password,
        string system,
        string region,
        string urlType,
        IReadOnlyDictionary<string, TagTestData> testData)
    {
        PrdTenantUrl = prdUrl;
        UatTenantUrl = uatUrl;
        Username = username;
        Password = password;
        SystemFilter = system;
        RegionFilter = region;
        UrlTypeFilter = urlType;
        TestData = testData;
    }

    public string PrdTenantUrl { get; }
    public string UatTenantUrl { get; }
    public string Username { get; }
    public string? Password { get; }
    public string SystemFilter { get; }
    public string RegionFilter { get; }
    public string UrlTypeFilter { get; }
    public IReadOnlyDictionary<string, TagTestData> TestData { get; }

    public static AppConfig Load()
    {
        PathProvider.EnsureSharedDirectories();
        LoadEnvFile();

        var prdUrl = ReadEnv("PRD_URL");
        var uatUrl = ReadEnv("UAT_URL");
        var username = ReadEnv("USERNAME");
        var password = Environment.GetEnvironmentVariable("PASSWORD");

        var testFile = Path.Combine(PathProvider.InputPath, "ApiTestData.json");
        if (!File.Exists(testFile))
        {
            throw new FileNotFoundException($"Input file not found: {testFile}");
        }

        var json = JObject.Parse(File.ReadAllText(testFile));
        var system = json.Value<string>("System") ?? string.Empty;
        var region = json.Value<string>("Region") ?? string.Empty;
        var urlType = json.Value<string>("URLTYPE") ?? string.Empty;
        var testDataToken = json["TestData"] as JObject ?? new JObject();

        var testData = new Dictionary<string, TagTestData>(StringComparer.OrdinalIgnoreCase);
        foreach (var property in testDataToken.Properties())
        {
            var values = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            var order = new List<string>();

            if (property.Value is JObject obj)
            {
                foreach (var child in obj.Properties())
                {
                    values[child.Name] = child.Value?.ToString() ?? string.Empty;
                    order.Add(child.Name);
                }
            }

            testData[property.Name] = new TagTestData(property.Name, values, order);
        }

        return new AppConfig(prdUrl, uatUrl, username, password, system, region, urlType, testData);
    }

    private static string ReadEnv(string key)
    {
        var value = Environment.GetEnvironmentVariable(key);
        if (string.IsNullOrWhiteSpace(value))
        {
            throw new InvalidOperationException($"Missing environment variable: {key}");
        }

        return value;
    }

    private static void LoadEnvFile()
    {
        var envPath = Path.Combine(PathProvider.CSharpRoot, ".env");
        if (File.Exists(envPath))
        {
            Env.Load(envPath);
        }
    }
}
