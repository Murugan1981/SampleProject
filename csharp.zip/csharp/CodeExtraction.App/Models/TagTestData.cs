using System.Collections.Generic;

namespace CodeExtraction.App.Models;

internal sealed class TagTestData
{
    public TagTestData(string tag, IReadOnlyDictionary<string, string> values, IReadOnlyList<string> keyOrder)
    {
        Tag = tag;
        Values = values;
        KeyOrder = keyOrder;
    }

    public string Tag { get; }
    public IReadOnlyDictionary<string, string> Values { get; }
    public IReadOnlyList<string> KeyOrder { get; }
}
