using System;
using System.Diagnostics;
using CodeExtraction.App.Models;
using CodeExtraction.App.Services;

var stopwatch = Stopwatch.StartNew();

try
{
    var config = AppConfig.Load();
    var authService = new AuthService(config);

    var tenantFetcher = new TenantFetcher(config, authService);
    var swaggerService = new SwaggerMetadataService(config, authService);
    var metadataComparer = new SwaggerMetadataComparer();
    var responseFetcher = new ResponseFetcher(config, authService);
    var responseComparer = new ResponseComparer(config);

    await tenantFetcher.FetchAndSaveAsync();
    await swaggerService.FetchAndStoreAsync();
    metadataComparer.Compare();
    await responseFetcher.FetchAndSaveAsync();
    responseComparer.Compare();

    Console.WriteLine($"Total Execution Time = {stopwatch.Elapsed.TotalSeconds:F2} seconds");
}
catch (Exception ex)
{
    Console.WriteLine($"Pipeline failed: {ex.Message}");
    Console.WriteLine(ex);
    Environment.ExitCode = -1;
}
