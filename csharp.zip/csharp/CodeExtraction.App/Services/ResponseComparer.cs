using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using ClosedXML.Excel;
using CodeExtraction.App.Models;
using CodeExtraction.App.Utilities;
using JsonDiffPatchDotNet;
using Newtonsoft.Json.Linq;

namespace CodeExtraction.App.Services;

internal sealed class ResponseComparer
{
    private readonly AppConfig _config;

    public ResponseComparer(AppConfig config)
    {
        _config = config;
    }

    public void Compare()
    {
        Console.WriteLine("Compare responses");
        var system = _config.SystemFilter;
        var inputFolder = Path.Combine(PathProvider.ReportsPath, $"{system}_OUTPUT");
        if (!Directory.Exists(inputFolder))
        {
            Console.WriteLine($"Response directory not found: {inputFolder}");
            return;
        }

        var files = Directory.EnumerateFiles(inputFolder, "*.json").ToList();
        var grouped = files
            .Select(ParseResponseFile)
            .Where(info => info != null)
            .Select(info => info!)
            .GroupBy(info => (info.Tag, info.Suffix))
            .ToDictionary(g => g.Key, g => g.ToList());

        var jdp = new JsonDiffPatch();
        var log = new List<ResponseComparisonRow>();

        foreach (var group in grouped)
        {
            var prd = group.Value.FirstOrDefault(f => f.Environment.Equals("PRD", StringComparison.OrdinalIgnoreCase));
            var uat = group.Value.FirstOrDefault(f => f.Environment.Equals("UAT", StringComparison.OrdinalIgnoreCase));

            if (prd == null || uat == null)
            {
                log.Add(new ResponseComparisonRow(group.Key.Tag, group.Key.Suffix, "MISSING", $"{(prd == null ? "PRD" : "UAT")} file missing"));
                continue;
            }

            try
            {
                var prdJson = JToken.Parse(File.ReadAllText(prd.Path));
                var uatJson = JToken.Parse(File.ReadAllText(uat.Path));
                var diff = jdp.Diff(prdJson, uatJson);
                var isMatch = diff == null || diff.Type == JTokenType.Null;
                log.Add(new ResponseComparisonRow(group.Key.Tag, group.Key.Suffix, isMatch ? "MATCH" : "MISMATCH", isMatch ? string.Empty : diff!.ToString(Newtonsoft.Json.Formatting.None)));
            }
            catch (Exception ex)
            {
                log.Add(new ResponseComparisonRow(group.Key.Tag, group.Key.Suffix, "ERROR", ex.Message));
            }
        }

        WriteLog(system, log);
    }

    private static ResponseFileInfo? ParseResponseFile(string path)
    {
        var fileName = Path.GetFileNameWithoutExtension(path);
        var parts = fileName.Split('_');
        if (parts.Length < 3)
        {
            return null;
        }

        var env = parts[^1].ToUpperInvariant();
        var tag = parts[0];
        var suffix = string.Join("_", parts.Skip(1).Take(parts.Length - 2));
        return new ResponseFileInfo(tag, suffix, env, path);
    }

    private static void WriteLog(string system, IReadOnlyList<ResponseComparisonRow> log)
    {
        var outputPath = Path.Combine(PathProvider.ReportsPath, $"{system}_Response_comparison.xlsx");
        using var workbook = new XLWorkbook();
        var sheet = workbook.Worksheets.Add("Comparison");
        sheet.Cell(1, 1).Value = "Tag";
        sheet.Cell(1, 2).Value = "Key";
        sheet.Cell(1, 3).Value = "Comparison";
        sheet.Cell(1, 4).Value = "Detail";

        var rowIndex = 2;
        foreach (var entry in log)
        {
            sheet.Cell(rowIndex, 1).Value = entry.Tag;
            sheet.Cell(rowIndex, 2).Value = entry.Key;
            sheet.Cell(rowIndex, 3).Value = entry.Comparison;
            sheet.Cell(rowIndex, 4).Value = entry.Detail;
            rowIndex++;
        }

        sheet.Columns().AdjustToContents();
        workbook.SaveAs(outputPath);
    }

    private sealed record ResponseFileInfo(string Tag, string Suffix, string Environment, string Path);

    private sealed record ResponseComparisonRow(string Tag, string Key, string Comparison, string Detail);
}
