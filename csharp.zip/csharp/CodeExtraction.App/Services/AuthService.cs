using System;
using System.Net;
using System.Net.Http;
using CodeExtraction.App.Models;

namespace CodeExtraction.App.Services;

internal sealed class AuthService
{
    private readonly string _username;
    private readonly string _password;

    public AuthService(AppConfig config)
    {
        _username = config.Username;
        _password = ResolvePassword(config.Password);
    }

    public HttpClient CreateHttpClient(TimeSpan? timeout = null)
    {
        var handler = new HttpClientHandler
        {
            Credentials = new NetworkCredential(_username, _password),
            PreAuthenticate = true,
            UseDefaultCredentials = false
        };

        handler.ServerCertificateCustomValidationCallback = HttpClientHandler.DangerousAcceptAnyServerCertificateValidator;

        var client = new HttpClient(handler, disposeHandler: true)
        {
            Timeout = timeout ?? TimeSpan.FromSeconds(60)
        };

        return client;
    }

    private static string ResolvePassword(string? provided)
    {
        if (!string.IsNullOrWhiteSpace(provided))
        {
            return provided;
        }

        Console.Write("Enter NTLM password: ");
        var password = ReadPasswordFromConsole();
        Console.WriteLine();
        return password;
    }

    private static string ReadPasswordFromConsole()
    {
        var password = string.Empty;
        ConsoleKeyInfo key;
        do
        {
            key = Console.ReadKey(intercept: true);
            if (key.Key == ConsoleKey.Backspace && password.Length > 0)
            {
                password = password[..^1];
                Console.Write("\b \b");
            }
            else if (!char.IsControl(key.KeyChar))
            {
                password += key.KeyChar;
                Console.Write("*");
            }
        } while (key.Key != ConsoleKey.Enter);

        if (string.IsNullOrEmpty(password))
        {
            throw new InvalidOperationException("Password is required to call the APIs.");
        }

        return password;
    }
}
