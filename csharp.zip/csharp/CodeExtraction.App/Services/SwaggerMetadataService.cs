using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using ClosedXML.Excel;
using CodeExtraction.App.Models;
using CodeExtraction.App.Utilities;
using Newtonsoft.Json.Linq;

namespace CodeExtraction.App.Services;

internal sealed class SwaggerMetadataService
{
    private readonly AppConfig _config;
    private readonly AuthService _authService;

    public SwaggerMetadataService(AppConfig config, AuthService authService)
    {
        _config = config;
        _authService = authService;
    }

    public async Task FetchAndStoreAsync()
    {
        Console.WriteLine("Comparing Swagger Metadata for PRD vs UAT URLs");
        var (prdRows, prdErrors) = await ProcessSheetAsync("PRD");
        var (uatRows, uatErrors) = await ProcessSheetAsync("UAT");

        using var workbook = new XLWorkbook(PathProvider.SwaggerFilePath);
        WriteMetadataSheet(workbook, "PRD_Metadata", prdRows);
        WriteMetadataSheet(workbook, "UAT_Metadata", uatRows);

        if (prdErrors.Count > 0)
        {
            WriteErrorSheet(workbook, "PRD_Metadata_Error", prdErrors);
        }
        else
        {
            RemoveSheetIfExists(workbook, "PRD_Metadata_Error");
        }

        if (uatErrors.Count > 0)
        {
            WriteErrorSheet(workbook, "UAT_Metadata_Error", uatErrors);
        }
        else
        {
            RemoveSheetIfExists(workbook, "UAT_Metadata_Error");
        }

        workbook.Save();
        Console.WriteLine($"Extracted metadata and errors saved to {PathProvider.SwaggerFilePath}");
    }

    private async Task<(List<SwaggerMetadataRow>, List<SwaggerMetadataError>)> ProcessSheetAsync(string sheetName)
    {
        var results = new List<SwaggerMetadataRow>();
        var errors = new List<SwaggerMetadataError>();

        using var workbook = new XLWorkbook(PathProvider.SwaggerFilePath);
        var worksheet = workbook.Worksheet(sheetName);
        if (worksheet == null)
        {
            throw new InvalidOperationException($"Worksheet '{sheetName}' not found in Swagger.xlsx");
        }

        var dataRows = WorksheetToDictionaryRows(worksheet);
        using var client = _authService.CreateHttpClient();

        foreach (var row in dataRows)
        {
            var system = row.GetValueOrDefault("SYSTEM")?.Trim() ?? string.Empty;
            var region = row.GetValueOrDefault("REGION")?.Trim() ?? string.Empty;
            var urlType = row.GetValueOrDefault("URLTYPE")?.Trim() ?? string.Empty;
            var baseUrl = (row.GetValueOrDefault("BASEURL") ?? string.Empty).Trim();

            if (!MatchesFilter(system, region, urlType))
            {
                continue;
            }

            if (string.IsNullOrWhiteSpace(baseUrl) || baseUrl.Equals("nan", StringComparison.OrdinalIgnoreCase))
            {
                Console.WriteLine($"Skipping base URL -> ({baseUrl}) / blank URL for {system} | {region} | {urlType}");
                continue;
            }

            var normalized = baseUrl.TrimEnd('/');
            var fullUrl = system.Equals("jil", StringComparison.OrdinalIgnoreCase)
                ? $"{normalized}/swagger/docs/v1"
                : $"{normalized}/swagger/v1/swagger.json";

            Console.WriteLine($"Fetching Swagger for {system} | {region} | {urlType}");
            var (endpoints, error) = await ExtractEndpointsAsync(client, normalized, fullUrl, system, region, sheetName, urlType);
            if (error != null)
            {
                errors.Add(error);
            }
            else
            {
                results.AddRange(endpoints);
            }
        }

        return (results, errors);
    }

    private static Dictionary<string, string?>[] WorksheetToDictionaryRows(IXLWorksheet worksheet)
    {
        var range = worksheet.RangeUsed();
        if (range == null)
        {
            return Array.Empty<Dictionary<string, string?>>();
        }

        var headerRow = range.FirstRow();
        var headers = headerRow.Cells()
            .Where(c => !string.IsNullOrWhiteSpace(c.GetString()))
            .Select((cell, index) => new { index, name = cell.GetString().Trim().ToUpperInvariant() })
            .ToList();

        var rows = new List<Dictionary<string, string?>>();
        foreach (var row in range.RowsUsed().Skip(1))
        {
            var dict = new Dictionary<string, string?>();
            foreach (var header in headers)
            {
                dict[header.name] = row.Cell(header.index + 1).GetString();
            }

            rows.Add(dict);
        }

        return rows.ToArray();
    }

    private bool MatchesFilter(string system, string region, string urlType)
    {
        return string.Equals(system, _config.SystemFilter, StringComparison.OrdinalIgnoreCase)
               && string.Equals(region, _config.RegionFilter, StringComparison.OrdinalIgnoreCase)
               && string.Equals(urlType, _config.UrlTypeFilter, StringComparison.OrdinalIgnoreCase);
    }

    private static async Task<(List<SwaggerMetadataRow>, SwaggerMetadataError?)> ExtractEndpointsAsync(
        HttpClient client,
        string baseUrl,
        string swaggerUrl,
        string system,
        string region,
        string env,
        string urlType)
    {
        try
        {
            var response = await client.GetAsync(swaggerUrl);
            if (!response.IsSuccessStatusCode)
            {
                var err = $"HTTP {(int)response.StatusCode}";
                Console.WriteLine($"Failed to fetch: {swaggerUrl} [{(int)response.StatusCode}]");
                return (new List<SwaggerMetadataRow>(), new SwaggerMetadataError(system, region, env, swaggerUrl, urlType, err));
            }

            var payload = await response.Content.ReadAsStringAsync();
            var document = JObject.Parse(payload);
            var paths = document["paths"] as JObject ?? new JObject();
            var rows = new List<SwaggerMetadataRow>();

            foreach (var path in paths.Properties())
            {
                if (path.Value is not JObject methods)
                {
                    continue;
                }

                foreach (var method in methods.Properties())
                {
                    if (method.Value is not JObject details)
                    {
                        continue;
                    }

                    var tags = details["tags"] is JArray tagsArray ? tagsArray.First?.ToString() ?? string.Empty : string.Empty;
                    var parameters = FlattenParameters(details["parameters"] as JArray);
                    var responses = details["responses"] as JObject ?? new JObject();
                    var responseProp = responses.Properties().FirstOrDefault();
                    var responseCode = responseProp?.Name ?? string.Empty;
                    var responseDescription = responseProp?.Value?["description"]?.ToString() ?? string.Empty;

                    rows.Add(new SwaggerMetadataRow(
                        system,
                        region,
                        env,
                        baseUrl,
                        swaggerUrl,
                        urlType,
                        method.Name.ToUpperInvariant(),
                        path.Name,
                        tags,
                        responseCode,
                        responseDescription,
                        parameters));
                }
            }

            return (rows, null);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error fetching {swaggerUrl}: {ex.Message}");
            var error = new SwaggerMetadataError(system, region, env, swaggerUrl, urlType, ex.Message);
            return (new List<SwaggerMetadataRow>(), error);
        }
    }

    private static string FlattenParameters(JArray? parameters)
    {
        if (parameters == null || parameters.Count == 0)
        {
            return string.Empty;
        }

        var parts = new List<string>();
        foreach (var param in parameters.OfType<JObject>())
        {
            var name = param.Value<string>("name") ?? string.Empty;
            var location = param.Value<string>("in") ?? string.Empty;
            var schemaType = param["schema"]?["type"]?.ToString() ?? "object";
            var required = param.Value<bool?>("required") ?? false;
            parts.Add($"{name} (in:{location},type:{schemaType},required:{required})");
        }

        return string.Join("; ", parts);
    }

    private static void WriteMetadataSheet(XLWorkbook workbook, string sheetName, IReadOnlyList<SwaggerMetadataRow> rows)
    {
        RemoveSheetIfExists(workbook, sheetName);
        var sheet = workbook.Worksheets.Add(sheetName);
        var columns = new[]
        {
            "System",
            "Region",
            "Env",
            "BASEURL",
            "SwaggerURL",
            "URLTYPE",
            "Method",
            "Endpoint",
            "Tags",
            "Response_Code",
            "Response_Description",
            "Parameters"
        };

        for (var i = 0; i < columns.Length; i++)
        {
            sheet.Cell(1, i + 1).Value = columns[i];
        }

        var rowIndex = 2;
        foreach (var row in rows)
        {
            sheet.Cell(rowIndex, 1).Value = row.System;
            sheet.Cell(rowIndex, 2).Value = row.Region;
            sheet.Cell(rowIndex, 3).Value = row.Env;
            sheet.Cell(rowIndex, 4).Value = row.BaseUrl;
            sheet.Cell(rowIndex, 5).Value = row.SwaggerUrl;
            sheet.Cell(rowIndex, 6).Value = row.UrlType;
            sheet.Cell(rowIndex, 7).Value = row.Method;
            sheet.Cell(rowIndex, 8).Value = row.Endpoint;
            sheet.Cell(rowIndex, 9).Value = row.Tags;
            sheet.Cell(rowIndex, 10).Value = row.ResponseCode;
            sheet.Cell(rowIndex, 11).Value = row.ResponseDescription;
            sheet.Cell(rowIndex, 12).Value = row.Parameters;
            rowIndex++;
        }

        sheet.Columns().AdjustToContents();
    }

    private static void WriteErrorSheet(XLWorkbook workbook, string sheetName, IReadOnlyList<SwaggerMetadataError> rows)
    {
        RemoveSheetIfExists(workbook, sheetName);
        var sheet = workbook.Worksheets.Add(sheetName);
        var columns = new[]
        {
            "System",
            "Region",
            "Env",
            "SwaggerURL",
            "URLTYPE",
            "Error"
        };

        for (var i = 0; i < columns.Length; i++)
        {
            sheet.Cell(1, i + 1).Value = columns[i];
        }

        var rowIndex = 2;
        foreach (var row in rows)
        {
            sheet.Cell(rowIndex, 1).Value = row.System;
            sheet.Cell(rowIndex, 2).Value = row.Region;
            sheet.Cell(rowIndex, 3).Value = row.Env;
            sheet.Cell(rowIndex, 4).Value = row.SwaggerUrl;
            sheet.Cell(rowIndex, 5).Value = row.UrlType;
            sheet.Cell(rowIndex, 6).Value = row.Error;
            rowIndex++;
        }

        sheet.Columns().AdjustToContents();
    }

    private static void RemoveSheetIfExists(XLWorkbook workbook, string sheetName)
    {
        var sheet = workbook.Worksheets.FirstOrDefault(ws => ws.Name.Equals(sheetName, StringComparison.OrdinalIgnoreCase));
        if (sheet != null)
        {
            sheet.Delete();
        }
    }

    private sealed record SwaggerMetadataRow(
        string System,
        string Region,
        string Env,
        string BaseUrl,
        string SwaggerUrl,
        string UrlType,
        string Method,
        string Endpoint,
        string Tags,
        string ResponseCode,
        string ResponseDescription,
        string Parameters);

    private sealed record SwaggerMetadataError(
        string System,
        string Region,
        string Env,
        string SwaggerUrl,
        string UrlType,
        string Error);
}
