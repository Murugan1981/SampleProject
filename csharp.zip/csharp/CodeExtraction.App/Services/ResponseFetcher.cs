using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using ClosedXML.Excel;
using CodeExtraction.App.Models;
using CodeExtraction.App.Utilities;

namespace CodeExtraction.App.Services;

internal sealed class ResponseFetcher
{
    private static readonly Regex PlaceholderRegex = new(@"\{([^{}\s]+)\}", RegexOptions.Compiled);

    private readonly AppConfig _config;
    private readonly AuthService _authService;

    public ResponseFetcher(AppConfig config, AuthService authService)
    {
        _config = config;
        _authService = authService;
    }

    public async Task FetchAndSaveAsync()
    {
        Console.WriteLine("Extract and Save Response");
        var rows = LoadComparisonRows();

        var filtered = rows.Where(IsEligibleRow).ToList();
        var outputFolder = Path.Combine(PathProvider.ReportsPath, $"{_config.SystemFilter}_OUTPUT");
        Directory.CreateDirectory(outputFolder);
        CleanOldJson(outputFolder);

        var errorPath = Path.Combine(PathProvider.ReportsPath, "Response_Error.xlsx");
        if (File.Exists(errorPath))
        {
            File.Delete(errorPath);
        }

        var errorLog = new List<ResponseErrorRow>();
        using var client = _authService.CreateHttpClient(TimeSpan.FromSeconds(30));

        foreach (var row in filtered)
        {
            var tag = row.GetValueOrDefault("Tags")?.Trim() ?? string.Empty;
            var endpointTemplate = row.GetValueOrDefault("Endpoint") ?? string.Empty;

            foreach (var env in new[] { "PRD", "UAT" })
            {
                var baseKey = $"BASEURL_{env}";
                var baseUrl = row.GetValueOrDefault(baseKey)?.Trim().TrimEnd('/') ?? string.Empty;
                if (string.IsNullOrWhiteSpace(baseUrl))
                {
                    errorLog.Add(new ResponseErrorRow(_config.SystemFilter, _config.RegionFilter, env, tag, endpointTemplate, string.Empty, $"Missing {baseKey}"));
                    continue;
                }

                var (url, missing, error) = BuildUrl(baseUrl, endpointTemplate, tag);
                if (error != null)
                {
                    errorLog.Add(new ResponseErrorRow(_config.SystemFilter, _config.RegionFilter, env, tag, endpointTemplate, string.Join(", ", missing), error));
                    continue;
                }

                try
                {
                    using var response = await client.GetAsync(url);
                    if (response.IsSuccessStatusCode)
                    {
                        var body = await response.Content.ReadAsStringAsync();
                        var tagData = ResolveTagData(tag) ?? throw new InvalidOperationException("Test data missing during response save.");
                        var suffix = BuildSuffix(tagData);
                        var filename = $"{tag}_{suffix}_{env}.json".Replace(" ", string.Empty, StringComparison.Ordinal);
                        var fullPath = Path.Combine(outputFolder, filename);
                        await File.WriteAllTextAsync(fullPath, body);
                    }
                    else
                    {
                        errorLog.Add(new ResponseErrorRow(_config.SystemFilter, _config.RegionFilter, env, tag, url!, string.Empty, $"HTTP {(int)response.StatusCode}: {response.ReasonPhrase}"));
                    }
                }
                catch (Exception ex)
                {
                    errorLog.Add(new ResponseErrorRow(_config.SystemFilter, _config.RegionFilter, env, tag, url ?? endpointTemplate, string.Empty, $"EXCEPTION: {ex.Message}"));
                }
            }
        }

        if (errorLog.Count > 0)
        {
            WriteErrors(errorPath, errorLog);
        }
    }

    private static List<Dictionary<string, string?>> LoadComparisonRows()
    {
        if (!File.Exists(PathProvider.MetadataComparisonPath))
        {
            throw new FileNotFoundException($"Comparison file not found: {PathProvider.MetadataComparisonPath}");
        }

        using var workbook = new XLWorkbook(PathProvider.MetadataComparisonPath);
        var worksheet = workbook.Worksheet("PRD_vs_UAT_Metadata") ?? throw new InvalidOperationException("Worksheet 'PRD_vs_UAT_Metadata' not found.");
        return WorksheetToRows(worksheet);
    }

    private static List<Dictionary<string, string?>> WorksheetToRows(IXLWorksheet worksheet)
    {
        var range = worksheet.RangeUsed();
        if (range == null)
        {
            return new List<Dictionary<string, string?>>();
        }

        var headers = range.FirstRow().Cells().Select((cell, index) => new
        {
            Name = cell.GetString().Trim(),
            Index = index + 1
        }).ToList();

        var rows = new List<Dictionary<string, string?>>();
        foreach (var row in range.RowsUsed().Skip(1))
        {
            var dict = new Dictionary<string, string?>();
            foreach (var header in headers)
            {
                dict[header.Name] = row.Cell(header.Index).GetString();
            }

            rows.Add(dict);
        }

        return rows;
    }

    private bool IsEligibleRow(Dictionary<string, string?> row)
    {
        return string.Equals(row.GetValueOrDefault("System"), _config.SystemFilter, StringComparison.OrdinalIgnoreCase)
               && string.Equals(row.GetValueOrDefault("Region"), _config.RegionFilter, StringComparison.OrdinalIgnoreCase)
               && string.Equals(row.GetValueOrDefault("URLTYPE"), _config.UrlTypeFilter, StringComparison.OrdinalIgnoreCase)
               && string.Equals(row.GetValueOrDefault("_merge"), "Present in both", StringComparison.OrdinalIgnoreCase)
               && string.Equals(row.GetValueOrDefault("Method"), "GET", StringComparison.OrdinalIgnoreCase)
               && IsTrue(row.GetValueOrDefault("Response_Code Match?"))
               && IsTrue(row.GetValueOrDefault("Response_Description Match?"))
               && IsTrue(row.GetValueOrDefault("Parameters Match?"))
               && IsTrue(row.GetValueOrDefault("Overall Match?"));
    }

    private static bool IsTrue(string? value)
    {
        return string.Equals(value, "true", StringComparison.OrdinalIgnoreCase) || value == bool.TrueString;
    }

    private (string? Url, IReadOnlyList<string> Missing, string? Error) BuildUrl(string baseUrl, string endpointTemplate, string tag)
    {
        var tagData = ResolveTagData(tag);
        if (tagData == null)
        {
            return (null, Array.Empty<string>(), "INPUT TEST DATA MISSING");
        }

        var placeholders = PlaceholderRegex.Matches(endpointTemplate)
            .Select(m => m.Groups[1].Value)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

        var missing = placeholders
            .Where(p => !tagData.Values.TryGetValue(p, out var value) || string.IsNullOrWhiteSpace(value))
            .ToList();

        if (missing.Count > 0)
        {
            return (null, missing, "INPUT TEST DATA MISSING");
        }

        try
        {
            var formattedEndpoint = PlaceholderRegex.Replace(endpointTemplate, match =>
            {
                var key = match.Groups[1].Value;
                return tagData.Values.TryGetValue(key, out var value) ? value : match.Value;
            });

            var fullUrl = $"{baseUrl}{formattedEndpoint}";
            return (fullUrl, Array.Empty<string>(), null);
        }
        catch (Exception ex)
        {
            return (null, Array.Empty<string>(), $"REQUEST FORMAT ERROR: {ex.Message}");
        }
    }

    private TagTestData? ResolveTagData(string tag)
    {
        if (_config.TestData.TryGetValue(tag, out var tagData))
        {
            return tagData;
        }

        return _config.TestData.TryGetValue("default", out var fallback) ? fallback : null;
    }

    private static string BuildSuffix(TagTestData tagData)
    {
        return tagData.KeyOrder.Count > 0
            ? string.Join("-", tagData.KeyOrder)
            : "default";
    }

    private static void CleanOldJson(string folder)
    {
        foreach (var file in Directory.EnumerateFiles(folder, "*.json"))
        {
            File.Delete(file);
        }
    }

    private static void WriteErrors(string path, IReadOnlyList<ResponseErrorRow> errors)
    {
        using var workbook = new XLWorkbook();
        var sheet = workbook.Worksheets.Add("Errors");
        var columns = new[]
        {
            "System",
            "Region",
            "Env",
            "Tag",
            "Endpoint",
            "Missing_variables",
            "Error"
        };

        for (var i = 0; i < columns.Length; i++)
        {
            sheet.Cell(1, i + 1).Value = columns[i];
        }

        var rowIndex = 2;
        foreach (var error in errors)
        {
            sheet.Cell(rowIndex, 1).Value = error.System;
            sheet.Cell(rowIndex, 2).Value = error.Region;
            sheet.Cell(rowIndex, 3).Value = error.Env;
            sheet.Cell(rowIndex, 4).Value = error.Tag;
            sheet.Cell(rowIndex, 5).Value = error.Endpoint;
            sheet.Cell(rowIndex, 6).Value = error.MissingVariables;
            sheet.Cell(rowIndex, 7).Value = error.Error;
            rowIndex++;
        }

        sheet.Columns().AdjustToContents();
        workbook.SaveAs(path);
    }

    private sealed record ResponseErrorRow(
        string System,
        string Region,
        string Env,
        string Tag,
        string Endpoint,
        string MissingVariables,
        string Error);
}
