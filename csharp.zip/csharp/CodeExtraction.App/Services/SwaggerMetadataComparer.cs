using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using ClosedXML.Excel;
using CodeExtraction.App.Utilities;

namespace CodeExtraction.App.Services;

internal sealed class SwaggerMetadataComparer
{
    private static readonly Regex BaseUrlRegex = new(@"://a[pt]w-", RegexOptions.IgnoreCase | RegexOptions.Compiled);
    private static readonly Regex HostSuffixRegex = new(@"\.uk\.mizuho-sc\.com", RegexOptions.IgnoreCase | RegexOptions.Compiled);

    public void Compare()
    {
        Console.WriteLine("Compare PRD vs UAT Metadata");
        var prdRecords = ReadMetadata("PRD_Metadata");
        var uatRecords = ReadMetadata("UAT_Metadata");
        var merged = MergeRecords(prdRecords, uatRecords);
        WriteComparison(merged);
    }

    private static IReadOnlyList<MetadataRecord> ReadMetadata(string sheetName)
    {
        using var workbook = new XLWorkbook(PathProvider.SwaggerFilePath);
        var worksheet = workbook.Worksheet(sheetName);
        if (worksheet == null)
        {
            throw new InvalidOperationException($"Worksheet '{sheetName}' not found in Swagger.xlsx");
        }

        var range = worksheet.RangeUsed();
        if (range == null)
        {
            return Array.Empty<MetadataRecord>();
        }

        var header = range.FirstRow().Cells().Select((cell, index) => new
        {
            Name = cell.GetString().Trim(),
            Index = index + 1
        }).ToList();

        var lookup = header.ToDictionary(h => h.Name, h => h.Index);

        var records = new List<MetadataRecord>();
        foreach (var row in range.RowsUsed().Skip(1))
        {
            var record = new MetadataRecord(
                Get(row, lookup, "System"),
                Get(row, lookup, "Region"),
                Get(row, lookup, "URLTYPE"),
                Get(row, lookup, "BASEURL"),
                Get(row, lookup, "SwaggerURL"),
                Get(row, lookup, "Method"),
                Get(row, lookup, "Endpoint"),
                Get(row, lookup, "Tags"),
                Get(row, lookup, "Response_Code"),
                Get(row, lookup, "Response_Description"),
                Get(row, lookup, "Parameters"),
                sheetName);

            records.Add(record);
        }

        return records;
    }

    private static string Get(IXLRangeRow row, Dictionary<string, int> lookup, string column)
    {
        return lookup.TryGetValue(column, out var index) ? row.Cell(index).GetString() : string.Empty;
    }

    private static IReadOnlyList<ComparisonRow> MergeRecords(
        IReadOnlyList<MetadataRecord> prdRecords,
        IReadOnlyList<MetadataRecord> uatRecords)
    {
        var prdLookup = prdRecords.ToDictionary(r => r.Key, StringComparer.OrdinalIgnoreCase);
        var uatLookup = uatRecords.ToDictionary(r => r.Key, StringComparer.OrdinalIgnoreCase);

        var keys = new HashSet<string>(prdLookup.Keys, StringComparer.OrdinalIgnoreCase);
        keys.UnionWith(uatLookup.Keys);

        var rows = new List<ComparisonRow>();

        foreach (var key in keys)
        {
            prdLookup.TryGetValue(key, out var prd);
            uatLookup.TryGetValue(key, out var uat);

            var mergeStatus = (prd != null, uat != null) switch
            {
                (true, true) => "Present in both",
                (true, false) => "PRD only",
                (false, true) => "UAT only",
                _ => "Missing"
            };

            var responseCodeMatch = CompareField(prd?.ResponseCode, uat?.ResponseCode);
            var responseDescMatch = CompareField(prd?.ResponseDescription, uat?.ResponseDescription);
            var parametersMatch = CompareField(prd?.Parameters, uat?.Parameters);
            var overallMatch = (responseCodeMatch.IsMatch && responseDescMatch.IsMatch && parametersMatch.IsMatch) ? "True" : "False";

            rows.Add(new ComparisonRow(
                prd?.System ?? uat?.System ?? string.Empty,
                prd?.Region ?? uat?.Region ?? string.Empty,
                prd?.UrlType ?? uat?.UrlType ?? string.Empty,
                prd?.BaseUrl ?? string.Empty,
                uat?.BaseUrl ?? string.Empty,
                prd?.SwaggerUrl ?? string.Empty,
                uat?.SwaggerUrl ?? string.Empty,
                prd?.Method ?? uat?.Method ?? string.Empty,
                prd?.Endpoint ?? uat?.Endpoint ?? string.Empty,
                prd?.Tags ?? uat?.Tags ?? string.Empty,
                prd?.ResponseCode ?? string.Empty,
                uat?.ResponseCode ?? string.Empty,
                prd?.ResponseDescription ?? string.Empty,
                uat?.ResponseDescription ?? string.Empty,
                prd?.Parameters ?? string.Empty,
                uat?.Parameters ?? string.Empty,
                responseCodeMatch.Display,
                responseDescMatch.Display,
                parametersMatch.Display,
                overallMatch,
                mergeStatus,
                prd?.NormalizedBaseUrl ?? uat?.NormalizedBaseUrl ?? string.Empty));
        }

        return rows;
    }

    private static (string Display, bool IsMatch) CompareField(string? prdValue, string? uatValue)
    {
        if (prdValue == null || uatValue == null)
        {
            return ("Field Missing", false);
        }

        var isMatch = string.Equals(prdValue, uatValue, StringComparison.Ordinal);
        return (isMatch ? "True" : "False", isMatch);
    }

    private static void WriteComparison(IReadOnlyList<ComparisonRow> rows)
    {
        using var workbook = new XLWorkbook();
        var sheet = workbook.Worksheets.Add("PRD_vs_UAT_Metadata");

        var columns = new[]
        {
            "System",
            "Region",
            "URLTYPE",
            "BASEURL_PRD",
            "BASEURL_UAT",
            "SwaggerURL_PRD",
            "SwaggerURL_UAT",
            "Method",
            "Endpoint",
            "Tags",
            "Response_Code_PRD",
            "Response_Code_UAT",
            "Response_Description_PRD",
            "Response_Description_UAT",
            "Parameters_PRD",
            "Parameters_UAT",
            "Response_Code Match?",
            "Response_Description Match?",
            "Parameters Match?",
            "Overall Match?",
            "_merge",
            "NormalizedBASEURL"
        };

        for (var i = 0; i < columns.Length; i++)
        {
            sheet.Cell(1, i + 1).Value = columns[i];
        }

        var rowIndex = 2;
        foreach (var row in rows)
        {
            sheet.Cell(rowIndex, 1).Value = row.System;
            sheet.Cell(rowIndex, 2).Value = row.Region;
            sheet.Cell(rowIndex, 3).Value = row.UrlType;
            sheet.Cell(rowIndex, 4).Value = row.BaseUrlPrd;
            sheet.Cell(rowIndex, 5).Value = row.BaseUrlUat;
            sheet.Cell(rowIndex, 6).Value = row.SwaggerUrlPrd;
            sheet.Cell(rowIndex, 7).Value = row.SwaggerUrlUat;
            sheet.Cell(rowIndex, 8).Value = row.Method;
            sheet.Cell(rowIndex, 9).Value = row.Endpoint;
            sheet.Cell(rowIndex, 10).Value = row.Tags;
            sheet.Cell(rowIndex, 11).Value = row.ResponseCodePrd;
            sheet.Cell(rowIndex, 12).Value = row.ResponseCodeUat;
            sheet.Cell(rowIndex, 13).Value = row.ResponseDescriptionPrd;
            sheet.Cell(rowIndex, 14).Value = row.ResponseDescriptionUat;
            sheet.Cell(rowIndex, 15).Value = row.ParametersPrd;
            sheet.Cell(rowIndex, 16).Value = row.ParametersUat;
            sheet.Cell(rowIndex, 17).Value = row.ResponseCodeMatch;
            sheet.Cell(rowIndex, 18).Value = row.ResponseDescriptionMatch;
            sheet.Cell(rowIndex, 19).Value = row.ParametersMatch;
            sheet.Cell(rowIndex, 20).Value = row.OverallMatch;
            sheet.Cell(rowIndex, 21).Value = row.MergeStatus;
            sheet.Cell(rowIndex, 22).Value = row.NormalizedBaseUrl;
            rowIndex++;
        }

        sheet.Columns().AdjustToContents();
        workbook.SaveAs(PathProvider.MetadataComparisonPath);
        Console.WriteLine($"Comparison complete. Output saved to: {PathProvider.MetadataComparisonPath}");
    }

    private sealed record MetadataRecord(
        string System,
        string Region,
        string UrlType,
        string BaseUrl,
        string SwaggerUrl,
        string Method,
        string Endpoint,
        string Tags,
        string ResponseCode,
        string ResponseDescription,
        string Parameters,
        string Environment)
    {
        public string NormalizedBaseUrl => NormalizeUrl(BaseUrl);
        public string Key => $"{System}|{Region}|{UrlType}|{NormalizedBaseUrl}|{Method}|{Endpoint}|{Tags}".ToLowerInvariant();
    }

    private sealed record ComparisonRow(
        string System,
        string Region,
        string UrlType,
        string BaseUrlPrd,
        string BaseUrlUat,
        string SwaggerUrlPrd,
        string SwaggerUrlUat,
        string Method,
        string Endpoint,
        string Tags,
        string ResponseCodePrd,
        string ResponseCodeUat,
        string ResponseDescriptionPrd,
        string ResponseDescriptionUat,
        string ParametersPrd,
        string ParametersUat,
        string ResponseCodeMatch,
        string ResponseDescriptionMatch,
        string ParametersMatch,
        string OverallMatch,
        string MergeStatus,
        string NormalizedBaseUrl);

    private static string NormalizeUrl(string url)
    {
        if (string.IsNullOrWhiteSpace(url))
        {
            return string.Empty;
        }

        var normalized = BaseUrlRegex.Replace(url, ":/aw-");
        normalized = HostSuffixRegex.Replace(normalized, string.Empty);
        return normalized;
    }
}
