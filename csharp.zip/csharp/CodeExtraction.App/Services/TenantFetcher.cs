using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using ClosedXML.Excel;
using CodeExtraction.App.Models;
using CodeExtraction.App.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace CodeExtraction.App.Services;

internal sealed class TenantFetcher
{
    private readonly AppConfig _config;
    private readonly AuthService _authService;

    public TenantFetcher(AppConfig config, AuthService authService)
    {
        _config = config;
        _authService = authService;
    }

    public async Task FetchAndSaveAsync()
    {
        Console.WriteLine("Fetching PRD & UAT tenant data...");
        using var client = _authService.CreateHttpClient();

        var prdData = await FetchTenantAsync(client, _config.PrdTenantUrl);
        var uatData = await FetchTenantAsync(client, _config.UatTenantUrl);

        await SaveRawJsonAsync(Path.Combine(PathProvider.RawPath, "tenant_prd.json"), prdData);
        await SaveRawJsonAsync(Path.Combine(PathProvider.RawPath, "tenant_uat.json"), uatData);

        var prdFlat = FlattenRecords(prdData);
        var uatFlat = FlattenRecords(uatData);
        SaveFlattenedExcel(prdFlat, uatFlat);
    }

    private static async Task<JArray> FetchTenantAsync(HttpClient client, string url)
    {
        var response = await client.GetAsync(url);
        response.EnsureSuccessStatusCode();
        var payload = await response.Content.ReadAsStringAsync();
        return JArray.Parse(payload);
    }

    private static async Task SaveRawJsonAsync(string path, JArray data)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        await File.WriteAllTextAsync(path, data.ToString(Formatting.Indented));
    }

    private static List<Dictionary<string, string?>> FlattenRecords(JArray records)
    {
        var flattened = new List<Dictionary<string, string?>>();
        foreach (var token in records.OfType<JObject>())
        {
            flattened.Add(FlattenRecord(token));
        }

        return flattened;
    }

    private static Dictionary<string, string?> FlattenRecord(JObject record)
    {
        var flat = new Dictionary<string, string?>(StringComparer.OrdinalIgnoreCase)
        {
            ["system"] = record.Value<string>("system"),
            ["env"] = record.Value<string>("env"),
            ["region"] = record.Value<string>("region"),
            ["envType"] = record.Value<string>("envType"),
            ["orchestrationApiUrl"] = record["orchestrationApiSettings"]?["url"]?.ToString(),
            ["orchestrationNotifySupport"] = record["orchestrationApiSettings"]?["notifySupport"]?.ToString()
        };

        var addOnLinks = record["addOnLinks"] as JArray;
        if (addOnLinks != null)
        {
            foreach (var link in addOnLinks.OfType<JObject>())
            {
                var name = link.Value<string>("name");
                if (string.IsNullOrWhiteSpace(name))
                {
                    continue;
                }

                flat[$"addonLinks_{name}_name"] = link.Value<string>("name");
                flat[$"addonLinks_{name}_caption"] = link.Value<string>("caption");
                flat[$"addonLinks_{name}_url"] = link.Value<string>("url");
            }
        }

        return flat;
    }

    private static void SaveFlattenedExcel(
        IReadOnlyCollection<Dictionary<string, string?>> prdRecords,
        IReadOnlyCollection<Dictionary<string, string?>> uatRecords)
    {
        var columns = prdRecords.Concat(uatRecords)
            .SelectMany(d => d.Keys)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .OrderBy(c => c, StringComparer.OrdinalIgnoreCase)
            .ToList();

        var excelPath = Path.Combine(PathProvider.RawPath, "tenant_data.xlsx");
        using var workbook = new XLWorkbook();
        WriteSheet(workbook, "PRD", columns, prdRecords);
        WriteSheet(workbook, "UAT", columns, uatRecords);
        workbook.SaveAs(excelPath);

        Console.WriteLine($"Saved flattened PRD/UAT data to {excelPath}");
    }

    private static void WriteSheet(
        XLWorkbook workbook,
        string sheetName,
        IReadOnlyList<string> columns,
        IReadOnlyCollection<Dictionary<string, string?>> rows)
    {
        var worksheet = workbook.Worksheets.Add(sheetName);
        for (var i = 0; i < columns.Count; i++)
        {
            worksheet.Cell(1, i + 1).Value = columns[i];
        }

        var rowIndex = 2;
        foreach (var row in rows)
        {
            for (var i = 0; i < columns.Count; i++)
            {
                row.TryGetValue(columns[i], out var value);
                worksheet.Cell(rowIndex, i + 1).Value = value ?? string.Empty;
            }

            rowIndex++;
        }

        worksheet.Columns().AdjustToContents();
    }
}
