using System;
using System.IO;

namespace CodeExtraction.App.Utilities;

internal static class PathProvider
{
    public static string ProjectRoot { get; } = GetProjectRoot();
    public static string CSharpRoot { get; } = Directory.GetParent(ProjectRoot)?.FullName ?? ProjectRoot;
    public static string RepositoryRoot { get; } = Directory.GetParent(CSharpRoot)?.FullName ?? CSharpRoot;
    public static string SharedRoot { get; } = Path.Combine(RepositoryRoot, "shared");
    public static string RawPath { get; } = Path.Combine(SharedRoot, "raw");
    public static string ReportsPath { get; } = Path.Combine(SharedRoot, "reports");
    public static string InputPath { get; } = Path.Combine(SharedRoot, "input");
    public static string SwaggerFilePath { get; } = Path.Combine(ReportsPath, "Swagger.xlsx");
    public static string MetadataComparisonPath { get; } = Path.Combine(ReportsPath, "PRDvsUAT_Metadata_Comparison.xlsx");

    public static void EnsureSharedDirectories()
    {
        Directory.CreateDirectory(SharedRoot);
        Directory.CreateDirectory(RawPath);
        Directory.CreateDirectory(ReportsPath);
        Directory.CreateDirectory(InputPath);
    }

    private static string GetProjectRoot()
    {
        var baseDir = AppContext.BaseDirectory;
        var projectDir = Path.GetFullPath(Path.Combine(baseDir, "..", "..", ".."));
        return projectDir;
    }
}
