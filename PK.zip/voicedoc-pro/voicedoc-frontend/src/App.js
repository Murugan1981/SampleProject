import React, { useState } from 'react';
import './App.css';

function App() {
  const [transcript, setTranscript] = useState('');
  const [log, setLog] = useState('');
  const [voice, setVoice] = useState('alloy');
  let mediaRecorder;

  const logMessage = (msg) => setLog((prev) => prev + '➡️ ' + msg + '\n');

  const uploadFile = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    logMessage('Uploading file...');

    const formData = new FormData();
    formData.append('audio', file);
    const res = await fetch('http://localhost:5000/api/transcribe', {
      method: 'POST',
      body: formData
    });
    const data = await res.json();
    data.text ? setTranscript(data.text) : logMessage('❌ ' + data.error);
  };

  const startRecording = async () => {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const recorder = new MediaRecorder(stream);
    let chunks = [];
    recorder.ondataavailable = (e) => chunks.push(e.data);
    recorder.onstop = async () => {
      const blob = new Blob(chunks, { type: 'audio/webm' });
      const formData = new FormData();
      formData.append('audio', blob, 'recording.webm');
      const res = await fetch('http://localhost:5000/api/transcribe', {
        method: 'POST',
        body: formData
      });
      const data = await res.json();
      data.text ? setTranscript(data.text) : logMessage('❌ ' + data.error);
    };
    recorder.start();
    mediaRecorder = recorder;
    window.mediaRecorderRef = recorder;
    logMessage('🎙️ Recording started...');
  };

  const stopRecording = () => {
    window.mediaRecorderRef.stop();
    logMessage('🛑 Recording stopped.');
  };

  const speak = async () => {
    if (!transcript) return;
    logMessage('Sending text to TTS...');
    const res = await fetch('http://localhost:5000/api/speak', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: transcript, voice })
    });
    const blob = await res.blob();
    new Audio(URL.createObjectURL(blob)).play();
    logMessage('🔊 Audio played.');
  };

  return (
    <div className="container">
      <h1>🎤 VoiceDoc Pro (React)</h1>

      <section>
        <h2>📁 Upload Audio</h2>
        <input type="file" accept=".mp3,.mp4,.wav,.webm,.m4a,.ogg,.flac" onChange={uploadFile} />
      </section>

      <section>
        <h2>🎙️ Record</h2>
        <button onClick={startRecording}>Start</button>
        <button onClick={stopRecording}>Stop</button>
      </section>

      <section>
        <h2>🔈 Text-to-Speech</h2>
        <select value={voice} onChange={(e) => setVoice(e.target.value)}>
          <option value="alloy">Alloy</option>
          <option value="echo">Echo</option>
          <option value="fable">Fable</option>
          <option value="onyx">Onyx</option>
          <option value="nova">Nova</option>
          <option value="shimmer">Shimmer</option>
        </select>
        <button onClick={speak}>Speak</button>
      </section>

      <section>
        <h2>📝 Transcript</h2>
        <textarea value={transcript} rows="6" readOnly />
      </section>

      <section>
        <h2>📊 Log</h2>
        <pre>{log}</pre>
      </section>
    </div>
  );
}

export default App;
