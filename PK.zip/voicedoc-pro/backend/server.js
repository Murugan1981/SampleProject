const express = require('express');
const cors = require('cors');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const { OpenAI } = require('openai');
require('dotenv').config();

const app = express();
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/'),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `${Date.now()}${ext}`);
  }
});
const upload = multer({ storage });

app.use(cors());
app.use(express.json());

app.post('/api/transcribe', upload.single('audio'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: "No file uploaded" });

    const ext = path.extname(req.file.originalname);
    const allowed = ['.mp3', '.mp4', '.wav', '.webm', '.m4a', '.ogg', '.flac'];
    if (!allowed.includes(ext)) return res.status(400).json({ error: "Unsupported file type" });

    // const res1 = await openai.audio.translations.create()
    // const res2 = await openai.embeddings.create(())
    const response = await openai.audio.transcriptions.create({ // output - response - text 
      file: fs.createReadStream(req.file.path),
      model: 'whisper-1',
    });

    res.json({ text: response.text });
    fs.unlink(req.file.path, () => {});
  } catch (err) {
    console.error("Transcription Error:", err);
    res.status(500).json({ error: 'Transcription failed', details: err.message });
  }
});

app.post('/api/speak', async (req, res) => {
  try {
    const { text, voice = 'alloy' } = req.body;
    const response = await openai.audio.speech.create({   // output - audio
      model: "tts-1",
      input: text,
      voice
    });
    const buffer = Buffer.from(await response.arrayBuffer());
    res.set({
      'Content-Type': 'audio/mpeg',
      'Content-Disposition': 'inline; filename="output.mp3"',
    });
    res.send(buffer);
  } catch (err) {
    console.error("TTS Error:", err);
    res.status(500).json({ error: 'TTS failed', details: err.message });
  }
});

app.listen(5000, () => console.log('✅ Server running at http://localhost:5000'));
