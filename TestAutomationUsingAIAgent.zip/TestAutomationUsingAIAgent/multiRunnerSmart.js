import fs from 'fs/promises';
import path from 'path';
import { exec } from 'child_process';
import { generateJsonFromPrompt } from './utils/generateJsonFromPrompt.js';

const modelArg = process.argv.find(arg => arg.startsWith('--model='));
const modelType = modelArg ? modelArg.split('=')[1] : 'openai';

const promptInputDir = './promptInput';
const promptJsonDir = './PromptJsons';
const reportPath = './multiPromptExecutionReport.txt';

async function run() {
  const reportLines = [];
  const promptFiles = (await fs.readdir(promptInputDir)).filter(f => f.endsWith('.txt'));

  console.log(`🧪 Found ${promptFiles.length} prompt files.`);
  for (const file of promptFiles) {
    const name = path.basename(file, '.txt');
    const promptFilePath = path.join(promptInputDir, file);
    const jsonPath = path.join(promptJsonDir, `${name}.json`);

    try {
      let instructionsJson;

      try {
        await fs.access(jsonPath);
        console.log(`📁 Using cached JSON for ${file}`);
        instructionsJson = await fs.readFile(jsonPath, 'utf-8');
      } catch {
        console.log(`🧠 Generating JSON for ${file} using ${modelType}`);
        const promptText = await fs.readFile(promptFilePath, 'utf-8');
        const parsed = await generateJsonFromPrompt(promptText, modelType);
        instructionsJson = JSON.stringify(parsed, null, 2);
        await fs.mkdir(promptJsonDir, { recursive: true });
        await fs.writeFile(jsonPath, instructionsJson, 'utf-8');
      }

      await fs.writeFile('./instructions.json', instructionsJson, 'utf-8');
      console.log("Instruction file is updated from promptjsons");
      const result = await new Promise(resolve => {        
        console.log("calling node runner.js");
        exec('node runner.js', (error, stdout, stderr) => {
          if (error) {
            console.error(`❌ Error executing ${file}:`, stderr);
            return resolve(`❌ ${file} failed: ${stderr}`);
          } else {
            console.log(`✅ ${file} executed.`);
            return resolve(`✅ ${file} executed:\n${stdout}`);
          }
        });
      });

      reportLines.push(result);
    } catch (err) {
      const errMsg = `❌ Unexpected failure for ${file}: ${err.message}`;
      console.error(errMsg);
      reportLines.push(errMsg);
    }
  }

  await fs.writeFile(reportPath, reportLines.join('\n'));
  console.log(`📄 Combined execution report saved to ${reportPath}`);
}

run();
