const generateJsonButton = document.getElementById('generateJson'); //input
const userPromptInput = document.getElementById('userPrompt');  //input
const jsonOutput = document.getElementById('jsonOutput'); //output
const modelSelect = document.getElementById('modelSelect'); //input

generateJsonButton.addEventListener('click', async () => {
  const userPrompt = userPromptInput.value.trim();
  const selectedModel = modelSelect.value;

  if (!userPrompt) {
    alert('Please enter a prompt!');
    return;
  }

  try {
    const result = await window.electronAPI.generateJson({ model: selectedModel, prompt: userPrompt });

    try {
      const parsed = JSON.parse(result); // validate
      jsonOutput.textContent = JSON.stringify(parsed, null, 2);

      // save and run only if JSON is valid
      await window.electronAPI.saveJsonToFile(result);
      const executionLog = await window.electronAPI.runTestAutomation();
      console.log(executionLog);
    } catch (err) {
      alert('Invalid JSON returned by AI model.\n\nCheck logs or try simpler prompt.');
      jsonOutput.textContent = result;
    }
  } catch (error) {
    alert('Generation failed:\n' + error.message);
    jsonOutput.textContent = error.message;
  }
});
