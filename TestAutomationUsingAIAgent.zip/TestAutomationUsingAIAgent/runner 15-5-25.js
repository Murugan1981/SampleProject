import { chromium } from 'playwright';
import fs from 'fs/promises';

async function delay(seconds) {
  return new Promise(resolve => setTimeout(resolve, seconds * 1000));
}

async function run() {
  let fileContent, instructions;

  try {
    fileContent = await fs.readFile('./instructions.json', 'utf-8');
    instructions = JSON.parse(fileContent);

  } catch (err) {
    console.error('ERROR: Failed to load or parse instructions.json:', err.message);
    return;
  }
  console.log("Executing runner.js");
  const { url, steps } = instructions;
  const fieldMap = JSON.parse(await fs.readFile('./fieldIdentificationDefinition.json', 'utf-8'));

  if (!Array.isArray(steps)) {
    console.error('ERROR: "steps" must be an array.');
    return;
  }

  const browser = await chromium.launch({ headless: false });
  const page = await browser.newPage();

  console.log(`Navigating to ${url}...`);
  await page.goto(url);

  for (const step of steps) {
    const { action, field, value, seconds } = step;
    console.log(`Processing: ${action}${field ? ' - ' + field : ''}${value ? ' = ' + value : ''}`);

    try {
      if (action === 'delay') {
        const delayTime = parseInt(seconds || value, 10);
        if (isNaN(delayTime)) {
          console.warn('Skipping delay: No valid duration provided.');
          continue;
        }
        console.log(`Delaying for ${delayTime} seconds...`);
        await delay(delayTime); // Exact Playwright command
        continue;
      }

      let locator = null;

      if (field && fieldMap[field]) {
        locator = page.locator(fieldMap[field]);
        console.log(`Using predefined XPath for "${field}"`);
      } else {
        try {
          locator = page.getByLabel(field, { exact: true });
          await locator.first().waitFor({ timeout: 2000 });
        } catch {
          locator = page.locator(
            `input[placeholder*="${field}" i], textarea[placeholder*="${field}" i], 
             input[name*="${field}" i], textarea[name*="${field}" i], 
             select[name*="${field}" i], select[aria-label*="${field}" i], 
             button:has-text("${field}"), a:has-text("${field}")`
          );
          const count = await locator.count();
          if (count === 0) throw new Error(`Field "${field}" not found.`);
        }
      }

      const el = locator.first();
      await el.scrollIntoViewIfNeeded();
      await el.waitFor({ state: 'visible', timeout: 3000 });

      if (action === 'fill' || action === 'type') {
        await el.fill(value); // Playwright command
      } else if (action === 'select') {
        await el.selectOption({ label: value }).catch(async () => {
          await el.selectOption(value); // Playwright command
        });
      } else if (action === 'click') {
        await el.click(); // Playwright command
      } else {
        console.warn(`Unknown action: ${action}`);
        continue;
      }

      console.log(`"${field}" processed successfully.`);
    } catch (err) {
      console.error(`FAILED: ${field || 'Unknown'} - ${err.message}`);
    }
  }

  await browser.close();
  console.log('Test execution completed.');
}

run();
