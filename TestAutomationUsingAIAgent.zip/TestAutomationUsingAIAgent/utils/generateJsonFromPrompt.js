import fetch from 'node-fetch';
import OpenAI from 'openai';
import { aiConfig } from './aiConfig.js';

export async function generateJsonFromPrompt(promptText, modelType = 'openai') {
  const config = aiConfig[modelType];
  let parsed = null;

  if (modelType === 'ollama') {
    const response = await fetch(`${config.baseURL}/api/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: config.model,
        prompt: `Convert this into JSON with "url" and array of steps (action, field, value): ${promptText}`,
        stream: false
      })
    });
    const data = await response.json();
    parsed = JSON.parse(data.response.trim().replace(/```json|```/g, '').trim());
  } else {
    const openai = new OpenAI({ apiKey: config.apiKey, baseURL: config.baseURL });
    const response = await openai.chat.completions.create({
      model: config.model,
      messages: [
        { role: 'system', content: 'Convert the prompt into JSON with "url" and structured steps (action, field, value)' },
        { role: 'user', content: promptText }
      ]
    });
    parsed = JSON.parse(response.choices[0].message.content.trim());
  }

  // Normalize actions
  if (Array.isArray(parsed.steps)) {
    parsed.steps = parsed.steps.map(step => {
      let action = step.action?.toLowerCase();
      if (['key in', 'type', 'enter', 'update'].includes(action)) action = 'fill';
      if (action?.includes('proceed to') || action?.includes('update save')) {
        return { action: 'click', field: 'Save' };
      }
      return { ...step, action };
    });
  }

  // const urlMatch = promptText.match(/https?:\\/\\/[\\w.:/-]+/);
  const urlMatch = promptText.match(/https?:\/\/[\w.:/-]+/);
  // const baseUrl = urlMatch ? urlMatch[0] : 'http://localhost:3050';
  if (urlMatch) parsed.url = urlMatch[0];

  return parsed;
}
