export const aiConfig = {
  openai: {
    apiKey: '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',
    baseURL: 'https://api.openai.com/v1',
    model: 'gpt-3.5-turbo'
  },
  groq: {
    apiKey: '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',
    baseURL: 'https://api.groq.com/openai/v1',
    model: 'mixtral-8x7b-32768'
  },
  ollama: {
    model: 'mistral',
    baseURL: 'http://127.0.0.1:11434'
  }
};
