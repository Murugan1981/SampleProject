import { app, BrowserWindow, ipcMain } from 'electron';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs/promises';
import { exec } from 'child_process';
import OpenAI from 'openai';
import fetch from 'node-fetch';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const openaiClient = new OpenAI({
  apiKey: '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'
}); //paid

const claudeApiKey = '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'; //paid
const groqApiKey = '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';    //open source / free

function createWindow() {
  const win = new BrowserWindow({
    width: 1000,
    height: 800,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    }
  });
  app.commandLine.appendSwitch('disable-gpu');
  win.loadFile('index.html');
}

app.whenReady().then(createWindow);
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
  
// ai will convert Natural language - prompt into json content as needed for Playwright - test automation tool 
ipcMain.handle('generate-json', async (event, { model, prompt }) => {
  try {
    let responseText = '';

    if (model === 'openai') {
      const res = await openaiClient.chat.completions.create({
        model: 'gpt-3.5-turbo',
        messages: [
          { role: 'system', content: 'Convert this prompt into JSON with "url" and "steps". Each step must have "action", "field", and optional "value". Only return JSON.' },
          { role: 'user', content: prompt }
        ]
      });
      responseText = res.choices[0].message.content;
    }

    else if (model === 'groq') {
      const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${groqApiKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model: 'llama3-70b-8192',
          messages: [
            { role: 'system', content: 'Convert this prompt into JSON with "url" and "steps". Each step must have "action", "field", and optional "value". Only return JSON.' },
            { role: 'user', content: prompt }
          ]
        })
      });
      const data = await res.json();
      responseText = data.choices[0].message.content;
    }


        else if (model === 'claude') {
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'x-api-key': claudeApiKey,
          'anthropic-version': '2023-06-01',
          'content-type': 'application/json'
        },
        body: JSON.stringify({
          model: 'claude-3-haiku-20240307',
          max_tokens: 1024,
          temperature: 0.2,
          messages: [
            {
              role: 'user',
              content: `
                Convert this prompt into valid JSON with the following structure:

                - "url": target URL
                - "steps": array of steps. Each step must contain:
                  - "action": one of ["click", "fill", "select", "delay"]
                  - "field": required for all except delay (omit or set to null for delay)
                  - "value": required for fill, select, and delay

                ❗ Do NOT use actions like "type", "enter", or "set". Only use "fill", "click", "select", "delay".

                Only return pure JSON. No markdown or explanation.

                Prompt: ${prompt}`
            }
          ]
        })
      });
      const data = await res.json();
      responseText = data.content[0].text;
    }

    else if (model === 'ollama') {
      const res = await fetch('http://127.0.0.1:11434/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'mistral',
          prompt: `Convert to JSON: ${prompt}`,
          stream: false
        })
      });
      const data = await res.json();
      responseText = data.response;
    }

    else {
      throw new Error('Unknown model selected');
    }
    
    // Clean up the JSON as per Playwright requirement

    const cleaned = responseText.replace(/```json|```/g, '').trim();
    const parsed = JSON.parse(cleaned);

    parsed.steps = parsed.steps.map(step => {
      let action = step.action?.toLowerCase();
      if (["key in", "type", "enter", "update"].includes(action)) action = 'fill';
      if (action?.includes("proceed to") || action?.includes("update save")) return { action: "click", field: "Save" };
      return { ...step, action };
    });

    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    await fs.mkdir(path.join(__dirname, 'logs'), { recursive: true });
    await fs.writeFile(path.join(__dirname, `logs/prompt-${timestamp}.txt`), prompt, 'utf-8');
    await fs.writeFile(path.join(__dirname, `logs/json-${timestamp}.json`), JSON.stringify(parsed, null, 2), 'utf-8');

    return JSON.stringify(parsed);

  } catch (err) {
    console.error(`${model} error:`, err);
    throw new Error(`${model} error: ${err.message}`);
  }
});
    // Saves the generated json content into instructions.json file. 
ipcMain.handle('save-json-to-file', async (event, jsonString) => {
  try {
    const outputPath = path.join(__dirname, 'instructions.json');
    await fs.writeFile(outputPath, jsonString, 'utf-8');
    return 'Saved Successfully!';
  } catch (error) {
    return `Save error: ${error.message}`;
  }
});
  // start the test automation execution. instructions.json is the input file.
ipcMain.handle('run-test-automation', async () => {
  return new Promise((resolve, reject) => {
    exec('node runner.js', { cwd: __dirname }, (error, stdout, stderr) => {
      if (error) {
        console.error(`Runner error: ${stderr}`);
        reject(`Runner execution failed: ${stderr}`);
      } else {
        console.log(`Runner output: ${stdout}`);
        resolve(stdout);
      }
    });
  });
});
