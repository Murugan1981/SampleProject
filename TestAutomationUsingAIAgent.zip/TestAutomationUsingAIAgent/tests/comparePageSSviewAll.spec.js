import { test } from '@playwright/test';
import fs from 'fs';
import path from 'path';
import pixelmatch from 'pixelmatch';
import { PNG } from 'pngjs';
import configData from '../config.json' assert { type: 'json' };

test('Compare page-level screenshots - Baseline vs Release1', async () => {
  const testResultsFolder = path.join(process.cwd(), configData.testResultsFolder);
  const baselineFolder = path.join(testResultsFolder, configData.baselineFolder, 'screenshots/pages');
  const releaseFolder = path.join(testResultsFolder, configData.release1Folder, 'screenshots/pages');

  const comparisonFolder = path.join(testResultsFolder, 'comparisonresults', 'PageScreenshotComparison');
  const diffFolder = path.join(comparisonFolder, 'diff');
  fs.mkdirSync(diffFolder, { recursive: true });

  const baselineFiles = fs.readdirSync(baselineFolder).filter(f => f.endsWith('.png'));

  const comparisonResults = [['PageScreenshot', 'Status']];

  for (const file of baselineFiles) {
    const baselinePath = path.join(baselineFolder, file);
    const releasePath = path.join(releaseFolder, file);
  
    if (!fs.existsSync(releasePath)) {
      comparisonResults.push([file, 'FOUNDINBASELINENOTINRELEASE1']);
      continue;
    }
  
    const img1 = PNG.sync.read(fs.readFileSync(baselinePath));
    const img2 = PNG.sync.read(fs.readFileSync(releasePath));
  
    const { width, height } = img1;
    const diff = new PNG({ width, height });
  
    const mismatchPixels = pixelmatch(img1.data, img2.data, diff.data, width, height, {
      threshold: 0.1
    });
  
    if (mismatchPixels === 0) {
      comparisonResults.push([file, 'MATCH']);
    } else {
      // Create a combined side-by-side image (Baseline | Release | Diff)
      const combined = new PNG({ width: width * 3, height });
  
      // Copy baseline to left
      PNG.bitblt(img1, combined, 0, 0, width, height, 0, 0);
      // Copy release to center
      PNG.bitblt(img2, combined, 0, 0, width, height, width, 0);
      // Copy diff to right
      PNG.bitblt(diff, combined, 0, 0, width, height, width * 2, 0);
  
      const combinedPath = path.join(diffFolder, `Compare_${file}`);
      fs.writeFileSync(combinedPath, PNG.sync.write(combined));
  
      comparisonResults.push([file, 'MISMATCH']);
    }
  }
  
  // Save comparison result to Excel
  const XLSX = await import('xlsx');
  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet(comparisonResults);
  XLSX.utils.book_append_sheet(wb, ws, 'PageScreenshotComparison');
  XLSX.writeFile(wb, path.join(comparisonFolder, 'PageComparisonReport.xlsx'));

  console.log('✅ Page screenshot comparison completed.');
});
