// tests/compareExcel.spec.js
import { test } from '@playwright/test';
import fs from 'fs';
import path from 'path';
import XLSX from 'xlsx';
import configData from '../config.json' assert { type: 'json' };

test('Compare Baseline and Release1 Excel files with full details', async () => {
  const testResultsFolder = path.join(process.cwd(), configData.testResultsFolder);
  const baselineFolder = path.join(testResultsFolder, configData.baselineFolder);
  const releaseFolder = path.join(testResultsFolder, configData.release1Folder);

  const baselineExcelPath = path.join(baselineFolder, 'DomInExcel', 'BaselineData.xlsx');
  const releaseExcelPath = path.join(releaseFolder, 'DomInExcel', 'Release1Data.xlsx');

  if (!fs.existsSync(baselineExcelPath) || !fs.existsSync(releaseExcelPath)) {
    console.error('❌ One or both Excel files not found.');
    return;
  }

  function readSheetToMap(filePath) {
    const buffer = fs.readFileSync(filePath);
    const wb = XLSX.read(buffer, { type: 'buffer' });
    const sheet = wb.Sheets[wb.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json(sheet, { header: 1 });

    const header = rows[0];
    const dataRows = rows.slice(1);

    const map = new Map();
    for (const row of dataRows) {
      const obj = {};
      header.forEach((key, index) => {
        obj[key] = row[index] ?? '';
      });

      if (obj.relativeXPath) {
        map.set(obj.relativeXPath.trim(), obj);
      }
    }
    return { map, rows: [header, ...dataRows] };
  }

  const baselineData = readSheetToMap(baselineExcelPath);
  const releaseData = readSheetToMap(releaseExcelPath);

  const baselineMap = baselineData.map;
  const releaseMap = releaseData.map;

  const allKeys = new Set([...baselineMap.keys(), ...releaseMap.keys()]);
  const compareRows = [['RelativeXPath', 'Status', 'BaselineText', 'ReleaseText']];

  for (const key of allKeys) {
    const base = baselineMap.get(key);
    const rel = releaseMap.get(key);

    if (base && rel) {
      // Same XPath → compare additional fields
      const baseText = base.text?.trim() ?? '';
      const relText = rel.text?.trim() ?? '';
      const status = baseText === relText ? 'MATCH' : 'MISMATCH';
      compareRows.push([key, status, baseText, relText]);
    } else if (base && !rel) {
      compareRows.push([key, 'FOUNDINBASELINENOTINRELEASE1', base.text ?? '', '']);
    } else if (!base && rel) {
      compareRows.push([key, 'FOUNDINRELEASE1NOTINBASELINE', '', rel.text ?? '']);
    }
  }

  // ✅ Write output Excel with 3 sheets including header
  const comparisonDir = path.join(testResultsFolder, 'comparisonresults', 'ExcelComparison');
  fs.mkdirSync(comparisonDir, { recursive: true });

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(baselineData.rows), 'Baseline');
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(releaseData.rows), 'Release1');
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(compareRows), 'CompareDOM');

  const outPath = path.join(comparisonDir, 'CompareXlBaselineVsRelease1.xlsx');
  XLSX.writeFile(wb, outPath);

  console.log(`✅ Excel comparison completed. File saved at: ${outPath}`);
});
