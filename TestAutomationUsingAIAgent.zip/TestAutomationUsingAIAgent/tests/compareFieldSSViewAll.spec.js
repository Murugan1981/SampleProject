// compareFieldSSViewAll.spec.js
import { test } from '@playwright/test';
import fs from 'fs';
import path from 'path';
import { createCanvas, loadImage } from 'canvas';
import pixelmatch from 'pixelmatch';
import configData from '../config.json' assert { type: 'json' };

test('Field-level screenshot comparison with visual output', async () => {
  const testResultsFolder = path.join(process.cwd(), configData.testResultsFolder);
  const baselineFolder = path.join(testResultsFolder, configData.baselineFolder);
  const releaseFolder = path.join(testResultsFolder, configData.release1Folder);
  const comparisonFolder = path.join(testResultsFolder, 'comparisonresults', 'FieldScreenshotComparison', 'diff');
  fs.mkdirSync(comparisonFolder, { recursive: true });

  const baselineFieldSSPath = path.join(baselineFolder, 'screenshots', 'fields');
  const releaseFieldSSPath = path.join(releaseFolder, 'screenshots', 'fields');

  const baselineImages = fs.readdirSync(baselineFieldSSPath).filter(f => f.endsWith('.png'));
  const releaseImages = fs.readdirSync(releaseFieldSSPath).filter(f => f.endsWith('.png'));

  const allFields = new Set([...baselineImages, ...releaseImages]);
  const comparisonData = [['FieldName', 'Status']];

  for (const filename of allFields) {
    const fieldName = filename.replace('.png', '');
    const basePath = path.join(baselineFieldSSPath, filename);
    const relPath = path.join(releaseFieldSSPath, filename);

    const baseExists = fs.existsSync(basePath);
    const relExists = fs.existsSync(relPath);

    let status = '';
    if (baseExists && relExists) {
      const [img1, img2] = await Promise.all([loadImage(basePath), loadImage(relPath)]);
      const width = Math.max(img1.width, img2.width);
      const height = Math.max(img1.height, img2.height);

      const canvas1 = createCanvas(width, height);
      canvas1.getContext('2d').drawImage(img1, 0, 0);

      const canvas2 = createCanvas(width, height);
      canvas2.getContext('2d').drawImage(img2, 0, 0);

      const diffCanvas = createCanvas(width, height);
      const diffCtx = diffCanvas.getContext('2d');

      const diffPixels = pixelmatch(
        canvas1.getContext('2d').getImageData(0, 0, width, height).data,
        canvas2.getContext('2d').getImageData(0, 0, width, height).data,
        diffCtx.getImageData(0, 0, width, height).data,
        width,
        height,
        { threshold: 0.1 }
      );

      status = diffPixels === 0 ? 'MATCH' : 'MISMATCH';
      if (status === 'MISMATCH') {
        const finalCanvas = createLabeledTriplePanel(img1, img2, diffCanvas, fieldName, 'YELLOW');
        const outputPath = path.join(comparisonFolder, filename);
        const outStream = fs.createWriteStream(outputPath);
        finalCanvas.createPNGStream().pipe(outStream);
      }
    } else if (baseExists && !relExists) {
      status = 'FOUNDINBASELINENOTINRELEASE1';
      const img1 = await loadImage(basePath);
      const dummy = createCanvas(img1.width, img1.height);
      const finalCanvas = createLabeledTriplePanel(img1, dummy, dummy, fieldName, 'RED');
      const outputPath = path.join(comparisonFolder, filename);
      finalCanvas.createPNGStream().pipe(fs.createWriteStream(outputPath));
    } else if (!baseExists && relExists) {
      status = 'FOUNDINRELEASE1NOTINBASELINE';
      const img2 = await loadImage(relPath);
      const dummy = createCanvas(img2.width, img2.height);
      const finalCanvas = createLabeledTriplePanel(dummy, img2, dummy, fieldName, 'GREEN');
      const outputPath = path.join(comparisonFolder, filename);
      finalCanvas.createPNGStream().pipe(fs.createWriteStream(outputPath));
    }

    comparisonData.push([fieldName, status]);
  }

  // Write Excel result
  const XLSX = await import('xlsx');
  const excelPath = path.join(testResultsFolder, 'comparisonresults', 'FieldScreenshotComparison', 'CompareFieldSS.xlsx');
  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet(comparisonData);
  XLSX.utils.book_append_sheet(wb, ws, 'FieldSSCompare');
  XLSX.writeFile(wb, excelPath);

  console.log(`✅ Field-level screenshot comparison completed. Excel: ${excelPath}`);
});




// Helper function to build labeled output


////

function createLabeledTriplePanel(img1, img2, diffImgCanvas, label, borderColor) {
    const width = Math.max(img1.width, img2.width, diffImgCanvas.width);
    const height = Math.max(img1.height, img2.height, diffImgCanvas.height);
    const labelHeight = 60; // Two rows: field label and section labels
  
    const finalCanvas = createCanvas(3 * width, height + labelHeight);
    const ctx = finalCanvas.getContext('2d');
  
    ctx.fillStyle = 'white';
    ctx.fillRect(0, 0, finalCanvas.width, finalCanvas.height);
  
    ctx.font = '16px Arial';
    ctx.fillStyle = 'black';
    ctx.textAlign = 'center';
  
    // 🟡 First row: Field name
    ctx.fillText(`Field: ${label}`, finalCanvas.width / 2, 20);
  
    // 🟢 Second row: Panel names
    ctx.fillText('Baseline', width / 2, 45);
    ctx.fillText('Release1', width + width / 2, 45);
    ctx.fillText('Diff', 2 * width + width / 2, 45);
  
    // 🖼️ Draw actual images below both labels
    ctx.drawImage(img1, 0, labelHeight);
    ctx.drawImage(img2, width, labelHeight);
    ctx.drawImage(diffImgCanvas, 2 * width, labelHeight);
  
    if (borderColor) {
      ctx.strokeStyle = borderColor.toUpperCase();
      ctx.lineWidth = 5;
      ctx.strokeRect(0, labelHeight, width, height);
      ctx.strokeRect(width, labelHeight, width, height);
      ctx.strokeRect(2 * width, labelHeight, width, height);
    }
  
    return finalCanvas;
  }
  

////

