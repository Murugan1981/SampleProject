
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  generateJson: (prompt) => ipcRenderer.invoke('generate-json', prompt),
  saveJsonToFile: (jsonString) => ipcRenderer.invoke('save-json-to-file', jsonString),
  runTestAutomation: () => ipcRenderer.invoke('run-test-automation') 
});
