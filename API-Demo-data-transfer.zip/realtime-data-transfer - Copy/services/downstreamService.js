import axios from 'axios';
import dotenv from 'dotenv';

dotenv.config();

export async function sendToDownstream(payload) {
  const response = await axios.post(process.env.DOWNSTREAM_API_URL, payload, {
    headers: {
      'Content-Type': 'application/json',
    },
  });
  return response.data;
}
