import express from 'express';
import dotenv from 'dotenv';
import path from 'path';              //module provides utilities for working with file and directory paths
import { fileURLToPath } from 'url'; //provides utilities for URL resolution and parsing
import cors from 'cors';
import upstreamRouter from './routes/upstream.js';

// Load environment variables
dotenv.config();

// Setup __dirname for ES Modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Express
const app = express();

// Middlewares
app.use(cors());
app.use(express.json());

// Serve static files from /public
app.use(express.static(path.join(__dirname, 'public')));

// Routes
app.use('/api/upstream', upstreamRouter);

// Start Server
const PORT = process.env.PORT || 3030;
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
