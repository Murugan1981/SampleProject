import { randomUUID } from 'crypto';
import express from 'express';
import { sendToDownstream } from '../services/downstreamService.js';
import fs from 'fs/promises';
import path from 'path';

const router = express.Router();

const logPath = path.resolve('./logs/transactions.json');

router.post('/receive', async (req, res) => {
  const data = req.body;
  const logEntry = {
    id: randomUUID(),  // Assign unique ID
    receivedAt: new Date().toISOString(),
    data,
  };

  try {
    const response = await sendToDownstream(data);
    logEntry.status = 'SUCCESS';
    logEntry.downstreamResponse = response;

    await saveLog(logEntry);
    res.status(200).json({ message: 'Data processed and sent downstream.', id: logEntry.id });  //SUCCESS
  } catch (error) {
    logEntry.status = 'FAILED';
    logEntry.error = error.message;
    await saveLog(logEntry);
    res.status(500).json({ error: 'Failed to send data downstream.' });  //FAILURE
  }
});


// router.get('/logs', async (req, res) => {
//   const logPath = path.resolve('./logs/transactions.json');

//   try {
//     const content = await fs.readFile(logPath, 'utf-8');
//     const logs = JSON.parse(content);
//     res.status(200).json(logs);
//   } catch (error) {
//     res.status(500).json({ error: 'Could not read transaction logs.' });
//   }
// });

router.get('/logs', async (req, res) => {
  const logPath = path.resolve('./logs/transactions.json');
  const { source, status, value } = req.query;

  try {
    const content = await fs.readFile(logPath, 'utf-8');
    let logs = JSON.parse(content);

    // Apply filters only if present
    if (source) {
      logs = logs.filter(entry =>
        entry.data?.source?.toLowerCase() === source.toLowerCase()
      );
    }

    if (status) {
      logs = logs.filter(entry =>
        entry.status?.toLowerCase() === status.toLowerCase()
      );
    }

    if (value) {
      logs = logs.filter(entry =>
        String(entry.data?.value) === String(value)
      );
    }

    res.status(200).json(logs);
  } catch (error) {
    res.status(500).json({ error: 'Could not read transaction logs.' });
  }
});

//GET http://localhost:3030/api/upstream/logs/b8d86288-2a77-4bf3-b251-1d342a61a8ad
router.get('/logs/:id', async (req, res) => {
  const logPath = path.resolve('./logs/transactions.json');
  const { id } = req.params;

  try {
    const content = await fs.readFile(logPath, 'utf-8');
    const logs = JSON.parse(content);
    const found = logs.find(entry => entry.id === id);

    if (!found) {
      return res.status(404).json({ error: 'Record not found.' });
    }

    res.status(200).json(found);
  } catch (error) {
    res.status(500).json({ error: 'Could not read logs.' });
  }
});

router.get('/value-by-source/:source', async (req, res) => {
  const logPath = path.resolve('./logs/transactions.json');
  const { source } = req.params;

  try {
    const content = await fs.readFile(logPath, 'utf-8');
    const logs = JSON.parse(content);

    // Find first matching record
    const match = logs.find(entry =>
      entry.data?.source?.toLowerCase() === source.toLowerCase()
    );

    if (!match) {
      return res.status(404).json({ error: 'Source not found.' });
    }

    // Return only the 'value' field
    res.status(200).json({ value: match.data?.value });
  } catch (error) {
    res.status(500).json({ error: 'Could not process request.' });
  }
});


router.get('/source-by-value/:value', async (req, res) => {
  const logPath = path.resolve('./logs/transactions.json'); // logpath - holds the transactions.json file
  const { value } = req.params;

  try {
    const content = await fs.readFile(logPath, 'utf-8');
    const logs = JSON.parse(content);

    // Find first matching record
    const match = logs.find(entry =>
      String(entry.data?.value) === String(value)
    );

    if (!match) {
      return res.status(404).json({ error: 'value not found.' });
    }

    // Return only the 'source' field
    res.status(200).json({ source: match.data?.source });
  } catch (error) {
    res.status(500).json({ error: 'Could not process request.' });
  }
});

//GET /timestamp-by-source/:source
router.get('/timestamp-by-source/:source', async (req, res) => {
  const logPath = path.resolve('./logs/transactions.json');
  const { source } = req.params;

  try {
    const content = await fs.readFile(logPath, 'utf-8');
    const logs = JSON.parse(content);

    const match = logs.find(entry =>
      entry.data?.source?.toLowerCase() === source.toLowerCase()
    );

    if (!match) {
      return res.status(404).json({ error: 'Source not found.' });
    }

    res.status(200).json({ timestamp: match.data?.timestamp });
  } catch (error) {
    res.status(500).json({ error: 'Could not process request.' });
  }
});


//GET /timestamp-by-value/:value
router.get('/timestamp-by-value/:value', async (req, res) => {
  const logPath = path.resolve('./logs/transactions.json');
  const { value } = req.params;

  try {
    const content = await fs.readFile(logPath, 'utf-8');
    const logs = JSON.parse(content);

    const match = logs.find(entry =>
      String(entry.data?.value) === String(value)
    );

    if (!match) {
      return res.status(404).json({ error: 'Value not found.' });
    }

    res.status(200).json({ timestamp: match.data?.timestamp });
  } catch (error) {
    res.status(500).json({ error: 'Could not process request.' });
  }
});

//GET /api/upstream/timestamp?source=demo-ui
//GET /api/upstream/timestamp?value=987654321
router.get('/timestamp', async (req, res) => {
  const logPath = path.resolve('./logs/transactions.json');
  const { source, value } = req.query;

  try {
    const content = await fs.readFile(logPath, 'utf-8');
    const logs = JSON.parse(content);

    let match;

    if (source) {
      match = logs.find(entry =>
        entry.data?.source?.toLowerCase() === source.toLowerCase()
      );
    } else if (value) {
      match = logs.find(entry =>
        String(entry.data?.value) === String(value)
      );
    } else {
      return res.status(400).json({ error: 'Please provide source or value.' });
    }

    if (!match) {
      return res.status(404).json({ error: 'No matching record found.' });
    }

    res.status(200).json({ timestamp: match.data?.timestamp });
  } catch (error) {
    res.status(500).json({ error: 'Could not process request.' });
  }
});


async function saveLog(entry) {
  let currentLogs = [];
  try {
    const content = await fs.readFile(logPath, 'utf-8');
    currentLogs = JSON.parse(content);
  } catch {}
  currentLogs.push(entry);
  await fs.writeFile(logPath, JSON.stringify(currentLogs, null, 2));
}

export default router;
