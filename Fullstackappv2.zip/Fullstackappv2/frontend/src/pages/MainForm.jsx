import React, { useEffect } from 'react';
import { Link, Routes, Route, useNavigate, useLocation } from 'react-router-dom';
import PersonalDetails from '../components/PersonalDetails';
import DemographicDetails from '../components/DemographicDetails';
import EducationDetails from '../components/EducationDetails';
import WorkExperience from '../components/WorkExperience';
import AutomationTools from '../components/AutomationTools';
import ProgrammingLanguages from '../components/ProgrammingLanguages';
import Certifications from '../components/Certifications';
import AwardsReceived from '../components/AwardsReceived';
import FrameworkKnowledge from '../components/FrameworkKnowledge.jsx';
import DomainExperience from '../components/DomainExperience.jsx';
import AIModelExperience from '../components/AIModelExperience.jsx';
import ExtraCurricularActivities from '../components/ExtraCurricularActivities.jsx';

const tabs = [
  { label: "Personal Details", path: "personal", element: <PersonalDetails /> },
  { label: "Demographic Details", path: "demographic", element: <DemographicDetails /> },
  { label: "Education Details", path: "education", element: <EducationDetails /> },
  { label: "Work Experience", path: "work", element: <WorkExperience /> },
  { label: "Automation Tools", path: "automation", element: <AutomationTools /> },
  { label: "Programming Languages", path: "languages", element: <ProgrammingLanguages /> },
  { label: "Certifications", path: "certifications", element: <Certifications /> },
  { label: "Awards Received", path: "awards", element: <AwardsReceived /> },
  { label: "Framework Knowledge", path: "frameworks", element: <FrameworkKnowledge /> },
  { label: "Domain Experience", path: "domain", element: <DomainExperience /> },
  { label: "AI Model Experience", path: "aimodels", element: <AIModelExperience /> },
  { label: "Extra Curricular Activities", path: "extracurricular", element: <ExtraCurricularActivities /> },

];

function MainForm() {
  const username = localStorage.getItem('username');
  const navigate = useNavigate();
  const location = useLocation();

  const currentPath = location.pathname.split('/')[2] || tabs[0].path;

  useEffect(() => {
    if (!username) {
      navigate('/login');
    }
  }, [username, navigate]);

  const handleLogout = () => {
    localStorage.clear();
    navigate('/login');
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh' }}>
      {/* Header */}
      <div style={{ background: '#007bff', padding: '10px 20px', color: 'white' }}>
        <span>Logged in as: <strong>{username}</strong></span>
        <button
          onClick={handleLogout}
          style={{ float: 'right', background: 'white', color: '#007bff', border: 'none', padding: '6px 12px', borderRadius: '4px', cursor: 'pointer', fontWeight: 'bold' }}
        >
          Logout
        </button>
      </div>

      {/* Body layout */}
      <div style={{ display: 'flex', flexGrow: 1 }}>
        {/* Sidebar */}
        <div style={{ minWidth: '220px', borderRight: '1px solid #ccc', backgroundColor: '#f1f1f1', height: '100%', overflowY: 'auto' }}>
          {tabs.map((tab) => (
            <div
              key={tab.path}
              onClick={() => navigate(`/main/${tab.path}`)}
              style={{
                padding: '12px 16px',
                backgroundColor: currentPath === tab.path ? '#d0ebff' : 'transparent',
                fontWeight: currentPath === tab.path ? 'bold' : 'normal',
                borderLeft: currentPath === tab.path ? '4px solid #007bff' : '4px solid transparent',
                cursor: 'pointer',
                transition: 'background-color 0.2s'
              }}
            >
              {tab.label}
            </div>
          ))}
        </div>

        {/* Main Content */}
        <div style={{ padding: '30px', flexGrow: 1 }}>
          <h2>{tabs.find(t => t.path === currentPath)?.label}</h2>
          <Routes>
            {tabs.map((tab) => (
              <Route key={tab.path} path={tab.path} element={tab.element} />
            ))}
          </Routes>
        </div>
      </div>
    </div>
  );
}

export default MainForm;
