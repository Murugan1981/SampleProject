import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate, Link } from 'react-router-dom';

function LoginPage() {
  const [form, setForm] = useState({ username: '', password: '' });
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage('');
    try {
      const res = await axios.post('http://localhost:5000/api/auth/login', form);
      console.log(res.data);
      const { token, username } = res.data;
      if (token  && username) {
        localStorage.setItem('username', username);
        localStorage.setItem('token', token);
        navigate('/main/personal');
      } else {
        setMessage('Login failed: Token not received.');
      }
    } catch (err) {
      const errorMsg = err.response?.data?.error || 'Login failed due to server error';
      setMessage(errorMsg);
    }
  };

  return (
    <div className="auth-container">
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <input name="username" placeholder="Username" value={form.username} onChange={handleChange} required />
        <input name="password" type="password" placeholder="Password" value={form.password} onChange={handleChange} required />
        <button type="submit">Login</button>
        {message && <p className="status-message">{message}</p>}
      </form>
      <p>New user? <Link to="/register">Register here</Link></p>
    </div>
  );
}

export default LoginPage;
