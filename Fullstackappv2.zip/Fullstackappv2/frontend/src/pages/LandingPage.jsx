import React from 'react';
import { useNavigate } from 'react-router-dom';

function LandingPage() {
  const navigate = useNavigate();
  return (
    <div style={{ textAlign: 'center', marginTop: '20vh' }}>
      <h1>Welcome to the AI Test Automation Tool</h1>
      <button onClick={() => navigate('/register')} style={{ margin: '10px' }}>Register</button>
      <button onClick={() => navigate('/login')} style={{ margin: '10px' }}>Login</button>
    </div>
  );
}
export default LandingPage;