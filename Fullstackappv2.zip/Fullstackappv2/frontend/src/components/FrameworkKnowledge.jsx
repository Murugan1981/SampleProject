import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Pencil, Trash2 } from 'lucide-react';

function FrameworkKnowledge() {
  const [entry, setEntry] = useState({ frameworkName: '', experience: '' });
  const [frameworks, setFrameworks] = useState([]);
  const [editIndex, setEditIndex] = useState(null);
  const username = localStorage.getItem('username');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await axios.get(`http://localhost:5000/api/profile/frameworks/${username}`);
        const raw = res.data?.framework;
        if (raw) {
          const parsed = JSON.parse(raw);
          if (Array.isArray(parsed)) setFrameworks(parsed);
          else setFrameworks([]);
        } else {
          setFrameworks([]);
        }
      } catch (err) {
        console.log('Error fetching framework data:', err);
        setFrameworks([]);
      }
    };
    fetchData();
  }, [username]);

  const handleChange = (e) => {
    setEntry({ ...entry, [e.target.name]: e.target.value });
  };

  const handleAddOrUpdate = () => {
    if (!entry.frameworkName || !entry.experience) return;

    const updated = [...frameworks];
    if (editIndex !== null) {
      updated[editIndex] = entry;
      setEditIndex(null);
    } else {
      updated.push(entry);
    }
    setFrameworks(updated);
    setEntry({ frameworkName: '', experience: '' });
  };

  const handleEdit = (index) => {
    setEntry(frameworks[index]);
    setEditIndex(index);
  };

  const handleDelete = (index) => {
    const updated = [...frameworks];
    updated.splice(index, 1);
    setFrameworks(updated);
    if (editIndex === index) setEditIndex(null);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/api/profile/frameworks', {
        username,
        framework: JSON.stringify(frameworks)
      });
      alert('Frameworks saved!');
    } catch (err) {
      alert('Save failed');
      console.error(err);
    }
  };

  return (
    <form className="grid-form" onSubmit={handleSave}>
      <div className="form-field">
        <label>Framework Name</label>
        <input name="frameworkName" value={entry.frameworkName} onChange={handleChange} />
      </div>
      <div className="form-field">
        <label>Experience</label>
        <input name="experience" value={entry.experience} onChange={handleChange} />
      </div>

      <button type="button" className="full-width" onClick={handleAddOrUpdate}>
        {editIndex !== null ? 'Update Framework' : 'Add Framework'}
      </button>

      {frameworks.length > 0 && (
        <table style={{ width: '200%', marginTop: '20px', borderCollapse: 'collapse', tableLayout: 'fixed' }}>
          <thead style={{ backgroundColor: '#f3f3f3' }}>
            <tr>
              <th style={{ width: '60%' }}>Framework</th>
              <th style={{ width: '20%' }}>Experience</th>
              <th style={{ width: '20%' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {frameworks.map((item, index) => (
              <tr key={index} style={{ textAlign: 'center', borderBottom: '1px solid #ccc' }}>
                <td>{item.frameworkName}</td>
                <td>{item.experience}</td>
                <td>
                  <button type="button" onClick={() => handleEdit(index)} style={{ marginRight: '10px' }}>
                    <Pencil size={16} />
                  </button>
                  <button type="button" onClick={() => handleDelete(index)}>
                    <Trash2 size={16} color="red" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      <button type="submit" className="full-width" style={{ marginTop: '20px' }}>Save</button>
    </form>
  );
}

export default FrameworkKnowledge;
