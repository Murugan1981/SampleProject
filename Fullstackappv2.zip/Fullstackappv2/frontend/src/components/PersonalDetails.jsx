import React, { useState,useEffect } from 'react';
import axios from 'axios';

function PersonalDetails() {
  const [form, setForm] = useState({
    firstName: '',
    lastName: '',
    telephone: '',
    mobile: '',
    dob: '',
    maritalStatus: ''
  });
  
  const username = localStorage.getItem('username');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await axios.get(`http://localhost:5000/api/profile/personal/${username}`);
        if (res.data) {
          setForm(res.data);
        }
      } catch (err) {
        console.log('No existing personal details');
      }
    };

    fetchData();
  }, [username]);

  
  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSave = async (e) => {
    e.preventDefault();
    const username = localStorage.getItem('username');
    try {
      await axios.post('http://localhost:5000/api/profile/personal', {
        username,
        ...form
      });
      alert('Saved!');
    } catch (err) {
      alert('Error saving data');
    }
  };

  return (
    // <form className="form-container" onSubmit={handleSave}>
  <form className="grid-form" onSubmit={handleSave}>
  <div className="form-field">
    <label htmlFor="firstName">First Name*</label>
    <input type="text" id="firstName" name="firstName" value={form.firstName} onChange={handleChange} required />
  </div>

  <div className="form-field">
    <label htmlFor="lastName">Last Name*</label>
    <input type="text" id="lastName" name="lastName" value={form.lastName} onChange={handleChange} required />
  </div>

  <div className="form-field">
    <label htmlFor="telephone">Telephone</label>
    <input type="text" id="telephone" name="telephone" value={form.telephone} onChange={handleChange} />
  </div>

  <div className="form-field">
    <label htmlFor="mobile">Mobile*</label>
    <input type="text" id="mobile" name="mobile" value={form.mobile} onChange={handleChange} required />
  </div>

  <div className="form-field">
    <label htmlFor="dob">Date of Birth*</label>
    <input type="date" id="dob" name="dob" value={form.dob} onChange={handleChange} required />
  </div>

  <div className="form-field">
    <label>Marital Status</label>
    <div className="radio-group">
      <label><input type="radio" name="maritalStatus" value="Married" checked={form.maritalStatus === 'Married'} onChange={handleChange} /> Married</label>
      <label><input type="radio" name="maritalStatus" value="Single" checked={form.maritalStatus === 'Single'} onChange={handleChange} /> Single</label>
      <label><input type="radio" name="maritalStatus" value="Separated" checked={form.maritalStatus === 'Separated'} onChange={handleChange} /> Separated</label>
    </div>
  </div>

  <button type="submit">Save</button>
</form>

  );
}

export default PersonalDetails;
