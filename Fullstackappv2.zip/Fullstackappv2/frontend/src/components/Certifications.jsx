import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Pencil, Trash2 } from 'lucide-react';

function Certifications() {
  const [entry, setEntry] = useState({
    name: '',
    certificateId: '',
    completionDate: '',
    validUntil: ''
  });

  const [certs, setCerts] = useState([]);
  const [editIndex, setEditIndex] = useState(null);
  const username = localStorage.getItem('username');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await axios.get(`http://localhost:5000/api/profile/certifications/${username}`);
        const parsed = res.data?.certificationData ? JSON.parse(res.data.certificationData) : [];
        setCerts(parsed);
      } catch {
        console.log('No certifications found');
      }
    };
    fetchData();
  }, [username]);

  const handleChange = (e) => {
    setEntry({ ...entry, [e.target.name]: e.target.value });
  };

  const handleAddOrUpdate = () => {
    if (!entry.name || !entry.completionDate) return;

    const updated = [...certs];
    if (editIndex !== null) {
      updated[editIndex] = entry;
      setEditIndex(null);
    } else {
      updated.push(entry);
    }
    setCerts(updated);
    setEntry({ name: '', certificateId: '', completionDate: '', validUntil: '' });
  };

  const handleEdit = (index) => {
    setEntry(certs[index]);
    setEditIndex(index);
  };

  const handleDelete = (index) => {
    const updated = [...certs];
    updated.splice(index, 1);
    setCerts(updated);
    if (editIndex === index) setEditIndex(null);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/api/profile/certifications', {
        username,
        certificationData: JSON.stringify(certs)
      });
      alert('Certifications saved!');
    } catch (err) {
      alert('Save failed');
      console.error(err);
    }
  };

  return (
    <form className="grid-form" onSubmit={handleSave}>
      <div className="form-field">
        <label>Certification Name</label>
        <input name="name" value={entry.name} onChange={handleChange} />
      </div>
      <div className="form-field">
        <label>Certificate ID</label>
        <input name="certificateId" value={entry.certificateId} onChange={handleChange} />
      </div>
      <div className="form-field">
        <label>Month/Year of Completion</label>
        <input name="completionDate" type="month" value={entry.completionDate} onChange={handleChange} />
      </div>
      <div className="form-field">
        <label>Valid Until (Month/Year)</label>
        <input name="validUntil" type="month" value={entry.validUntil} onChange={handleChange} />
      </div>

      <button type="button" className="full-width" onClick={handleAddOrUpdate}>
        {editIndex !== null ? 'Update Certification' : 'Add Certification'}
      </button>

      {certs.length > 0 && (
        <table style={{ width: '200%', marginTop: '20px', borderCollapse: 'collapse', tableLayout: 'fixed' }}>
          <thead style={{ backgroundColor: '#f3f3f3' }}>
            <tr>
              <th style={{ width: '30%' }}>Name</th>
              <th style={{ width: '15%' }}>ID</th>
              <th style={{ width: '15%' }}>Completed</th>
              <th style={{ width: '20%' }}>Valid Until</th>
              <th style={{ width: '20%' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {certs.map((item, index) => (
              <tr key={index} style={{ textAlign: 'center', borderBottom: '1px solid #ccc' }}>
                <td>{item.name}</td>
                <td>{item.certificateId}</td>
                <td>{item.completionDate}</td>
                <td>{item.validUntil}</td>
                <td>
                  <button type="button" onClick={() => handleEdit(index)} style={{ marginRight: '10px' }}>
                    <Pencil size={16} />
                  </button>
                  <button type="button" onClick={() => handleDelete(index)}>
                    <Trash2 size={16} color="red" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      <button type="submit" className="full-width" style={{ marginTop: '20px' }}>Save</button>
    </form>
  );
}

export default Certifications;
