import React, { useState, useEffect } from 'react';
import axios from 'axios';

function DemographicDetails() {
  const [form, setForm] = useState({
    address1: '',
    address2: '',
    city: '',
    state: '',
    country: '',
    zipCode: ''
  });

  useEffect(() => {
    const fetchData = async () => {
      const username = localStorage.getItem('username');
      try {
        const res = await axios.get(`http://localhost:5000/api/profile/demographic/${username}`);
        if (res.data) {
          setForm(res.data);
        }
      } catch (err) {
        console.log('No existing demographic data');
      }
    };
    fetchData();
  }, []);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSave = async (e) => {
    e.preventDefault();
    const username = localStorage.getItem('username');
    try {
      await axios.post('http://localhost:5000/api/profile/demographic', {
        username,
        ...form
      });
      alert('Demographic details saved!');
    } catch (err) {
      alert('Error saving demographic details');
    }
  };

  return (
    <form className="grid-form" onSubmit={handleSave}>
      <div className="form-field">
        <label htmlFor="address1">Address Line 1</label>
        <input type="text" id="address1" name="address1" value={form.address1} onChange={handleChange} />
      </div>

      <div className="form-field">
        <label htmlFor="address2">Address Line 2</label>
        <input type="text" id="address2" name="address2" value={form.address2} onChange={handleChange} />
      </div>

      <div className="form-field">
        <label htmlFor="city">City</label>
        <input type="text" id="city" name="city" value={form.city} onChange={handleChange} />
      </div>

      <div className="form-field">
        <label htmlFor="state">State</label>
        <input type="text" id="state" name="state" value={form.state} onChange={handleChange} />
      </div>

      <div className="form-field">
        <label htmlFor="country">Country</label>
        <input type="text" id="country" name="country" value={form.country} onChange={handleChange} />
      </div>

      <div className="form-field">
        <label htmlFor="zipCode">Zip Code</label>
        <input type="text" id="zipCode" name="zipCode" value={form.zipCode} onChange={handleChange} />
      </div>

      <button type="submit" className="full-width">Save</button>
    </form>
  );
}

export default DemographicDetails;
