import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Pencil, Trash2 } from 'lucide-react';

function Hobbies() {
  const [entry, setEntry] = useState({ hobby: '' });
  const [hobbies, setHobbies] = useState([]);
  const [editIndex, setEditIndex] = useState(null);
  const username = localStorage.getItem('username');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await axios.get(`http://localhost:5000/api/profile/hobbies/${username}`);
        const raw = res.data?.hobby;
        if (raw) {
          const parsed = JSON.parse(raw);
          if (Array.isArray(parsed)) setHobbies(parsed);
          else setHobbies([]);
        } else {
          setHobbies([]);
        }
      } catch (err) {
        console.log('Error fetching hobbies:', err);
        setHobbies([]);
      }
    };
    fetchData();
  }, [username]);

  const handleChange = (e) => {
    setEntry({ ...entry, [e.target.name]: e.target.value });
  };

  const handleAddOrUpdate = () => {
    if (!entry.hobby.trim()) return;
    const updated = [...hobbies];
    if (editIndex !== null) {
      updated[editIndex] = entry;
      setEditIndex(null);
    } else {
      updated.push(entry);
    }
    setHobbies(updated);
    setEntry({ hobby: '' });
  };

  const handleEdit = (index) => {
    setEntry(hobbies[index]);
    setEditIndex(index);
  };

  const handleDelete = (index) => {
    const updated = [...hobbies];
    updated.splice(index, 1);
    setHobbies(updated);
    if (editIndex === index) setEditIndex(null);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/api/profile/hobbies', {
        username,
        hobby: JSON.stringify(hobbies)
      });
      alert('Hobbies saved!');
    } catch (err) {
      alert('Save failed');
      console.error(err);
    }
  };

  return (
    <form className="grid-form" onSubmit={handleSave}>
      <div className="form-field">
        <label>Hobby</label>
        <input name="hobby" value={entry.hobby} onChange={handleChange} />
      </div>

      <button type="button" className="full-width" onClick={handleAddOrUpdate}>
        {editIndex !== null ? 'Update Hobby' : 'Add Hobby'}
      </button>

      {hobbies.length > 0 && (
        <table style={{ width: '200%', marginTop: '20px', borderCollapse: 'collapse', tableLayout: 'fixed' }}>
          <thead style={{ backgroundColor: '#f3f3f3' }}>
            <tr>
              <th style={{ width: '70%' }}>Hobby</th>
              <th style={{ width: '30%' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {hobbies.map((item, index) => (
              <tr key={index} style={{ textAlign: 'center', borderBottom: '1px solid #ccc' }}>
                <td>{item.hobby}</td>
                <td>
                  <button type="button" onClick={() => handleEdit(index)} style={{ marginRight: '10px' }}>
                    <Pencil size={16} />
                  </button>
                  <button type="button" onClick={() => handleDelete(index)}>
                    <Trash2 size={16} color="red" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      <button type="submit" className="full-width" style={{ marginTop: '20px' }}>Save</button>
    </form>
  );
}

export default Hobbies;

