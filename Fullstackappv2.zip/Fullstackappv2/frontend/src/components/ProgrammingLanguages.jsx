import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Pencil, Trash2 } from 'lucide-react';

function ProgrammingLanguages() {
  const [entry, setEntry] = useState({ language: '', level: '', lastUsed: '' });
  const [languages, setLanguages] = useState([]);
  const [editIndex, setEditIndex] = useState(null);
  const username = localStorage.getItem('username');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await axios.get(`http://localhost:5000/api/profile/languages/${username}`);
        const parsed = res.data?.languageData ? JSON.parse(res.data.languageData) : [];
        setLanguages(parsed);
      } catch {
        console.log('No language data found');
      }
    };
    fetchData();
  }, [username]);

  const handleChange = (e) => {
    setEntry({ ...entry, [e.target.name]: e.target.value });
  };

  const handleAddOrUpdate = () => {
    if (!entry.language || !entry.level || !entry.lastUsed) return;

    const updated = [...languages];
    if (editIndex !== null) {
      updated[editIndex] = entry;
      setEditIndex(null);
    } else {
      updated.push(entry);
    }
    setLanguages(updated);
    setEntry({ language: '', level: '', lastUsed: '' });
  };

  const handleEdit = (index) => {
    setEntry(languages[index]);
    setEditIndex(index);
  };

  const handleDelete = (index) => {
    const updated = [...languages];
    updated.splice(index, 1);
    setLanguages(updated);
    if (editIndex === index) setEditIndex(null);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/api/profile/languages', {
        username,
        languageData: JSON.stringify(languages)
      });
      alert('Languages saved!');
    } catch (err) {
      alert('Save failed');
      console.error(err);
    }
  };

  return (
    <form className="grid-form" onSubmit={handleSave}>
      <div className="form-field">
        <label>Programming Language</label>
        <input name="language" value={entry.language} onChange={handleChange} />
      </div>
      <div className="form-field">
        <label>Experience Level</label>
        <select name="level" value={entry.level} onChange={handleChange}>
          <option value="">Select</option>
          <option value="Expert">Expert</option>
          <option value="Very good">Very good</option>
          <option value="Intermediate">Intermediate</option>
          <option value="Able to use/code">Able to use/code</option>
        </select>
      </div>
      <div className="form-field">
        <label>Year Last Used</label>
        <input name="lastUsed" type="number" placeholder="e.g., 2024" value={entry.lastUsed} onChange={handleChange} />
      </div>

      <button type="button" className="full-width" onClick={handleAddOrUpdate}>
        {editIndex !== null ? 'Update Language' : 'Add Language'}
      </button>

      {languages.length > 0 && (
        <table style={{ width: '200%', marginTop: '20px', borderCollapse: 'collapse', tableLayout: 'fixed' }}>
          <thead style={{ backgroundColor: '#f3f3f3' }}>
            <tr>
              <th style={{ width: '40%' }}>Skill</th>
              <th style={{ width: '20%' }}>Level</th>
              <th style={{ width: '20%' }}>Year Last Used</th>
              <th style={{ width: '20%' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {languages.map((item, index) => (
              <tr key={index} style={{ textAlign: 'center', borderBottom: '1px solid #ccc' }}>
                <td>{item.language}</td>
                <td>{item.level}</td>
                <td>{item.lastUsed}</td>
                <td>
                  <button type="button" onClick={() => handleEdit(index)} style={{ marginRight: '10px' }}>
                    <Pencil size={16} />
                  </button>
                  <button type="button" onClick={() => handleDelete(index)}>
                    <Trash2 size={16} color="red" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      <button type="submit" className="full-width" style={{ marginTop: '20px' }}>Save</button>
    </form>
  );
}

export default ProgrammingLanguages;
