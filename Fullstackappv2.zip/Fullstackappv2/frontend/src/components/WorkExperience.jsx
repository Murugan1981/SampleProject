import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Pencil, Trash2 } from 'lucide-react'; // You can use react-icons or any icon library

function WorkExperience() {
  const [exp, setExp] = useState({ company: '', designation: '', startDate: '', endDate: '' });
  const [experiences, setExperiences] = useState([]);
  const [editIndex, setEditIndex] = useState(null);
  const username = localStorage.getItem('username');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await axios.get(`http://localhost:5000/api/profile/work/${username}`);
        const data = Array.isArray(res.data) ? res.data : [res.data];
        setExperiences(data);
      } catch {
        console.log('No work experience data found');
      }
    };
    fetchData();
  }, [username]);

  const handleChange = (e) => {
    setExp({ ...exp, [e.target.name]: e.target.value });
  };

  const handleAddOrUpdate = () => {
    if (!exp.company || !exp.designation) return;
    if (editIndex !== null) {
      const updated = [...experiences];
      updated[editIndex] = exp;
      setExperiences(updated);
      setEditIndex(null);
    } else {
      setExperiences([...experiences, exp]);
    }
    setExp({ company: '', designation: '', startDate: '', endDate: '' });
  };

  const handleEdit = (index) => {
    setExp(experiences[index]);
    setEditIndex(index);
  };

  const handleDelete = (index) => {
    const updated = [...experiences];
    updated.splice(index, 1);
    setExperiences(updated);
    if (editIndex === index) setEditIndex(null);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/api/profile/work', {
        username,
        experiences
      });
      alert('All work experiences saved!');
    } catch (err) {
      alert('Save failed');
      console.error(err);
    }
  };

  return (
    <form className="grid-form" onSubmit={handleSave}>
      <div className="form-field">
        <label>Company Name</label>
        <input name="company" value={exp.company} onChange={handleChange} />
      </div>
      <div className="form-field">
        <label>Designation</label>
        <input name="designation" value={exp.designation} onChange={handleChange} />
      </div>
      <div className="form-field">
        <label>Start Date</label>
        <input type="date" name="startDate" value={exp.startDate} onChange={handleChange} />
      </div>
      <div className="form-field">
        <label>End Date</label>
        <input type="date" name="endDate" value={exp.endDate} onChange={handleChange} />
      </div>

      <button type="button" className="full-width" onClick={handleAddOrUpdate}>
        {editIndex !== null ? 'Update Experience' : 'Add Experience'}
      </button>

      {experiences.length > 0 && (
        <table style={{ width: '200%', marginTop: '20px', borderCollapse: 'collapse' }}>
          <thead style={{ backgroundColor: '#f3f3f3' }}>
            <tr>
              <th style={{ width: '20%' }}>Company</th>
              <th style={{ width: '20%' }}>Designation</th>
              <th style={{ width: '20%' }}>Start Date</th>
              <th style={{ width: '20%' }}>End Date</th>
              <th style={{ width: '20%' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {experiences.map((item, index) => (
              <tr key={index} style={{ textAlign: 'center', borderBottom: '1px solid #ccc' }}>
                <td>{item.company}</td>
                <td>{item.designation}</td>
                <td>{item.startDate}</td>
                <td>{item.endDate}</td>
                <td>
                  <button type="button" onClick={() => handleEdit(index)} style={{ marginRight: '10px' }}>
                    <Pencil size={16} />
                  </button>
                  <button type="button" onClick={() => handleDelete(index)}>
                    <Trash2 size={16} color="red" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      <button type="submit" className="full-width" style={{ marginTop: '20px' }}>Save</button>
    </form>
  );
}

export default WorkExperience;
