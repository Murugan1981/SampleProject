import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Pencil, Trash2 } from 'lucide-react';

function AIModelExperience() {
  const [entry, setEntry] = useState({ modelMake: '', modelName: '' });
  const [models, setModels] = useState([]);
  const [editIndex, setEditIndex] = useState(null);
  const username = localStorage.getItem('username');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await axios.get(`http://localhost:5000/api/profile/aimodels/${username}`);
        const raw = res.data?.modelName;
        if (raw) {
          const parsed = JSON.parse(raw);
          if (Array.isArray(parsed)) setModels(parsed);
          else setModels([]);
        } else {
          setModels([]);
        }
      } catch (err) {
        console.log('Error fetching AI model data:', err);
        setModels([]);
      }
    };
    fetchData();
  }, [username]);

  const handleChange = (e) => {
    setEntry({ ...entry, [e.target.name]: e.target.value });
  };

  const handleAddOrUpdate = () => {
    if (!entry.modelMake || !entry.modelName) return;

    const updated = [...models];
    if (editIndex !== null) {
      updated[editIndex] = entry;
      setEditIndex(null);
    } else {
      updated.push(entry);
    }
    setModels(updated);
    setEntry({ modelMake: '', modelName: '' });
  };

  const handleEdit = (index) => {
    setEntry(models[index]);
    setEditIndex(index);
  };

  const handleDelete = (index) => {
    const updated = [...models];
    updated.splice(index, 1);
    setModels(updated);
    if (editIndex === index) setEditIndex(null);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/api/profile/aimodels', {
        username,
        modelName: JSON.stringify(models)
      });
      alert('AI Models saved!');
    } catch (err) {
      alert('Save failed');
      console.error(err);
    }
  };

  return (
    <form className="grid-form" onSubmit={handleSave}>
      <div className="form-field">
        <label>Model Make</label>
        <input name="modelMake" value={entry.modelMake} onChange={handleChange} />
      </div>
      <div className="form-field">
        <label>Model Name</label>
        <input name="modelName" value={entry.modelName} onChange={handleChange} />
      </div>

      <button type="button" className="full-width" onClick={handleAddOrUpdate}>
        {editIndex !== null ? 'Update Model' : 'Add Model'}
      </button>

      {models.length > 0 && (
        <table style={{ width: '200%', marginTop: '20px', borderCollapse: 'collapse', tableLayout: 'fixed' }}>
          <thead style={{ backgroundColor: '#f3f3f3' }}>
            <tr>
              <th style={{ width: '40%' }}>Model Make</th>
              <th style={{ width: '40%' }}>Model Name</th>
              <th style={{ width: '20%' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {models.map((item, index) => (
              <tr key={index} style={{ textAlign: 'center', borderBottom: '1px solid #ccc' }}>
                <td>{item.modelMake}</td>
                <td>{item.modelName}</td>
                <td>
                  <button type="button" onClick={() => handleEdit(index)} style={{ marginRight: '10px' }}>
                    <Pencil size={16} />
                  </button>
                  <button type="button" onClick={() => handleDelete(index)}>
                    <Trash2 size={16} color="red" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      <button type="submit" className="full-width" style={{ marginTop: '20px' }}>Save</button>
    </form>
  );
}

export default AIModelExperience;

