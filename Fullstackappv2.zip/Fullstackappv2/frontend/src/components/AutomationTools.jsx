import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Pencil, Trash2 } from 'lucide-react';

function AutomationTools() {
  const [tool, setTool] = useState({ name: '', months: '' });
  const [tools, setTools] = useState([]);
  const [editIndex, setEditIndex] = useState(null);
  const username = localStorage.getItem('username');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await axios.get(`http://localhost:5000/api/profile/automation-tools/${username}`);
        const parsed = res.data?.tools ? JSON.parse(res.data.tools) : [];
        setTools(parsed);
      } catch {
        console.log('No automation tools found');
      }
    };
    fetchData();
  }, [username]);

  const handleChange = (e) => {
    setTool({ ...tool, [e.target.name]: e.target.value });
  };

  const handleAddOrUpdate = () => {
    if (!tool.name || !tool.months) return;
    const updatedTools = [...tools];
    if (editIndex !== null) {
      updatedTools[editIndex] = tool;
      setEditIndex(null);
    } else {
      updatedTools.push(tool);
    }
    setTools(updatedTools);
    setTool({ name: '', months: '' });
  };

  const handleEdit = (index) => {
    setTool(tools[index]);
    setEditIndex(index);
  };

  const handleDelete = (index) => {
    const updated = [...tools];
    updated.splice(index, 1);
    setTools(updated);
    if (editIndex === index) setEditIndex(null);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/api/profile/automation-tools', {
        username,
        tools: JSON.stringify(tools)
      });
      alert('Saved!');
    } catch {
      alert('Save failed');
    }
  };

  return (
    <form className="grid-form" onSubmit={handleSave}>
      <div className="form-field">
        <label>Tool Name</label>
        <input name="name" value={tool.name} onChange={handleChange} />
      </div>
      <div className="form-field">
        <label>Months of Experience</label>
        <input name="months" type="number" value={tool.months} onChange={handleChange} />
      </div>

      <button type="button" className="full-width" onClick={handleAddOrUpdate}>
        {editIndex !== null ? 'Update Tool' : 'Add Tool'}
      </button>

      {tools.length > 0 && (
        <table style={{ width: '200%', marginTop: '20px', borderCollapse: 'collapse', tableLayout: 'fixed' }}>
          <thead style={{ backgroundColor: '#f3f3f3' }}>
            <tr>
              <th style={{ width: '60%' }}>Tool</th>
              <th style={{ width: '20%' }}>Months</th>
              <th style={{ width: '20%' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {tools.map((item, index) => (
              <tr key={index} style={{ textAlign: 'center', borderBottom: '1px solid #ccc' }}>
                <td>{item.name}</td>
                <td>{item.months}</td>
                <td>
                  <button type="button" onClick={() => handleEdit(index)} style={{ marginRight: '10px' }}>
                    <Pencil size={16} />
                  </button>
                  <button type="button" onClick={() => handleDelete(index)}>
                    <Trash2 size={16} color="red" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      <button type="submit" className="full-width" style={{ marginTop: '20px' }}>Save</button>
    </form>
  );
}

export default AutomationTools;
