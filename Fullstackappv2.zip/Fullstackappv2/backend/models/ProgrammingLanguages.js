const { DataTypes } = require('sequelize');
const sequelize = require('../database');

const ProgrammingLanguages = sequelize.define('ProgrammingLanguages', {
  username: { type: DataTypes.STRING, allowNull: false, unique: true  },
languageData: { type: DataTypes.TEXT }  // to store JSON string for all languages
});

module.exports = ProgrammingLanguages;
