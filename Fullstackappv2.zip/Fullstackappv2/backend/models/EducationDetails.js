const { DataTypes } = require('sequelize');
const sequelize = require('../database'); 

const EducationDetails = sequelize.define('EducationDetails', {
  username: { type: DataTypes.STRING, allowNull: false },
  qualification: { type: DataTypes.STRING },
  educationCountry: { type: DataTypes.STRING },
  university: { type: DataTypes.STRING },
  cgpa: { type: DataTypes.STRING }
});

module.exports = EducationDetails;
