const { DataTypes } = require('sequelize');
const sequelize = require('../database');

const AIModelExperience = sequelize.define('AIModelExperience', {
  username: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true
  },
  modelName: {
    type: DataTypes.TEXT
  }
});

module.exports = AIModelExperience;


