const { DataTypes } = require('sequelize');
const sequelize = require('../database');

const PersonalDetails = sequelize.define('PersonalDetails', {
  username: { type: DataTypes.STRING, allowNull: false },
  firstName: { type: DataTypes.STRING },
  lastName: { type: DataTypes.STRING },
  telephone: { type: DataTypes.STRING },
  mobile: { type: DataTypes.STRING },
  dob: { type: DataTypes.STRING },
  maritalStatus: { type: DataTypes.STRING }
});

module.exports = PersonalDetails;
