const { DataTypes } = require('sequelize');
const sequelize = require('../database');

const Certifications = sequelize.define('Certifications', {
  username: { type: DataTypes.STRING, allowNull: false, unique: true },
  certificationData: { type: DataTypes.TEXT }  // JSON string of certifications
});

module.exports = Certifications;

