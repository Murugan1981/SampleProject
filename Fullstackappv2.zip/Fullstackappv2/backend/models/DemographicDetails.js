const { DataTypes } = require('sequelize');
const sequelize = require('../database');

const DemographicDetails = sequelize.define('DemographicDetails', {
  username: { type: DataTypes.STRING, allowNull: false },
  address1: { type: DataTypes.STRING },
  address2: { type: DataTypes.STRING },
  city: { type: DataTypes.STRING },
  state: { type: DataTypes.STRING },
  country: { type: DataTypes.STRING }, 
  zipCode: { type: DataTypes.STRING }
});

module.exports = DemographicDetails;
