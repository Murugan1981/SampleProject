const { DataTypes } = require('sequelize');
const sequelize = require('../database');

const AwardsReceived = sequelize.define('AwardsReceived', {
  username: { type: DataTypes.STRING, allowNull: false, unique: true },
  awardData: { type: DataTypes.TEXT } // JSON string for all awards
});

module.exports = AwardsReceived;
