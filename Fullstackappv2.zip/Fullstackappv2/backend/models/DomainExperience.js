const { DataTypes } = require('sequelize');
const sequelize = require('../database');

const DomainExperience = sequelize.define('DomainExperience', {
  username: { type: DataTypes.STRING, allowNull: false, unique: true },
  domain: { type: DataTypes.TEXT }
});

module.exports = DomainExperience;
