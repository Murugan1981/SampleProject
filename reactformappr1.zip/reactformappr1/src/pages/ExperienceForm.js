
import { useState } from 'react';

function ExperienceForm() {
  const [formData, setFormData] = useState({ company: '', years: '' });
  const handleChange = (e) => { const { id, value } = e.target; setFormData(prev => ({ ...prev, [id]: value })); };
  const handleSubmit = (e) => { e.preventDefault(); console.log('Experience Submitted:', formData); };
  return (
    <form style={{ maxWidth: '400px', margin: 'auto', display: 'flex', flexDirection: 'column', gap: '10px' }} onSubmit={handleSubmit}>
      <label htmlFor="company">Company</label>
      <input type="text" id="company" value={formData.company} onChange={handleChange} />
      <label htmlFor="years">Years of Experience</label>
      <input type="text" id="years" value={formData.years} onChange={handleChange} />
      <button type="submit">Save</button>
    </form>
  );
}
export default ExperienceForm;
