
import { useState } from 'react';

function EducationForm() {
  const [formData, setFormData] = useState({ degree: '', university: '' });
  const handleChange = (e) => { const { id, value } = e.target; setFormData(prev => ({ ...prev, [id]: value })); };
  const handleSubmit = (e) => { e.preventDefault(); console.log('Education Submitted:', formData); };
  return (
    <form style={{ maxWidth: '400px', margin: 'auto', display: 'flex', flexDirection: 'column', gap: '10px' }} onSubmit={handleSubmit}>
      <label htmlFor="degree">Degree</label>
      <input type="text" id="degree" value={formData.degree} onChange={handleChange} />
      <label htmlFor="university">University</label>
      <input type="text" id="university" value={formData.university} onChange={handleChange} />
      <button type="submit">Save</button>
    </form>
  );
}
export default EducationForm;
