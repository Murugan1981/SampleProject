
import { useState } from 'react';

function MainForm() {
  const [formData, setFormData] = useState({
    lastname: '', sex: 'Male', dob: '', state: '', country: '',
    pincode: '', phone: '', email: '', comments: '', firstname: '', middlename: ''
  });

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const handleSubmit = (e) => { e.preventDefault(); console.log('Form Submitted:', formData); };

  const formStyle = { maxWidth: '500px', margin: 'auto', display: 'flex', flexDirection: 'column', gap: '10px' };

  return (
    <form style={formStyle} onSubmit={handleSubmit}>
      <label htmlFor="lastname">Last Name</label>
      <input type="text" id="lastname" value={formData.lastname} onChange={handleChange} />

      <label htmlFor="gender">Gender</label>
      <select id="gender" value={formData.gender} onChange={handleChange}>
        <option>Male</option><option>Female</option>
      </select>

      <label htmlFor="dob">Date of Birth</label>
      <input type="text" id="dob" placeholder="DD/MM/YYYY" value={formData.dob} onChange={handleChange} />

      <label htmlFor="state">State</label>
      <select id="state" value={formData.state} onChange={handleChange}>
        <option value="">Select state</option><option>Tamil Nadu</option><option>Karnataka</option>
      </select>

      <label htmlFor="country">Country</label>
      <select id="country" value={formData.country} onChange={handleChange}>
        <option value="">Select country</option><option>India</option><option>Singapore</option>
      </select>

      <label htmlFor="pincode">Pincode</label>
      <input type="text" id="pincode" value={formData.pincode} onChange={handleChange} />

      <label htmlFor="phone">Telephone</label>
      <input type="text" id="phone" value={formData.phone} onChange={handleChange} />

      <label htmlFor="email">Email</label>
      <input type="email" id="email" value={formData.email} onChange={handleChange} />

      <label htmlFor="comments">Comments</label>
      <textarea id="comments" value={formData.comments} onChange={handleChange} placeholder="Enter comments" />

      <label htmlFor="firstname">First Name (Updated)</label>
      <input type="text" id="firstname" value={formData.firstname} onChange={handleChange} />

      <label htmlFor="middlename">Middle Name</label>
      <input type="text" id="middlename" value={formData.middlename} onChange={handleChange} />

      <button type="submit">Save</button>
    </form>
  );
}

export default MainForm;
