
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import MainForm from './pages/MainForm';
import EducationForm from './pages/EducationForm';
import ExperienceForm from './pages/ExperienceForm';

function App() {
  return (
    <Router>
      <nav style={{ marginBottom: '20px' }}>
        <Link to="/">Main</Link> | 
        <Link to="/education">Education</Link> | 
        <Link to="/experience">Experience</Link>
      </nav>
      <Routes>
        <Route path="/" element={<MainForm />} />
        <Route path="/education" element={<EducationForm />} />
        <Route path="/experience" element={<ExperienceForm />} />
      </Routes>
    </Router>
  );
}

export default App;
