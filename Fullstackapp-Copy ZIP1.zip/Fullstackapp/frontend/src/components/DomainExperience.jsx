import React, { useEffect, useState } from 'react';
import axios from 'axios';

function DomainExperience() {
  const [domain, setDomain] = useState('');

  useEffect(() => {
    const username = localStorage.getItem('username');
    axios.get(`http://localhost:5000/api/profile/domain/${username}`)
      .then(res => {
        if (res.data?.domain) setDomain(res.data.domain);
      })
      .catch(() => console.log('No domain data found'));
  }, []);

  const handleSave = async () => {
    const username = localStorage.getItem('username');
    try {
      await axios.post('http://localhost:5000/api/profile/domain', { username, domain });
      alert('Saved successfully');
    } catch (err) {
      alert('Save failed');
      console.error(err);
    }
  };

  return (
    <form className="grid-form">
      <div className="form-field">
        <label>Domain Experience</label>
        <input
          type="text"
          value={domain}
          onChange={e => setDomain(e.target.value)}
        />
      </div>
      <button type="button" className="full-width" onClick={handleSave}>Save</button>
    </form>
  );
}

export default DomainExperience;
