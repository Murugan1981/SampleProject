import React, { useEffect, useState } from 'react';
import axios from 'axios';

function ExtraCurricularActivities() {
  const [activity, setActivity] = useState('');

  useEffect(() => {
    const username = localStorage.getItem('username');
    axios.get(`http://localhost:5000/api/profile/extracurricular/${username}`)
      .then(res => {
        if (res.data?.activity) setActivity(res.data.activity);
      })
      .catch(err => console.log('No activity found'));
  }, []);

  const handleSave = async (e) => {
    e.preventDefault();
    const username = localStorage.getItem('username');
    try {
      await axios.post('http://localhost:5000/api/profile/extracurricular', { username, activity });
      alert('Saved!');
    } catch (err) {
      alert('Save failed');
    }
  };

  return (
    <form className="grid-form" onSubmit={handleSave}>
      <div className="form-field full-width">
        <label>Extra Curricular Activity</label>
        <input type="text" value={activity} onChange={(e) => setActivity(e.target.value)} />
      </div>
      <button type="submit" className="full-width">Save</button>
    </form>
  );
}

export default ExtraCurricularActivities;

