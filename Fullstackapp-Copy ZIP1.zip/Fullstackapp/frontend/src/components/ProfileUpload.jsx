import React, { useState } from 'react';
import axios from 'axios';

function ProfileUpload() {
  const username = localStorage.getItem('username');
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);

  const handleChange = (e) => {
    const file = e.target.files[0];
    setSelectedFile(file);
    setPreviewUrl(URL.createObjectURL(file));
  };

  const handleUpload = async () => {
    if (!selectedFile) return alert('Please choose a file first.');
    const formData = new FormData();
    formData.append('username', username);
    formData.append('profileImage', selectedFile);

    try {
      await axios.post('http://localhost:5000/api/profile/upload-photo', formData);
      alert('Profile image uploaded!');
    } catch (err) {
      alert('Upload failed');
    }
  };

  return (
    <form className="grid-form" onSubmit={(e) => e.preventDefault()}>
      <div className="form-field full-width">
        <label>Upload Profile Photo</label>
        <input type="file" accept="image/*" onChange={handleChange} />
      </div>

      {previewUrl && (
        <div className="full-width">
          <img src={previewUrl} alt="Preview" style={{ width: '120px', height: '120px', borderRadius: '10px' }} />
        </div>
      )}

      <button type="submit" className="full-width" onClick={handleUpload}>Save</button>
    </form>
  );
}

export default ProfileUpload;
