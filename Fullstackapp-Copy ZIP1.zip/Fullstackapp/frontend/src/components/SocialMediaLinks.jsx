import React, { useState, useEffect } from 'react';
import axios from 'axios';

function SocialMediaLinks() {
  const username = localStorage.getItem('username');
  const [links, setLinks] = useState([]);
  const [entry, setEntry] = useState({ platform: '', url: '' });

  useEffect(() => {
    axios.get(`http://localhost:5000/api/profile/social-links/${username}`)
      .then(res => res.data && setLinks(res.data))
      .catch(() => {});
  }, [username]);

  const handleChange = (e) => setEntry({ ...entry, [e.target.name]: e.target.value });

  const handleAdd = () => {
    if (entry.platform.trim() && entry.url.trim()) {
      setLinks([...links, entry]);
      setEntry({ platform: '', url: '' });
    }
  };

  const handleDelete = (index) => {
    const updated = [...links];
    updated.splice(index, 1);
    setLinks(updated);
  };

  const handleSave = async () => {
    try {
      await axios.post('http://localhost:5000/api/profile/social-links', {
        username,
        links
      });
      alert('Social media links saved!');
    } catch {
      alert('Save failed');
    }
  };

  return (
    <form className="grid-form" onSubmit={e => e.preventDefault()}>
      <div className="form-field">
        <label>Platform</label>
        <input name="platform" value={entry.platform} onChange={handleChange} />
      </div>
      <div className="form-field">
        <label>Profile URL</label>
        <input name="url" value={entry.url} onChange={handleChange} />
      </div>

      <button type="button" className="full-width" onClick={handleAdd}>Add Link</button>

      {links.map((item, idx) => (
        <div className="full-width" key={idx}>
          <p>{item.platform} — <a href={item.url} target="_blank" rel="noreferrer">{item.url}</a></p>
          <button type="button" onClick={() => handleDelete(idx)}>Delete</button>
        </div>
      ))}

      <button type="submit" className="full-width" onClick={handleSave}>Save</button>
    </form>
  );
}

export default SocialMediaLinks;
