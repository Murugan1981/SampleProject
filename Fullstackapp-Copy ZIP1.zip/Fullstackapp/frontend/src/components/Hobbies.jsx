import React, { useState, useEffect } from 'react';
import axios from 'axios';

function Hobbies() {
  const username = localStorage.getItem('username');
  const [hobbies, setHobbies] = useState([]);
  const [entry, setEntry] = useState({ name: '' });

  useEffect(() => {
    axios.get(`http://localhost:5000/api/profile/hobbies/${username}`)
      .then(res => res.data && setHobbies(res.data))
      .catch(() => {});
  }, [username]);

  const handleChange = (e) => setEntry({ ...entry, [e.target.name]: e.target.value });

  const handleAdd = () => {
    if (entry.name.trim()) {
      setHobbies([...hobbies, entry]);
      setEntry({ name: '' });
    }
  };

  const handleDelete = (index) => {
    const updated = [...hobbies];
    updated.splice(index, 1);
    setHobbies(updated);
  };

  const handleSave = async () => {
    try {
      await axios.post('http://localhost:5000/api/profile/hobbies', {
        username,
        hobbies
      });
      alert('Hobbies saved!');
    } catch {
      alert('Save failed');
    }
  };

  return (
    <form className="grid-form" onSubmit={e => e.preventDefault()}>
      <div className="form-field">
        <label>Hobby</label>
        <input name="name" value={entry.name} onChange={handleChange} />
      </div>

      <button type="button" className="full-width" onClick={handleAdd}>Add Hobby</button>

      {hobbies.map((item, idx) => (
        <div className="full-width" key={idx}>
          <p>{item.name}</p>
          <button type="button" onClick={() => handleDelete(idx)}>Delete</button>
        </div>
      ))}

      <button type="submit" className="full-width" onClick={handleSave}>Save</button>
    </form>
  );
}

export default Hobbies;
