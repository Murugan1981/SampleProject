import React, { useState, useEffect } from 'react';
import axios from 'axios';

function FrameworkKnowledge() {
  const [frameworks, setFrameworks] = useState('');

  useEffect(() => {
  const username = localStorage.getItem('username');
  axios.get(`http://localhost:5000/api/profile/frameworks/${username}`)
    .then(res => {
      const data = res.data?.framework || '';
      setFrameworks(Array.isArray(data) ? data : data.split(',').map(f => f.trim()));
    })
    .catch(() => setFrameworks([]));
}, []);

  const handleChange = (e) => {
    setFrameworks(e.target.value);
  };

  const handleSave = async () => {
  const username = localStorage.getItem('username');
  try {
    await axios.post('http://localhost:5000/api/profile/frameworks', {
      username,
      framework: frameworks.join(', ')
    });
    alert('Saved!');
  } catch (err) {
    alert('Save failed');
    console.error(err);
  }
};


  return (
    <form className="grid-form" onSubmit={(e) => e.preventDefault()}>
      <div className="form-field">
        <label>Frameworks</label>
        <input
          type="text"
          name="framework"
          value={frameworks}
          onChange={handleChange}
        />
      </div>

      <div className="form-field full-width">
        <button type="button" onClick={handleSave} className="full-width">Save</button>
      </div>
    </form>
  );
}

export default FrameworkKnowledge;



