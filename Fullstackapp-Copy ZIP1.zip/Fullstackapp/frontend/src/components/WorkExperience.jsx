import React, { useState, useEffect } from 'react';
import axios from 'axios';

function WorkExperience() {
  const [exp, setExp] = useState({ company: '', designation: '', startDate: '', endDate: '' });
  const [experiences, setExperiences] = useState([]);

  const username = localStorage.getItem('username');

  useEffect(() => {
  const fetchData = async () => {
    try {
      const res = await axios.get(`http://localhost:5000/api/profile/work/${username}`);
      if (res.data) {
        // If a single object is returned instead of an array
        const data = Array.isArray(res.data) ? res.data : [res.data];
        setExperiences(data);
      }
    } catch (err) {
      console.log('No work experience data found');
    }
  };
  fetchData();
}, [username]);

  const handleChange = (e) => {
    setExp({ ...exp, [e.target.name]: e.target.value });
  };

  const handleAdd = () => {
    if (exp.company && exp.designation) {
      setExperiences([...experiences, exp]);
      setExp({ company: '', designation: '', startDate: '', endDate: '' });
    }
  };

  const handleDelete = (index) => {
    const updated = [...experiences];
    updated.splice(index, 1);
    setExperiences(updated);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/api/profile/work', {
        username,
        experiences
      });
      alert('Saved!');
    } catch (err) {
      alert('Save failed');
      console.error(err);
    }
  };

  return (
    <form className="grid-form" onSubmit={handleSave}>
      <div className="form-field">
        <label>Company Name</label>
        <input name="company" value={exp.company} onChange={handleChange} />
      </div>
      <div className="form-field">
        <label>Designation</label>
        <input name="designation" value={exp.designation} onChange={handleChange} />
      </div>
      <div className="form-field">
        <label>Start Date</label>
        <input type="date" name="startDate" value={exp.startDate} onChange={handleChange} />
      </div>
      <div className="form-field">
        <label>End Date</label>
        <input type="date" name="endDate" value={exp.endDate} onChange={handleChange} />
      </div>

      <button type="button" className="full-width" onClick={handleAdd}>Add Experience</button>
      <button type="submit" className="full-width">Save</button>

      {experiences.map((item, index) => (
        <div key={index} className="form-field full-width">
          <p><strong>{item.company}</strong> - {item.designation} ({item.startDate} to {item.endDate})</p>
          <button type="button" onClick={() => handleDelete(index)}>Delete</button>
        </div>
      ))}
    </form>
  );
}

export default WorkExperience;
