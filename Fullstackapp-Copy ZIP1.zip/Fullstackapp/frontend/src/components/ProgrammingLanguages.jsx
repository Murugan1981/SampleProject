import React, { useState } from 'react';

function ProgrammingLanguages() {
  const [languages, setLanguages] = useState([]);
  const [entry, setEntry] = useState({ language: '', level: '' });

  const handleChange = (e) => {
    setEntry({ ...entry, [e.target.name]: e.target.value });
  };

  const handleAdd = () => {
    if (entry.language && entry.level) {
      setLanguages([...languages, entry]);
      setEntry({ language: '', level: '' });
    }
  };

  const handleDelete = (index) => {
    const list = [...languages];
    list.splice(index, 1);
    setLanguages(list);
  };

  const handleSave = async () => {
  try {
    await axios.post('http://localhost:5000/api/profile/programming-languages', {
      username,
      languages
    });
    alert('Languages saved!');
  } catch {
    alert('Save failed');
  }
};

  return (
    <form className="grid-form" onSubmit={(e) => e.preventDefault()}>
      <div className="form-field">
        <label>Programming Language</label>
        <input name="language" value={entry.language} onChange={handleChange} />
      </div>
      <div className="form-field">
        <label>Experience Level</label>
        <select name="level" value={entry.level} onChange={handleChange}>
          <option value="">Select</option>
          <option value="Expert">Expert</option>
          <option value="Very good">Very good</option>
          <option value="Intermediate">Intermediate</option>
          <option value="Able to use/code">Able to use/code</option>
        </select>
      </div>

      <button type="button" className="full-width" onClick={handleAdd}>Add Language</button>

      {languages.map((item, idx) => (
        <div className="full-width" key={idx}>
          <p>{item.language} - {item.level}</p>
          <button type="button" onClick={() => handleDelete(idx)}>Delete</button>
        </div>
      ))}
       <button type="submit" className="full-width" onClick={handleSave}>Save</button>
    </form>
  );
}

export default ProgrammingLanguages;
