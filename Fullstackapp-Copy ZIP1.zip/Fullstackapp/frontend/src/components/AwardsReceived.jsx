import React, { useEffect, useState } from 'react';
import axios from 'axios';

function AwardsReceived() {
  const [form, setForm] = useState({
    awardName: '',
    issuingAuthority: ''
  });

  useEffect(() => {
    const username = localStorage.getItem('username');
    axios.get(`http://localhost:5000/api/profile/awards/${username}`)
      .then(res => {
        if (res.data) {
          setForm(res.data);
        }
      })
      .catch(err => console.log('No award found:', err));
  }, []);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSave = async () => {
    const username = localStorage.getItem('username');

    try {
      await axios.post('http://localhost:5000/api/profile/awards', {
        username,
        awardName: form.awardName,
        issuingAuthority: form.issuingAuthority
      });
      alert('Award saved!');
    } catch (err) {
      alert('Error saving award');
      console.error(err);
    }
  };

  return (
    <form className="grid-form" onSubmit={(e) => { e.preventDefault(); handleSave(); }}>
      <div className="form-field">
        <label>Award Title</label>
        <input type="text" name="awardName" value={form.awardName} onChange={handleChange} />
      </div>
      <div className="form-field">
        <label>Issued By</label>
        <input type="text" name="issuingAuthority" value={form.issuingAuthority} onChange={handleChange} />
      </div>
      <button type="submit" className="full-width">Save</button>
    </form>
  );
}

export default AwardsReceived;

