import React, { useState, useEffect } from 'react';
import axios from 'axios';

function AIModelExperience() {
  const [form, setForm] = useState({
    modelMake: '',
    modelName: ''
  });

  const username = localStorage.getItem('username');

  useEffect(() => {
    axios.get(`http://localhost:5000/api/profile/aimodels/${username}`)
      .then(res => {
        if (res.data) setForm(res.data);
      })
      .catch(() => console.log('No AI model experience found'));
  }, [username]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSave = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/api/profile/aimodels', {
        username,
        ...form
      });
      alert('Saved!');
    } catch (err) {
      alert('Save failed');
      console.error(err);
    }
  };

  return (
    <form className="grid-form" onSubmit={handleSave}>
      <div className="form-field">
        <label>Model Make</label>
        <input type="text" name="modelMake" value={form.modelMake} onChange={handleChange} />
      </div>

      <div className="form-field">
        <label>Model Name</label>
        <input type="text" name="modelName" value={form.modelName} onChange={handleChange} />
      </div>

      <button type="submit" className="full-width">Save</button>
    </form>
  );
}

export default AIModelExperience;

