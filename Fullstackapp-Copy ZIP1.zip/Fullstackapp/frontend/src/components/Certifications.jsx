import React, { useState } from 'react';

function Certifications() {
  const [certs, setCerts] = useState([]);
  const [cert, setCert] = useState({ name: '', id: '', completion: '' });

  const handleChange = (e) => {
    setCert({ ...cert, [e.target.name]: e.target.value });
  };

  const handleAdd = () => {
    if (cert.name && cert.completion) {
      setCerts([...certs, cert]);
      setCert({ name: '', id: '', completion: '' });
    }
  };

  const handleDelete = (index) => {
    const list = [...certs];
    list.splice(index, 1);
    setCerts(list);
  };

  const handleSave = async () => {
  try {
    await axios.post('http://localhost:5000/api/profile/certifications', {
      username,
      certs
    });
    alert('Certifications saved!');
  } catch {
    alert('Save failed');
  }
};

  return (
    <form className="grid-form" onSubmit={(e) => e.preventDefault()}>
      <div className="form-field">
        <label>Certification Name</label>
        <input name="name" value={cert.name} onChange={handleChange} />
      </div>
      <div className="form-field">
        <label>Certificate ID</label>
        <input name="id" value={cert.id} onChange={handleChange} />
      </div>
      <div className="form-field">
        <label>Month/Year of Completion</label>
        <input name="completion" type="month" value={cert.completion} onChange={handleChange} />
      </div>

      <button type="button" className="full-width" onClick={handleAdd}>Add Certification</button>

      {certs.map((item, index) => (
        <div className="full-width" key={index}>
          <p>{item.name} ({item.id}) - {item.completion}</p>
          <button type="button" onClick={() => handleDelete(index)}>Delete</button>
        </div>
      ))}

      <button type="submit" className="full-width" onClick={handleSave}>Save</button>
    </form>
  );
}

export default Certifications;
