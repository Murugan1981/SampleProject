import React, { useState, useEffect } from 'react';
import axios from 'axios';

function AutomationTools() {
  const [tools, setTools] = useState('');

  useEffect(() => {
    const username = localStorage.getItem('username');
    axios.get(`http://localhost:5000/api/profile/automation-tools/${username}`)
      .then(res => res.data && setTools(res.data.tools || ''))
      .catch(() => console.log('No existing automation tools found'));
  }, []);

  const handleChange = (e) => setTools(e.target.value);

  const handleSave = async (e) => {
    e.preventDefault();
    const username = localStorage.getItem('username');
    try {
      await axios.post('http://localhost:5000/api/profile/automation-tools', { username, tools });
      alert('Saved!');
    } catch (err) {
      alert('Error saving automation tools');
    }
  };

  return (
    <form className="grid-form" onSubmit={handleSave}>
      <div className="form-field full-width">
        <label>Automation Tools</label>
        <input type="text" value={tools} onChange={handleChange} placeholder="e.g., Selenium, Playwright, Cypress" />
      </div>
      <button type="submit" className="full-width">Save</button>
    </form>
  );
}

export default AutomationTools;

