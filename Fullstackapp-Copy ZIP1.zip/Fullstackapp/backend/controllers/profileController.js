const PersonalDetails = require('../models/PersonalDetails');
const DemographicDetails = require('../models/DemographicDetails');
const EducationDetails = require('../models/EducationDetails');
const WorkExperience = require('../models/WorkExperience');
const AutomationTools = require('../models/AutomationTools');
const ProgrammingLanguages = require('../models/ProgrammingLanguages');
const Certifications = require('../models/Certifications');
const AwardsReceived = require('../models/AwardsReceived');
const FrameworkKnowledge = require('../models/FrameworkKnowledge');
const DomainExperience = require('../models/DomainExperience');
const AIModelExperience = require('../models/AIModelExperience');
const ExtraCurricularActivities = require('../models/ExtraCurricularActivities');
const Hobbies = require('../models/Hobbies');
const SocialMediaLinks = require('../models/SocialMediaLinks');
const ProfileImage = require('../models/ProfileImage');









exports.savePersonalDetails = async (req, res) => {
  const { username, firstName, lastName, telephone, mobile, dob, maritalStatus } = req.body;

  try {
    await PersonalDetails.upsert({
      username,
      firstName,
      lastName,
      telephone,
      mobile,
      dob,
      maritalStatus
    });

    res.status(200).json({ message: 'Personal details saved successfully' });
  } catch (err) {
    console.error('Save error:', err);
    res.status(500).json({ error: 'Failed to save personal details' });
  }
};

exports.saveDemographicDetails = async (req, res) => {
  const { username, address1, address2, city, state, country, zipCode } = req.body;

  try {
    await DemographicDetails.upsert({
      username,            
      address1,
      address2,
      city,
      state,
      country,
      zipCode
    });

    res.status(200).json({ message: 'Demographic details saved successfully' });
  } catch (err) {
    console.error('Error saving demographic details:', err);
    res.status(500).json({ error: 'Failed to save demographic details' });
  }
};


// --- Education Details ---
exports.saveEducationDetails = async (req, res) => {
  const { username, qualification, educationCountry, university, cgpa } = req.body;

  try {
    await EducationDetails.upsert({
      username,
      qualification,
      educationCountry, // 👈 this must match model field
      university,
      cgpa
    });

    res.status(200).json({ message: 'Education details saved successfully' });
  } catch (err) {
    console.error('Error saving education details:', err);
    res.status(500).json({ error: 'Failed to save education details' });
  }
};

exports.getEducationDetails = async (req, res) => {
  const { username } = req.params;
  try {
    const data = await EducationDetails.findOne({ where: { username } });
    if (data) res.json(data);
    else res.status(404).json({});
  } catch (err) {
    console.error('Failed to fetch education details:', err);
    res.status(500).json({ error: 'Failed to fetch education details' });
  }
};




// --- Work Experience ---
exports.saveWorkExperience = async (req, res) => {
  const { username, company, designation, startDate, endDate } = req.body;

  try {
    await WorkExperience.upsert({
      username,
      company,
      designation,
      startDate,
      endDate
    });

    res.status(200).json({ message: 'Work experience saved successfully' });
  } catch (err) {
    console.error('Error saving work experience:', err);
    res.status(500).json({ error: 'Failed to save work experience' });
  }
};


// --- Automation Tools ---
exports.saveAutomationTools = async (req, res) => {
  const { username, tools } = req.body;
  try {
    await AutomationTools.upsert({ username, tools });
    res.status(200).json({ message: 'Automation tools saved successfully' });
  } catch (err) {
    console.error('Error saving automation tools:', err);
    res.status(500).json({ error: 'Failed to save automation tools' });
  }
};

// --- Programming Languages ---
exports.saveProgrammingLanguage = async (req, res) => {
  const { username, language, experienceLevel } = req.body;

  try {
    await ProgrammingLanguages.upsert({
      username,
      language,
      experienceLevel
    });

    res.status(200).json({ message: 'Programming language saved successfully' });
  } catch (err) {
    console.error('Error saving programming language:', err);
    res.status(500).json({ error: 'Failed to save programming language' });
  }
};


// --- Certifications ---
exports.saveCertification = async (req, res) => {
  const { username, name, certificateId, completionDate } = req.body;

  try {
    await Certifications.upsert({
      username,
      name,
      certificateId,
      completionDate
    });

    res.status(200).json({ message: 'Certification saved successfully' });
  } catch (err) {
    console.error('Error saving certification:', err);
    res.status(500).json({ error: 'Failed to save certification' });
  }
};


// --- Awards Received ---
exports.saveAward = async (req, res) => {
  const { username, awardName, issuingAuthority } = req.body;

  try {
    await AwardsReceived.upsert({
      username,
      awardName,
      issuingAuthority
    });

    res.status(200).json({ message: 'Award saved successfully' });
  } catch (err) {
    console.error('Error saving award:', err);
    res.status(500).json({ error: 'Failed to save award' });
  }
};


// --- Framework Knowledge ---
exports.saveFrameworkKnowledge = async (req, res) => {
  const { username, framework } = req.body;

  try {
    await FrameworkKnowledge.upsert({
      username,
      framework
    });

    res.status(200).json({ message: 'Framework knowledge saved successfully' });
  } catch (err) {
    console.error('Error saving framework knowledge:', err);
    res.status(500).json({ error: 'Failed to save framework knowledge' });
  }
};


// --- Domain Experience ---

exports.saveDomainExperience = async (req, res) => {
  const { username, domain } = req.body;

  try {
    await DomainExperience.upsert({
      username,
      domain
    });

    res.status(200).json({ message: 'Domain experience saved successfully' });
  } catch (err) {
    console.error('Error saving domain experience:', err);
    res.status(500).json({ error: 'Failed to save domain experience' });
  }
};



// --- AI Model Experience ---
exports.saveAIModelExperience = async (req, res) => {
  const { username, modelMake, modelName } = req.body;

  try {
    await AIModelExperience.upsert({
      username,
      modelMake,
      modelName
    });

    res.status(200).json({ message: 'AI model experience saved successfully' });
  } catch (err) {
    console.error('Error saving AI model experience:', err);
    res.status(500).json({ error: 'Failed to save AI model experience' });
  }
};


// --- Extra Curricular Activities ---
exports.saveExtraCurricular = async (req, res) => {
  const { username, activity } = req.body;

  try {
    await ExtraCurricularActivities.upsert({
      username,
      activity
    });

    res.status(200).json({ message: 'Extra curricular activity saved successfully' });
  } catch (err) {
    console.error('Error saving extra curricular activity:', err);
    res.status(500).json({ error: 'Failed to save extra curricular activity' });
  }
};

// --- Hobbies ---
exports.saveHobby = async (req, res) => {
  const { username, hobby } = req.body;

  try {
    await Hobbies.upsert({
      username,
      hobby
    });

    res.status(200).json({ message: 'Hobby saved successfully' });
  } catch (err) {
    console.error('Error saving hobby:', err);
    res.status(500).json({ error: 'Failed to save hobby' });
  }
};

// --- Social Media Links ---
exports.saveSocialMediaLinks = async (req, res) => {
  const { username, platform, link } = req.body;

  try {
    await SocialMediaLinks.upsert({
      username,
      platform,
      link
    });

    res.status(200).json({ message: 'Social media link saved successfully' });
  } catch (err) {
    console.error('Error saving social media link:', err);
    res.status(500).json({ error: 'Failed to save social media link' });
  }
};

// --- ProfileUpload ---
exports.saveProfileUpload = async (req, res) => {
  const { username, filePath } = req.body;

  try {
    await ProfileUpload.upsert({
      username,
      filePath
    });

    res.status(200).json({ message: 'Profile picture path saved successfully' });
  } catch (err) {
    console.error('Error saving profile upload:', err);
    res.status(500).json({ error: 'Failed to save profile upload' });
  }
};





