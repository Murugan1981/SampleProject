const { DataTypes } = require('sequelize');
const sequelize = require('../database');

const FrameworkKnowledge = sequelize.define('FrameworkKnowledge', {
  username: { type: DataTypes.STRING, allowNull: false, unique: true },
  framework: { type: DataTypes.TEXT }  // Must match key used in save call
});


module.exports = FrameworkKnowledge;