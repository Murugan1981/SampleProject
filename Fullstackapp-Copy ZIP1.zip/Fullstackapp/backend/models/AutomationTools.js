const { DataTypes } = require('sequelize');
const sequelize = require('../database');

const AutomationTools = sequelize.define('AutomationTools', {
  username: { type: DataTypes.STRING, allowNull: false },
  tools: { type: DataTypes.STRING } // comma-separated or single string
});

module.exports = AutomationTools;

