const { DataTypes } = require('sequelize');
const sequelize = require('../database');

const ProfileImage = sequelize.define('ProfileImage', {
  username: { type: DataTypes.STRING, allowNull: false },
  filePath: { type: DataTypes.STRING }
});

module.exports = ProfileImage;