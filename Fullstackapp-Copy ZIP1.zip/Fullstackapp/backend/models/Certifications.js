const { DataTypes } = require('sequelize');
const sequelize = require('../database');

const Certifications = sequelize.define('Certifications', {
  username: { type: DataTypes.STRING, allowNull: false },
  name: { type: DataTypes.STRING },
  certId: { type: DataTypes.STRING },
  completionDate: { type: DataTypes.STRING }
});

module.exports = Certifications;