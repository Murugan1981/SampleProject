const { DataTypes } = require('sequelize');
const sequelize = require('../database');

const ProgrammingLanguages = sequelize.define('ProgrammingLanguages', {
  username: { type: DataTypes.STRING, allowNull: false },
  language: { type: DataTypes.STRING },
  level: { type: DataTypes.STRING }
});

module.exports = ProgrammingLanguages;