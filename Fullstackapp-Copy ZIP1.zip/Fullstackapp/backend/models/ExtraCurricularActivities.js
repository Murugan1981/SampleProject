const { DataTypes } = require('sequelize');
const sequelize = require('../database');

const ExtraCurricularActivities = sequelize.define('ExtraCurricularActivities', {
  username: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true, 
  },
  activity: {
    type: DataTypes.STRING
  }
});

module.exports = ExtraCurricularActivities;
