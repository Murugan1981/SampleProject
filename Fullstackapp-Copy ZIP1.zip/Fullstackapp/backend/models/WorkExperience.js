const { DataTypes } = require('sequelize');
const sequelize = require('../database');

const WorkExperience = sequelize.define('WorkExperience', {
  username: { type: DataTypes.STRING, allowNull: false },
  company: { type: DataTypes.STRING },
  designation: { type: DataTypes.STRING },
  startDate: { type: DataTypes.DATEONLY },
  endDate: { type: DataTypes.DATEONLY }
});

module.exports = WorkExperience;