const { DataTypes } = require('sequelize');
const sequelize = require('../database');

const Hobbies = sequelize.define('Hobbies', {
  username: { type: DataTypes.STRING, allowNull: false },
  name: { type: DataTypes.STRING }
});

module.exports = Hobbies;