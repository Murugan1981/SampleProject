const { DataTypes } = require('sequelize');
const sequelize = require('../database');

const SocialMediaLinks = sequelize.define('SocialMediaLinks', {
  username: { type: DataTypes.STRING, allowNull: false },
  platform: { type: DataTypes.STRING },
  url: { type: DataTypes.STRING }
});

module.exports = SocialMediaLinks;