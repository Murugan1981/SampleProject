const express = require('express');
const cors = require('cors');
const sequelize = require('./database');
const authRoutes = require('./routes/authRoutes');
const profileRoutes = require('./routes/profileRoutes');
require('./models/User');
require('./models/PersonalDetails');
require('./models/DemographicDetails');
require('./models/EducationDetails');
require('./models/WorkExperience');
require('./models/AutomationTools');
require('./models/ProgrammingLanguages');
require('./models/Certifications');
require('./models/AwardsReceived');
require('./models/FrameworkKnowledge');
require('./models/DomainExperience');
require('./models/AIModelExperience');
require('./models/ExtraCurricularActivities');
require('./models/Hobbies');
require('./models/SocialMediaLinks');
require('./models/ProfileImage');









const app = express();
app.use(cors());
app.use(express.json());

app.use('/api/auth', authRoutes);
app.use('/api/profile', profileRoutes);

sequelize.sync({ force: false })  
  .then(() => {
    console.log('Database synced.');
    app.listen(5000, () => {
      console.log('Server running on http://localhost:5000');
    });
  })
  .catch(err => console.error('Database sync error:', err));
