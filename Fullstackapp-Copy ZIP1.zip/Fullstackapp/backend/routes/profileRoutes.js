const express = require('express');
const router = express.Router();
const profileController = require('../controllers/profileController');
const PersonalDetails = require('../models/PersonalDetails');
const DemographicDetails = require('../models/DemographicDetails');
const EducationDetails = require('../models/EducationDetails');
const WorkExperience = require('../models/WorkExperience');
const AutomationTools = require('../models/AutomationTools');
const ProgrammingLanguages = require('../models/ProgrammingLanguages');
const Certifications = require('../models/Certifications');
const AwardsReceived = require('../models/AwardsReceived');
const FrameworkKnowledge = require('../models/FrameworkKnowledge');
const DomainExperience = require('../models/DomainExperience');
const AIModelExperience = require('../models/AIModelExperience');
const ExtraCurricularActivities = require('../models/ExtraCurricularActivities');
const Hobbies = require('../models/Hobbies');
const SocialMediaLinks = require('../models/SocialMediaLinks');
const ProfileImage = require('../models/ProfileImage');

// similarly add for other tabs



router.post('/personal', profileController.savePersonalDetails);
router.post('/demographic', profileController.saveDemographicDetails);
router.post('/education', profileController.saveEducationDetails);
router.post('/work', profileController.saveWorkExperience);
router.post('/automation-tools', profileController.saveAutomationTools);
router.post('/languages', profileController.saveProgrammingLanguage);
router.post('/certifications', profileController.saveCertification);
router.post('/awards', profileController.saveAward);
router.post('/frameworks', profileController.saveFrameworkKnowledge);
router.post('/domain', profileController.saveDomainExperience);
router.post('/aimodels', profileController.saveAIModelExperience);
router.post('/extracurricular', profileController.saveExtraCurricular);
router.post('/hobbies', profileController.saveHobby);
router.post('/social', profileController.saveSocialMediaLinks);
router.post('/upload', profileController.saveProfileUpload);
// similarly add for other tabs

router.get('/personal/:username', async (req, res) => {
  const { username } = req.params;
  try {
    console.log('Fetching personal details for:', username);
    const data = await PersonalDetails.findOne({ where: { username } });
    console.log('Fetched personal details:', data);
    if (data) res.json(data);
    else res.status(404).json({});
  } catch (err) {
    console.error('GET failed:', err);
    res.status(500).json({ error: 'Failed to fetch personal details' });
  }
});

router.get('/demographic/:username', async (req, res) => {
  const { username } = req.params;
  try {
    console.log('Fetching demographic for:', username);
    const data = await DemographicDetails.findOne({ where: { username } });
    console.log('Fetched demographic:', data);
    if (data) res.json(data);
    else res.status(404).json({});
  } catch (err) {
    console.error('GET failed:', err);
    res.status(500).json({ error: 'Failed to fetch demographic details' });
  }
});

router.get('/education/:username', async (req, res) => {
  const { username } = req.params;
  try {
    console.log('Fetching education for:', username);
    const data = await EducationDetails.findOne({ where: { username } });
    console.log('Fetched education:', data);
    if (data) res.json(data);
    else res.status(404).json({});
  } catch (err) {
    console.error('GET failed:', err);
    res.status(500).json({ error: 'Failed to fetch education details' });
  }
});

router.get('/work/:username', async (req, res) => {
  const { username } = req.params;
  try {
    console.log('Fetching work for:', username);
    const data = await WorkExperience.findAll({ where: { username } });
    console.log('Fetched work:', data);
    if (data) res.json(data);
    else res.status(404).json({});
  } catch (err) {
    console.error('GET failed:', err);
    res.status(500).json({ error: 'Failed to fetch work experience' });
  }
});

router.get('/automation-tools/:username', async (req, res) => {
  const { username } = req.params;
  try {
    console.log('Fetching automation for:', username);
    const data = await AutomationTools.findOne({ where: { username } });
    console.log('Fetched automation:', data);
    if (data) res.json(data);
    else res.status(404).json({});
  } catch (err) {
    console.error('GET failed:', err);
    res.status(500).json({ error: 'Failed to fetch automation tools' });
  }
});

router.get('/languages/:username', async (req, res) => {
  const { username } = req.params;
  try {
    console.log('Fetching languages for:', username);
    const data = await ProgrammingLanguages.findOne({ where: { username } });
    console.log('Fetched languages:', data);
    if (data) res.json(data);
    else res.status(404).json({});
  } catch (err) {
    console.error('GET failed:', err);
    res.status(500).json({ error: 'Failed to fetch programming languages' });
  }
});

router.get('/certifications/:username', async (req, res) => {
  const { username } = req.params;
  try {
    console.log('Fetching certifications for:', username);
    const data = await Certifications.findOne({ where: { username } });
    console.log('Fetched certifications:', data);
    if (data) res.json(data);
    else res.status(404).json({});
  } catch (err) {
    console.error('GET failed:', err);
    res.status(500).json({ error: 'Failed to fetch certifications' });
  }
});

router.get('/awards/:username', async (req, res) => {
  const { username } = req.params;
  try {
    console.log('Fetching awards for:', username);
    const data = await AwardsReceived.findOne({ where: { username } });
    console.log('Fetched awards:', data);
    if (data) res.json(data);
    else res.status(404).json({});
  } catch (err) {
    console.error('GET failed:', err);
    res.status(500).json({ error: 'Failed to fetch awards' });
  }
});

router.get('/frameworks/:username', async (req, res) => {
  const { username } = req.params;
  try {
    const data = await FrameworkKnowledge.findOne({ where: { username } });
    if (data) res.json(data);
    else res.status(404).json({});
  } catch (err) {
    console.error('GET failed:', err);
    res.status(500).json({ error: 'Failed to fetch framework knowledge' });
  }
});

router.get('/domain/:username', async (req, res) => {
  const { username } = req.params;
  try {
    console.log('Fetching domain for:', username);
    const data = await DomainExperience.findOne({ where: { username } });
    console.log('Fetched domain:', data);
    if (data) res.json(data);
    else res.status(404).json({});
  } catch (err) {
    console.error('GET failed:', err);
    res.status(500).json({ error: 'Failed to fetch domain experience' });
  }
});

router.get('/aimodels/:username', async (req, res) => {
  const { username } = req.params;
  try {
    console.log('Fetching AI models for:', username);
    const data = await AIModelExperience.findOne({ where: { username } });
    console.log('Fetched AI models:', data);
    if (data) res.json(data);
    else res.status(404).json({});
  } catch (err) {
    console.error('GET failed:', err);
    res.status(500).json({ error: 'Failed to fetch AI model experience' });
  }
});

router.get('/extracurricular/:username', async (req, res) => {
  const { username } = req.params;
  try {
    console.log('Fetching extracurricular for:', username);
    const data = await ExtraCurricularActivities.findOne({ where: { username } });
    console.log('Fetched extracurricular:', data);
    if (data) res.json(data);
    else res.status(404).json({});
  } catch (err) {
    console.error('GET failed:', err);
    res.status(500).json({ error: 'Failed to fetch extracurricular activities' });
  }
});

router.get('/hobbies/:username', async (req, res) => {
  const { username } = req.params;
  try {
    console.log('Fetching hobbies for:', username);
    const data = await Hobbies.findOne({ where: { username } });
    console.log('Fetched hobbies:', data);
    if (data) res.json(data);
    else res.status(404).json({});
  } catch (err) {
    console.error('GET failed:', err);
    res.status(500).json({ error: 'Failed to fetch hobbies' });
  }
});

router.get('/social/:username', async (req, res) => {
  const { username } = req.params;
  try {
    console.log('Fetching social links for:', username);
    const data = await SocialMediaLinks.findOne({ where: { username } });
    console.log('Fetched social links:', data);
    if (data) res.json(data);
    else res.status(404).json({});
  } catch (err) {
    console.error('GET failed:', err);
    res.status(500).json({ error: 'Failed to fetch social media links' });
  }
});

router.get('/upload/:username', async (req, res) => {
  const { username } = req.params;
  try {
    console.log('Fetching profile upload for:', username);
    const data = await ProfileUpload.findOne({ where: { username } });
    console.log('Fetched profile upload:', data);
    if (data) res.json(data);
    else res.status(404).json({});
  } catch (err) {
    console.error('GET failed:', err);
    res.status(500).json({ error: 'Failed to fetch profile upload' });
  }
});











// similarly add for other tabs


module.exports = router;