using Newtonsoft.Json;
using System.Net;
using System.Net.Http;
using DotNetEnv;

public class TenantFetcher
{
    private readonly string RAW_PATH = Path.Combine("shared", "raw");

    public TenantFetcher()
    {
        Directory.CreateDirectory(RAW_PATH);
    }

    private HttpClient GetHttpClient(string username, string password)
    {
        var handler = new HttpClientHandler
        {
            Credentials = new NetworkCredential(username.Split('\\')[1], password, username.Split('\\')[0])
        };

        return new HttpClient(handler);
    }

    public async Task<List<TenantRecord>> Fetch(string url, string username, string password)
    {
        var client = GetHttpClient(username, password);
        var response = await client.GetAsync(url);
        response.EnsureSuccessStatusCode();

        string json = await response.Content.ReadAsStringAsync();
        return JsonConvert.DeserializeObject<List<TenantRecord>>(json);
    }

    public async Task Run()
    {
        Env.Load();

        string prdUrl = Environment.GetEnvironmentVariable("PRD_URL");
        string uatUrl = Environment.GetEnvironmentVariable("UAT_URL");
        string username = Environment.GetEnvironmentVariable("USERNAME");
        string password = Environment.GetEnvironmentVariable("PASSWORD");

        var prdData = await Fetch(prdUrl, username, password);
        var uatData = await Fetch(uatUrl, username, password);

        File.WriteAllText(Path.Combine(RAW_PATH, "tenant_prd.json"), JsonConvert.SerializeObject(prdData, Formatting.Indented));
        File.WriteAllText(Path.Combine(RAW_PATH, "tenant_uat.json"), JsonConvert.SerializeObject(uatData, Formatting.Indented));

        await ExcelWriter.Save(prdData, uatData, RAW_PATH);
    }
}
