#nullable enable

using TenantExtractor.Models;

namespace TenantExtractor.Services
{
    public static class TenantFlattener
    {
        public static Dictionary<string, object?> Flatten(TenantRecord record)
        {
            var flat = new Dictionary<string, object?>
            {
                ["system"] = record.system,
                ["env"] = record.env,
                ["region"] = record.region,
                ["envType"] = record.envType,
                ["orchestrationApiUrl"] = record.orchestrationApiSettings?.url,
                ["orchestrationNotifySupport"] = record.orchestrationApiSettings?.notifySupport
            };

            if (record.addOnLinks != null)
            {
                foreach (var link in record.addOnLinks)
                {
                    if (!string.IsNullOrWhiteSpace(link.name))
                    {
                        flat[$"addonLinks_{link.name}_name"] = link.name;
                        flat[$"addonLinks_{link.name}_caption"] = link.caption;
                        flat[$"addonLinks_{link.name}_url"] = link.url;
                    }
                }
            }

            return flat;
        }
    }
}
