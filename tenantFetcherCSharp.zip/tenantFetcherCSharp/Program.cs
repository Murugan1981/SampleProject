using System;
using System.Threading.Tasks;

class Program
{
    static async Task Main(string[] args)
    {
        Console.WriteLine("Executing C# Tenant Extractor...");

        var fetcher = new TenantFetcher();
        await fetcher.Run();

        Console.WriteLine("Completed ✔");
    }
}
