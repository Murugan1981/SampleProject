#nullable enable

using OfficeOpenXml;
using TenantExtractor.Models;

namespace TenantExtractor.Services
{
    public static class ExcelWriter
    {
        public static void Save(List<TenantRecord> prd, List<TenantRecord> uat, string rawPath)
        {
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

            string excelPath = Path.Combine(rawPath, "tenant_data.xlsx");

            using (var package = new ExcelPackage())
            {
                var prdSheet = package.Workbook.Worksheets.Add("PRD");
                var uatSheet = package.Workbook.Worksheets.Add("UAT");

                WriteSheet(prdSheet, prd);
                WriteSheet(uatSheet, uat);

                // FIX for CS0618 — use SaveAs() instead of SaveAsAsync()
                package.SaveAs(new FileInfo(excelPath));
            }
        }

        private static void WriteSheet(ExcelWorksheet sheet, List<TenantRecord> data)
        {
            var flattened = data.Select(TenantFlattener.Flatten).ToList();

            var headers = flattened.SelectMany(x => x.Keys).Distinct().ToList();

            for (int col = 0; col < headers.Count; col++)
                sheet.Cells[1, col + 1].Value = headers[col];

            for (int row = 0; row < flattened.Count; row++)
            {
                for (int col = 0; col < headers.Count; col++)
                {
                    flattened[row].TryGetValue(headers[col], out var value);
                    sheet.Cells[row + 2, col + 1].Value = value;
                }
            }
        }
    }
}
