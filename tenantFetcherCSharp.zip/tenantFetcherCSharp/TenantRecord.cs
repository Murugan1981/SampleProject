#nullable enable

namespace TenantExtractor.Models
{
    public class TenantRecord
    {
        public string? system { get; set; }
        public string? env { get; set; }
        public string? region { get; set; }
        public string? envType { get; set; }

        public OrchestrationSettings? orchestrationApiSettings { get; set; }
        public List<AddOnLink>? addOnLinks { get; set; }
    }

    public class OrchestrationSettings
    {
        public string? url { get; set; }
        public bool? notifySupport { get; set; }
    }

    public class AddOnLink
    {
        public string? name { get; set; }
        public string? caption { get; set; }
        public string? url { get; set; }
    }
}
