const PersonalDetails = require('../models/PersonalDetails');

exports.savePersonalDetails = async (req, res) => {
  const { username, firstName, lastName, telephone, mobile, dob, maritalStatus } = req.body;
  try {
    const [details, created] = await PersonalDetails.findOrCreate({
      where: { username },
      defaults: { firstName, lastName, telephone, mobile, dob, maritalStatus }
    });

    if (!created) {
      await details.update({ firstName, lastName, telephone, mobile, dob, maritalStatus });
    }

    res.status(200).json({ message: 'Personal details saved successfully' });
  } catch (err) {
    console.error('Save error:', err);
    res.status(500).json({ error: 'Failed to save personal details' });
  }
};