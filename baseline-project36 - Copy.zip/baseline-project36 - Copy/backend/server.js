const express = require('express');
const cors = require('cors');
const sequelize = require('./database');
const authRoutes = require('./routes/authRoutes');
const profileRoutes = require('./routes/profileRoutes');
require('./models/User');
require('./models/PersonalDetails');

const app = express();
app.use(cors());
app.use(express.json());

app.use('/api/auth', authRoutes);
app.use('/api/profile', profileRoutes);

sequelize.sync().then(() => {
  console.log('Database synced.');
  app.listen(5000, () => {
    console.log('Server running on http://localhost:5000');
  });
}).catch(err => console.error('Database sync error:', err));