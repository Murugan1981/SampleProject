import React, { useState } from 'react';
import PersonalDetails from '../components/PersonalDetails';
import DemographicDetails from '../components/DemographicDetails';


const tabLabels = [
  "Personal Details", "Demographic Details", "Education Details", "Work Experience",
  "Automation Tools", "Programming Languages", "Certifications", "Awards Received",
  "Framework Knowledge", "Domain Experience", "AI Model Experience", "Extra Curricular Activities",
  "Hobbies", "Social Media Links", "Upload Profile Picture"
];

function MainForm() {
  const [activeTab, setActiveTab] = useState(0);
  const username = localStorage.getItem('username');

  const handleLogout = () => {
    localStorage.clear();
    window.location.href = '/login';
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 0:
        return <PersonalDetails />;
      case 1:
        return <DemographicDetails />;

      default:
        return <p>[Form content for {tabLabels[activeTab]} will go here]</p>;
    }
  };

  return (
    <div>
      <div style={{ background: '#f2f2f2', padding: '10px' }}>
        <span>Logged in as: <strong>{username}</strong></span>
        <button style={{ float: 'right' }} onClick={handleLogout}>Logout</button>
      </div>
      <div style={{ display: 'flex' }}>
        <div style={{ minWidth: '200px', borderRight: '1px solid gray' }}>
          {tabLabels.map((label, index) => (
            <div
              key={index}
              onClick={() => setActiveTab(index)}
              style={{
                padding: '10px',
                backgroundColor: activeTab === index ? '#ddd' : '#fff',
                cursor: 'pointer'
              }}
            >
              {label}
            </div>
          ))}
        </div>
        <div style={{ padding: '20px', width: '100%' }}>
          <h2>{tabLabels[activeTab]}</h2>
          {renderTabContent()}
        </div>
      </div>
    </div>
  );
}

export default MainForm;
