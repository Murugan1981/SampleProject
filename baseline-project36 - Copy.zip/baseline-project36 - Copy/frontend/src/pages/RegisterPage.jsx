import React, { useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

function RegisterPage() {
  const [form, setForm] = useState({ username: '', password: '', confirmPassword: '' });
  const [message, setMessage] = useState('');

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (form.password !== form.confirmPassword) return setMessage("Passwords do not match");

    try {
      await axios.post('http://localhost:5000/api/auth/register', {
        username: form.username,
        password: form.password
      });
      setMessage('Registered successfully!');
    } catch (err) {
      setMessage('Registration failed');
    }
  };

  return (
    <form onSubmit={handleSubmit} style={{ margin: '50px' }}>
      <h2>Register</h2>
      <input name="username" placeholder="Username" onChange={handleChange} required /><br />
      <input name="password" type="password" placeholder="Password" onChange={handleChange} required /><br />
      <input name="confirmPassword" type="password" placeholder="Confirm Password" onChange={handleChange} required /><br />
      <button type="submit">Register</button>

      <p>{message}</p>
      <p>
        Already registered? <Link to="/login">Login here</Link>
      </p>
    </form>
  );
}
export default RegisterPage;