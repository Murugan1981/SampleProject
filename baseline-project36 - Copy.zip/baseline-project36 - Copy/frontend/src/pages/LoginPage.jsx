import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate, Link } from 'react-router-dom';

function LoginPage() {
  const [form, setForm] = useState({ username: '', password: '' });
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage('');
    try {
      const res = await axios.post('http://localhost:5000/api/auth/login', {
        username: form.username,
        password: form.password,
      });

      console.log('Login response:', res.data);

      const token = res.data?.token;

      if (token) {
        localStorage.setItem('username', form.username);
        localStorage.setItem('token', token);
        navigate('/main');
      } else {
        setMessage('Login failed: Token not received.');
      }
    } catch (err) {
      console.error('Login error:', err);
      const errorMsg = err.response?.data?.error || 'Login failed due to server error';
      setMessage(errorMsg);
    }
  };

  return (
    <div style={{ margin: '50px' }}>
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <input
          name="username"
          placeholder="Username"
          value={form.username}
          onChange={handleChange}
          required
        /><br />
        <input
          name="password"
          type="password"
          placeholder="Password"
          value={form.password}
          onChange={handleChange}
          required
        /><br />
        <button type="submit">Login</button>
      </form>
      {message && <p style={{ color: 'red' }}>{message}</p>}

      <p style={{ marginTop: '15px' }}>
        New user? <Link to="/register">Register here</Link>
      </p>
      <p>
        Or go directly to the <Link to="/main">Main Page</Link> (for debugging only)
      </p>
    </div>
  );
}

export default LoginPage;
