import React, { useState } from 'react';
import axios from 'axios';

function DemographicDetails() {
  const [form, setForm] = useState({
    address1: '',
    address2: '',
    city: '',
    state: '',
    country: '',
    zipCode: ''
  });

  const [statusMessage, setStatusMessage] = useState('');

  const handleSave = async (e) => {
    e.preventDefault();
    try {
      const username = localStorage.getItem('username');
      const res = await axios.post('http://localhost:5000/api/profile/demographic', {
        username,
        ...form
      });
      setStatusMessage(res.data.message || 'Saved successfully!');
    } catch (err) {
      console.error('Save error:', err);
      setStatusMessage('Failed to save demographic details');
    }
  };

  return (
    <form onSubmit={handleSave}>
      <div>
        <label>Address Line 1: </label>
        <input value={form.address1} onChange={e => setForm({ ...form, address1: e.target.value })} />
      </div>
      <div>
        <label>Address Line 2: </label>
        <input value={form.address2} onChange={e => setForm({ ...form, address2: e.target.value })} />
      </div>
      <div>
        <label>City: </label>
        <input value={form.city} onChange={e => setForm({ ...form, city: e.target.value })} />
      </div>
      <div>
        <label>State: </label>
        <input value={form.state} onChange={e => setForm({ ...form, state: e.target.value })} />
      </div>
      <div>
        <label>Country: </label>
        <input value={form.country} onChange={e => setForm({ ...form, country: e.target.value })} />
      </div>
      <div>
        <label>Zip Code: </label>
        <input value={form.zipCode} onChange={e => setForm({ ...form, zipCode: e.target.value })} />
      </div>
      <button type="submit" style={{ marginTop: '10px' }}>Save</button>
      <p>{statusMessage}</p>
    </form>
  );
}

export default DemographicDetails;
