// src/components/PersonalDetails.jsx
import React, { useState } from 'react';
import axios from 'axios';

function PersonalDetails() {
  const [form, setForm] = useState({
    firstName: '',
    lastName: '',
    telephone: '',
    mobile: '',
    dob: '',
    maritalStatus: ''
  });

  const [statusMessage, setStatusMessage] = useState('');

  const handleSave = async (e) => {
    e.preventDefault();
    try {
      const username = localStorage.getItem('username');
      const res = await axios.post('http://localhost:5000/api/profile/personal', {
        username,
        ...form
      });
      setStatusMessage(res.data.message || 'Saved successfully!');
    } catch (err) {
      setStatusMessage('Failed to save personal details');
    }
  };

  return (
    <form onSubmit={handleSave}>
      <div>
        <label>First Name*: </label>
        <input value={form.firstName} onChange={e => setForm({ ...form, firstName: e.target.value })} required />
      </div>
      <div>
        <label>Last Name*: </label>
        <input value={form.lastName} onChange={e => setForm({ ...form, lastName: e.target.value })} required />
      </div>
      <div>
        <label>Telephone: </label>
        <input value={form.telephone} onChange={e => setForm({ ...form, telephone: e.target.value })} />
      </div>
      <div>
        <label>Mobile*: </label>
        <input value={form.mobile} onChange={e => setForm({ ...form, mobile: e.target.value })} required />
      </div>
      <div>
        <label>Date of Birth*: </label>
        <input type="date" value={form.dob} onChange={e => setForm({ ...form, dob: e.target.value })} required />
      </div>
      <div>
        <label>Marital Status: </label><br />
        <label><input type="checkbox" checked={form.maritalStatus === 'Married'} onChange={() => setForm({ ...form, maritalStatus: 'Married' })} /> Married</label><br />
        <label><input type="checkbox" checked={form.maritalStatus === 'Single'} onChange={() => setForm({ ...form, maritalStatus: 'Single' })} /> Single</label><br />
        <label><input type="checkbox" checked={form.maritalStatus === 'Separated'} onChange={() => setForm({ ...form, maritalStatus: 'Separated' })} /> Separated</label>
      </div>
      <button type="submit" style={{ marginTop: '10px' }}>Save</button>
      <p>{statusMessage}</p>
    </form>
  );
}

export default PersonalDetails;
